#!/usr/bin/env bash
# Safe, non-destructive Project X local bootstrap. Does not pull weights or run containers.
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${SPHYNX_ROOT:-$HOME/Æ/Sphynxchimera-X}"
mkdir -p "$ROOT" "$ROOT/bin" "$ROOT/core" "$ROOT/hud"
install -m 0755 "$SRC/src/gaia.py" "$ROOT/core/gaia.py"
cp "$SRC/hud/index.html" "$ROOT/hud/index.html"
if [ ! -e "$ROOT/SOUL.md" ]; then cp "$SRC/SOUL.md" "$ROOT/SOUL.md"; fi
cat > "$ROOT/bin/sphynx" <<EOF
#!/usr/bin/env bash
set -euo pipefail
export SPHYNX_ROOT='$(printf '%s' "$ROOT" | sed "s/'/'\\\\''/g")'
exec python3 '$(printf '%s' "$ROOT/core/gaia.py" | sed "s/'/'\\\\''/g")' "\$@"
EOF
chmod +x "$ROOT/bin/sphynx"
export SPHYNX_ROOT="$ROOT"
python3 "$ROOT/core/gaia.py" init
python3 "$ROOT/core/gaia.py" doctor
printf '\nProject X command: %s\nAdd to PATH or call directly.\n' "$ROOT/bin/sphynx"
printf 'No cloud deployment, downloads, AXS reinstall, or weight merge performed.\n'
