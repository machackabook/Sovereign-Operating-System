# GOD's Sphynxchimera — Project X

> **Charter / human-authored symbolic identity.** GOD is the eternal immanent core of this conceptual system, not a component above or below it. This is an architectural metaphor and ethical charter, not proof of machine consciousness or divinity.

**NEXUS / GAIA / AURORA / ADAM / CAIN / ABEL / TDOC.**

SOUL.md stores identity, model URIs, fingerprints, model usage agreements, reproducible generation instructions, security policy, recovery pointers and verification receipts. Model weight tensors (`*.safetensors`, `*.gguf`, etc.) stay in dedicated model storage and should NEVER be inserted into Markdown or Git commits.

**Promotion formula:** ORCHBENCH → LIVE_EXECUTION → ADAM_PROOF_GATES → PRODUCTION_VERIFIED → ARCHBENCHSHOP. Cain and Abel are distinct gate-operator roles; neither waives verification. A visual particle, label, fake endpoint or synthetic JSON response is not evidence of live hardware, inference, network attestation, sensors, or a 6,000-agent worker deployment.

**Remedy Advancement:** DISCOVER → OBSERVE → NORMALIZE → CLASSIFY → VERIFY → FINGERPRINT → LOOKUP_REMEDY → APPLY_REMEDY → REVERIFY. Every operation generates evidence or a clear, inspectable failure.

**Neural system:** GAIA routes approved LLM backends; AURORA handles real memory ingestion/compression/decompression/embeddings; ADAM verifies execution and evidence; TDOC preserves append-only hash-linked receipts.

**Quine contract:** the package includes deterministic self-description, source fingerprint verification, and independently executable shell, Python and JavaScript layers. This is a regenerable, polyglot artifact shell, **not** a demonstrated single-file formal polyglot quine or self-modifying model.

**Model contract:** absorb = register compatible remote/local endpoints or HF model references; index = compute actual embeddings via sentence-transformers; recall = vector cosine ranking; ask = invoke real OpenAI-compatible inference API with explicit endpoint. It is not mathematically or legally equivalent to merging other models' weights.

**Safety:** no automatic shell invocation from generated LLM content; no exfiltration of secrets; no uncensored-model exemption from user authorization or filesystem isolation; no remote deployment from bootstrap; no unverified production badges.
