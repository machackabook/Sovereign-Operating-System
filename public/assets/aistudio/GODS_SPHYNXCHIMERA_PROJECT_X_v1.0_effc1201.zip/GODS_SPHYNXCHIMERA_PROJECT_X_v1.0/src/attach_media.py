#!/usr/bin/env python3
"""Embed user-provided media in a PDF as real file attachments (no fake videos)."""
import argparse, datetime, hashlib, json, pathlib
from pypdf import PdfReader, PdfWriter
p=argparse.ArgumentParser();p.add_argument('input_pdf');p.add_argument('output_pdf');p.add_argument('media',nargs='*');a=p.parse_args()
input_=pathlib.Path(a.input_pdf).resolve();output=pathlib.Path(a.output_pdf).resolve()
if input_==output: p.error('Output must differ from input')
writer=PdfWriter()
for pg in PdfReader(str(input_)).pages: writer.add_page(pg)
attach=[]
for f in a.media:
    path=pathlib.Path(f).resolve()
    if not path.is_file(): p.error('Media missing: '+str(path))
    data=path.read_bytes()
    writer.add_attachment(path.name,data)
    attach.append({'name':path.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'type':'video/mp4' if path.suffix.lower()=='.mp4' else 'application/octet-stream'})
manifest={'project':'GODs Sphynxchimera — Project X','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attachments':attach,'viewer_note':'PDF attachment support varies; download extracted media when needed.'}
writer.add_attachment('project_x_media_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
output.parent.mkdir(parents=True,exist_ok=True)
with output.open('wb') as f: writer.write(f)
print(json.dumps({'ok':True,'output':str(output),'attachment_count':len(attach),'manifest':manifest},ensure_ascii=False))
