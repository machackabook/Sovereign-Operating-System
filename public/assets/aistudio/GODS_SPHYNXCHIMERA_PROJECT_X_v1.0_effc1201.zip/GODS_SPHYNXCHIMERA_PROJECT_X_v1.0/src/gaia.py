#!/usr/bin/env python3
"""GOD's Sphynxchimera / Project X.
Real local artifact storage, event ledger, model registry and optional semantic retrieval.
Nothing remotely executes or deploys without explicit user commands.
"""
from __future__ import annotations
import argparse, base64, datetime as dt, gzip, hashlib, json, math, os, pathlib, re, shutil, sqlite3, subprocess, sys, urllib.request, urllib.error, uuid

VERSION = '1.0.0'
ROOT = pathlib.Path(os.environ.get('SPHYNX_ROOT', str(pathlib.Path.home() / 'Æ' / 'Sphynxchimera-X'))).expanduser()
SOURCE = 'GODS_SPHYNXCHIMERA_PROJECT_X'
ENV_RE = re.compile(r'^[A-Z][A-Z0-9_]*$')
REPO_RE = re.compile(r'^[\w.-]+/[\w.-]+$')

def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def canonical(v): return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
def fail(reason, code=2):
    print(json.dumps({'ok':False,'error':reason},ensure_ascii=False),file=sys.stderr)
    raise SystemExit(code)

def dirs():
    for d in ('state','logs','media','model-metadata','evidence','exports'):
        (ROOT/d).mkdir(parents=True,exist_ok=True)
    (ROOT/'SOUL.md').write_text((ROOT/'SOUL.md').read_text() if (ROOT/'SOUL.md').exists() else '# GOD’s Sphynxchimera — Project X\n\nGOD is the eternal immanent core of this symbolic architecture.\nThe charter governs human authorship, care, consent, reproducible evidence and model boundaries.\nActual model weights live outside Markdown, under independently referenced model storage.\n',encoding='utf-8')
    with db() as conn: schema(conn)

def db():
    ROOT.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(ROOT/'state'/'behavior.db')
    con.row_factory=sqlite3.Row
    return con

def schema(con):
    con.executescript('''
    CREATE TABLE IF NOT EXISTS models(id TEXT PRIMARY KEY, url TEXT, repo_id TEXT, model_name TEXT, token_env TEXT, kind TEXT, created_utc TEXT);
    CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY, source TEXT, sha256 TEXT, mime TEXT, codec TEXT, compressed BLOB, bytes INTEGER, created_utc TEXT);
    CREATE TABLE IF NOT EXISTS embeddings(document_id TEXT, model TEXT, vector_json TEXT, PRIMARY KEY(document_id,model));
    CREATE TABLE IF NOT EXISTS receipts(id TEXT PRIMARY KEY, gate TEXT, status TEXT, evidence_sha256 TEXT, created_utc TEXT);
    ''')
    con.commit()

def record(event, details):
    dirs()
    ledger=ROOT/'logs'/'tdoc-ledger.jsonl'
    prev='0'*64
    if ledger.exists():
        for line in ledger.read_text(encoding='utf-8').splitlines():
            if line.strip():
                try: prev=json.loads(line)['digest']
                except (ValueError,KeyError): fail('Existing TDOC ledger is malformed; refusing to append')
    payload={'utc':now(),'tdoc':'TDOC-PROJECT-X-10026','event':event,'details':details,'previous':prev}
    payload['digest']=sha(canonical(payload))
    with ledger.open('a',encoding='utf-8') as f:
        f.write(json.dumps(payload,ensure_ascii=False,sort_keys=True)+'\n')
        f.flush();os.fsync(f.fileno())
    return payload

def emit(value):
    print(json.dumps(value,ensure_ascii=False,indent=2))

def init(_):
    dirs(); ev=record('INIT',{'version':VERSION});emit({'ok':True,'root':str(ROOT),'tdoc':ev['digest']})

def registry(a):
    dirs()
    if a.token_env and not ENV_RE.fullmatch(a.token_env): fail('token-env must be an uppercase environment-variable name')
    if a.repo_id and not REPO_RE.fullmatch(a.repo_id): fail('Invalid Hugging Face repository identifier')
    if not a.endpoint and not a.repo_id: fail('Specify --endpoint or --repo-id')
    if a.endpoint and not (a.endpoint.startswith('http://') or a.endpoint.startswith('https://')): fail('Endpoint requires http(s)://')
    id_=a.name
    with db() as con:
        schema(con)
        con.execute('INSERT OR REPLACE INTO models VALUES(?,?,?,?,?,?,?)',(id_,a.endpoint or '',a.repo_id or '',a.model or a.name,a.token_env or '',a.kind,now()))
        con.commit()
    ev=record('ABSORB_MODEL_REFERENCE',{'id':id_,'repo':a.repo_id or '', 'kind':a.kind,'url':a.endpoint or '', 'does_not_merge_weights':True})
    emit({'ok':True,'registered':id_,'weights_copied':False,'ledger':ev['digest']})

def memory_put(source,data,mime='text/plain'):
    if len(data)>64*1024*1024: fail('Ingestion limit is 64MiB per item; use an external media store for large video')
    id_=uuid.uuid4().hex
    digest=sha(data)
    compressed=gzip.compress(data,compresslevel=6,mtime=0)
    with db() as con:
        schema(con)
        con.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?)',(id_,source,digest,mime,'gzip',compressed,len(data),now()))
        con.commit()
    return {'id':id_,'sha256':digest,'bytes':len(data),'gzip_bytes':len(compressed),'mime':mime}

def ingest(a):
    dirs()
    p=pathlib.Path(a.file).expanduser().resolve()
    if not p.is_file(): fail('File does not exist')
    if p.stat().st_size>64*1024*1024: fail('File too large for SQLite ingest (64MiB). Store large media externally with a hash manifest.')
    ext=p.suffix.lower()
    accepted={'.txt':'text/plain','.md':'text/markdown','.json':'application/json','.csv':'text/csv','.log':'text/plain','.mp4':'video/mp4','.webm':'video/webm','.png':'image/png','.jpg':'image/jpeg','.pdf':'application/pdf'}
    if ext not in accepted: fail('Unsupported file extension; do not ingest executable files')
    v=memory_put(p.name,p.read_bytes(),accepted[ext]); ev=record('INGEST',{'source':p.name,**v});emit({'ok':True,**v,'ledger':ev['digest']})

def extract(a):
    dirs()
    with db() as con:
        schema(con)
        row=con.execute('SELECT * FROM documents WHERE id=?',(a.document_id,)).fetchone()
    if not row: fail('Document not found')
    raw=gzip.decompress(row['compressed'])
    if sha(raw)!=row['sha256'] or len(raw)!=row['bytes']: fail('Integrity check failed')
    dst=pathlib.Path(a.output).expanduser().resolve()
    if dst.exists() and not a.overwrite: fail('Output already exists (pass --overwrite explicitly)')
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(raw)
    ev=record('DECOMPRESS',{'id':a.document_id,'output_name':dst.name,'sha256':row['sha256']})
    emit({'ok':True,'bytes':len(raw),'sha256':row['sha256'],'ledger':ev['digest']})

def semantic_model(name):
    try: from sentence_transformers import SentenceTransformer
    except ImportError: fail('sentence-transformers not installed. Run python -m pip install sentence-transformers, then retry.')
    return SentenceTransformer(name)

def index(a):
    dirs(); model=semantic_model(a.embedding_model)
    with db() as con:
        schema(con)
        rows=con.execute("SELECT * FROM documents WHERE mime LIKE 'text/%' OR mime = 'application/json'").fetchall()
        count=0
        for row in rows:
            text=gzip.decompress(row['compressed']).decode('utf-8','replace')
            embedding=model.encode_document(text) if hasattr(model,'encode_document') else model.encode(text)
            vec=embedding.tolist()
            con.execute('INSERT OR REPLACE INTO embeddings VALUES(?,?,?)',(row['id'],a.embedding_model,json.dumps(vec)))
            count+=1
        con.commit()
    ev=record('EMBED_DOCUMENTS',{'embedding_model':a.embedding_model,'count':count})
    emit({'ok':True,'embedded_documents':count,'ledger':ev['digest']})

def recall(a):
    dirs(); model=semantic_model(a.embedding_model)
    q=model.encode_query(a.query) if hasattr(model,'encode_query') else model.encode(a.query)
    q=q.tolist(); qnorm=math.sqrt(sum(x*x for x in q))
    with db() as con:
        schema(con)
        rows=con.execute('SELECT d.id,d.source,d.sha256,d.mime,e.vector_json FROM embeddings e JOIN documents d ON d.id=e.document_id WHERE e.model=?',(a.embedding_model,)).fetchall()
    scores=[]
    for r in rows:
        v=json.loads(r['vector_json'])
        if len(v)!=len(q): continue
        den=qnorm*math.sqrt(sum(x*x for x in v))
        score=sum(x*y for x,y in zip(q,v))/den if den else 0.
        scores.append({'id':r['id'],'source':r['source'],'score':round(score,6),'sha256':r['sha256']})
    scores.sort(key=lambda o:o['score'],reverse=True)
    ev=record('SEMANTIC_RECALL',{'model':a.embedding_model,'query_sha256':sha(a.query.encode()),'results':min(a.top_k,len(scores))})
    emit({'ok':True,'matches':scores[:a.top_k],'ledger':ev['digest']})

def ask(a):
    dirs()
    with db() as con:
        schema(con)
        m=con.execute('SELECT * FROM models WHERE id=?',(a.name,)).fetchone()
    if not m: fail('Unknown model, use absorb to register an endpoint first')
    if not m['url']: fail('Model has metadata only; register a real endpoint before inference')
    auth=m['token_env']; key=os.environ.get(auth,'') if auth else ''
    if auth and not key: fail(f'Environment variable {auth} is missing')
    endpoint=m['url'].rstrip('/')+'/chat/completions'
    body={'model':m['model_name'],'messages':[{'role':'user','content':a.prompt}],'temperature':a.temperature,'max_tokens':a.max_tokens}
    headers={'Content-Type':'application/json'}
    if key: headers['Authorization']='Bearer '+key
    req=urllib.request.Request(endpoint,data=canonical(body),headers=headers,method='POST')
    try:
        with urllib.request.urlopen(req,timeout=a.timeout) as response: data=json.loads(response.read(8*1024*1024))
    except (OSError,ValueError,urllib.error.HTTPError) as e: fail('Real inference request failed: '+str(e))
    if not data.get('choices'): fail('Endpoint returned no choices')
    # Log only prompt digest, not prompt or secret.
    ev=record('LIVE_INFERENCE',{'model':a.name,'prompt_sha256':sha(a.prompt.encode()),'response_sha256':sha(canonical(data)),'choices':len(data['choices'])})
    emit({'ok':True,'model':a.name,'response':data,'ledger':ev['digest']})

def verify(_):
    dirs(); ledger=ROOT/'logs'/'tdoc-ledger.jsonl'
    prev='0'*64; n=0; errors=[]
    for lineno,line in enumerate(ledger.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip(): continue
        try:
            row=json.loads(line); dig=row.pop('digest')
            if row['previous'] != prev or sha(canonical(row)) != dig: errors.append('Ledger mismatch line '+str(lineno))
            prev=dig;n+=1
        except (ValueError,KeyError): errors.append('Invalid ledger line '+str(lineno))
    with db() as con:
        schema(con); rows=con.execute('SELECT * FROM documents').fetchall()
    for r in rows:
        try:
            b=gzip.decompress(r['compressed'])
            if sha(b)!=r['sha256'] or len(b)!=r['bytes']: errors.append('Mismatch '+r['id'])
        except Exception: errors.append('Uncompressible '+r['id'])
    status='PASS' if not errors else 'FAIL'
    # Verify is intentionally limited to the local storage/evidence scope.
    if not errors: ev=record('LOCAL_INTEGRITY_VERIFIED',{'checked_events':n,'documents':len(rows),'scope':'local-ledger-and-media'})
    emit({'ok':not errors,'status':status,'ledger_events':n,'documents':len(rows),'errors':errors,'scope':'LOCAL_ONLY','live_gpu_attestation':False})
    if errors: raise SystemExit(1)

def doctor(_):
    dirs()
    checks={'python':sys.version.split()[0], 'docker': bool(shutil.which('docker')), 'nvidia_smi':bool(shutil.which('nvidia-smi')),'sentence_transformers':False,'model_registry':0,'documents':0}
    try: import sentence_transformers;checks['sentence_transformers']=True
    except ImportError: pass
    with db() as con:
        checks['model_registry']=con.execute('SELECT COUNT(*) FROM models').fetchone()[0]
        checks['documents']=con.execute('SELECT COUNT(*) FROM documents').fetchone()[0]
    emit({'ok':True,'checks':checks,'gpu_inference_verified':False})

def serve(a):
    dirs()
    from http.server import HTTPServer, BaseHTTPRequestHandler
    assets=pathlib.Path(__file__).resolve().parent.parent/'hud'/'index.html'
    if not assets.exists(): fail('HUD index.html not found')
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path=='/api/status':
                with db() as con:
                    schema(con); models=[dict(x) for x in con.execute('SELECT id,repo_id,model_name,kind,created_utc FROM models')]
                    docs=con.execute('SELECT COUNT(*) FROM documents').fetchone()[0]
                payload=canonical({'project':SOURCE,'version':VERSION,'models':models,'documents':docs,'root':str(ROOT)})
                self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
            elif self.path in ('/','/index.html'):
                data=assets.read_bytes(); self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'");self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
            else: self.send_error(404)
        def log_message(self,*args): pass
    if a.host != '127.0.0.1': fail('HUD binds loopback only; use an authenticated reverse proxy for access from another device')
    print('Live local HUD: http://127.0.0.1:'+str(a.port),flush=True)
    HTTPServer((a.host,a.port),Handler).serve_forever()

def main():
    p=argparse.ArgumentParser(description="Project X evidence-first autonomous-organism *software architecture* CLI")
    sub=p.add_subparsers(dest='command',required=True)
    def cmd(n,f): sp=sub.add_parser(n); sp.set_defaults(run=f);return sp
    cmd('init',init)
    a=cmd('absorb',registry);a.add_argument('name');a.add_argument('--endpoint');a.add_argument('--repo-id');a.add_argument('--model');a.add_argument('--token-env');a.add_argument('--kind',default='llm',choices=['llm','embedding','vision','speech','tool'])
    a=cmd('ingest',ingest);a.add_argument('file')
    a=cmd('decompress',extract);a.add_argument('document_id');a.add_argument('output');a.add_argument('--overwrite',action='store_true')
    a=cmd('index',index);a.add_argument('--embedding-model',default='sentence-transformers/all-MiniLM-L6-v2')
    a=cmd('recall',recall);a.add_argument('query');a.add_argument('--embedding-model',default='sentence-transformers/all-MiniLM-L6-v2');a.add_argument('--top-k',type=int,default=5)
    a=cmd('ask',ask);a.add_argument('name');a.add_argument('prompt');a.add_argument('--max-tokens',type=int,default=200);a.add_argument('--temperature',type=float,default=0.3);a.add_argument('--timeout',type=int,default=120)
    cmd('verify',verify);cmd('doctor',doctor)
    a=cmd('hud',serve);a.add_argument('--host',default='127.0.0.1');a.add_argument('--port',type=int,default=8877)
    a=p.parse_args();a.run(a)
if __name__=='__main__':main()
