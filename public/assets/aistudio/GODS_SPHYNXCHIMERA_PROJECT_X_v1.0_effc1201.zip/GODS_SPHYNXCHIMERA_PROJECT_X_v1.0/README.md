# ⚡ GOD's Sphynxchimera — Project X v1.0.0

**Deliverable:** local, non-destructive polyglot-shell starter: executable Python TDOC/SQLite/gzip/semantic-index/inference CLI; browser HUD reflecting actual API state; Cordova AXS adapter; GPU-specific AEON/DFlash compose; adapter contracts; audit spreadsheet; media-carrying PDF. This release is **locally testable**, not claimed to have live GPU weights or third-party production deployment.

## Single local installation command

```bash
bash install.sh
```

Or from the package directory on Android Termux / Linux:

```bash
export SPHYNX_ROOT="$HOME/Æ/Sphynxchimera-X"; bash ./install.sh; "$SPHYNX_ROOT/bin/sphynx" verify
```

Dependencies: Python 3.10+; `sentence-transformers` optional for true semantic encoding. To add real vector retrieval:

```bash
python3 -m pip install sentence-transformers
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" ingest ./SOUL.md
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" index
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" recall "What are the ADAM proof gates?"
```

Models are **references, not merged weights**. Register a real GPU inference server then ask:

```bash
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" absorb aeon --repo-id AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-Multimodal-NVFP4-MTP-XS --endpoint http://127.0.0.1:8000/v1 --model aeon-ultimate
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" ask aeon "State the ADAM proof-gate sequence."
```

Open the actual local HUD after running:

```bash
"$HOME/Æ/Sphynxchimera-X/bin/sphynx" hud
```

The HUD listens on **127.0.0.1:8877** and reads `/api/status` with no fake success responses.

## Weights / GPU route

1. **DGX Spark (GB10 128 GB):** `deploy/docker-compose.spark.yml`, AEON XS body in `models/aeon-xs/`, z-lab DFlash drafter in `models/dflash-drafter/`. Accept the drafter's Hugging Face terms first.
2. **GPU host download (manual, large):** `hf download AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-Multimodal-NVFP4-MTP-XS --local-dir models/aeon-xs` and `hf download z-lab/Qwen3.6-27B-DFlash --local-dir models/dflash-drafter`.
3. **Start (manual, billable/hardware impact):** `docker compose -f deploy/docker-compose.spark.yml config` then `docker compose -f deploy/docker-compose.spark.yml up -d`. Use `curl -fsS http://127.0.0.1:8000/health` and a real `POST /v1/chat/completions` plus `docker logs sphynxchimera-aeon` before claiming a runtime PASS.
4. **Other NVIDIA hardware:** do **not** use Spark-specific image/flags. Consult AEON's own hardware recipes, validate GPU capability first.

`--kv-cache-dtype auto` (BF16) + DFlash `n=10` is the AEON-7 documented Spark path. `--kv-cache-dtype fp8` with this DFlash drafter is **not supported as a validated configuration**. `deploy/mtp-fp8-lab.txt` documents a separate unverified research profile; avoid presenting it as a merged production configuration.

## Data authenticity / hidden encoding

* GHCR `vllm-aeon-ultimate-dflash` linked by user is the **old experimental DDTree lineage**, not AEON's current unified production container.
* The user-provided AXS `buildUrl` arrays assemble network URLs from fragments. `btoa` wraps textual fake launch references in Base64 in the supplied HUD; `10.AXS.*.*` is not an IP address. This is no demonstrated hidden trainable model, secret weight store, or autonomous network of 6,000 endpoints.
* No model tensor data is included in this package or stored in `SOUL.md`. We do not claim direct examination of all private/hidden container layers.
* The original `Terminal.startAxs` interpolates values into shell commands; see `cordova/AXS_SECURITY_NOTES.md` before connecting untrusted inputs.

## Evidence semantics

`verify` checks local TDOC hash-chain and gzip round-trip file integrity. A successful `verify` **does not** certify inference, GPU performance, sensor attestation, network deliveries or ADAM production promotion. Use the spreadsheet to record those separately.

## References

- https://github.com/AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-DFlash
- https://github.com/AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-DFlash/blob/main/AGENTS.md
- https://github.com/AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-DFlash/blob/main/docker-compose.spark-xs.yml
- https://github.com/AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-DFlash/pkgs/container/vllm-aeon-ultimate-dflash
- https://huggingface.co/z-lab/Qwen3.6-27B-DFlash
- https://sbert.net/

## Executable quine proof

Two language-local formal quines are under `quine/`. Exact output was verified under Python and Node. The entire package is a polyglot shell, not one single-source multi-language quine.
