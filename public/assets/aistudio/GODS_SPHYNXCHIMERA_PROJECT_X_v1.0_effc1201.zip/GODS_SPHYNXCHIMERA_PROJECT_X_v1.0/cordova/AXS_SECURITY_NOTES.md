# AXS original-source review and safe bridge

Your original `Terminal` Cordova module is not replaced. Its `install`, `uninstall`, `restore`, `backup`, `repair`, `startAxs`, and `stopAxs` methods remain in the original source. Our new adapter calls only `getDiagnostics`, `isInstalled`, `startAxs(false, ...)` and `stopAxs` after explicit authorization. There is no automatic reinstallation.

**Important vulnerability in upstream user-supplied source:**

```javascript
Object.entries(config.env).map(([k, v]) => `export ${k}="${v}"`)
```

Values containing `$()`, double quotes or shell metacharacters can be executed by the interactive shell. The `initScript` value is also composed into a raw `source` string without validation. The bridge rejects these characters, but do not expose the original `startAxs` directly to untrusted inputs. For a proper repair, modify the original method to construct a strictly validated, shell-quoted argument vector, ideally through `Executor` argument-based APIs if supported. Also audit the original install operation: it uninstalls before replacing the rootfs, and backups/restores use recursive deletion, so always require separate user confirmation.

The legacy source constructs download URLs from fragments (e.g., `ht`+`tps`+`:`+`//`; `raw.github`+`usercontent.com`). These are **obfuscated endpoint strings**, not a verified hidden model. `btoa(...)` in the HUD encodes synthetic labels, not weights.
