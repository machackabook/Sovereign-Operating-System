/* Cordova adapter: requires the actual AXS Terminal module. Does NOT reinstall. */
cordova.define('com.gaia.sphynxchimera.axs',function(require,exports,module){
  'use strict';
  const Terminal=require('com.foxdebug.acode.rk.exec.terminal.Terminal');
  const NAME=/^[A-Z][A-Z0-9_]*$/;
  const ALLOWED=new Set(['GAIA_PROFILE','AURORA_PROFILE','TDOC_ROOT','NEXUS_MODE']);
  const ADAPTER_CONTRACT=Object.freeze({execute:'async',input:'validated',authorization:'required',output:'structured',evidence:'mandatory',failure:'explicit'});
  const adapter={
    ADAPTER_CONTRACT,
    async diagnostics(){
      const info=await Terminal.getDiagnostics();
      return {ok:true,backend:'AXS',measured:info,checked_at:new Date().toISOString()};
    },
    async start({authorized=false,env={},failsafe=false}={}){
      if(authorized!==true)throw new Error('Explicit authorization is required');
      if(!(await Terminal.isInstalled()))throw new Error('AXS not installed. Install manually via original AXS lifecycle UI.');
      const safe={};
      for(const [k,v] of Object.entries(env)){
        if(!NAME.test(k)||!ALLOWED.has(k)||typeof v!=='string'||v.length>256||/[\u0000-\u001F"'`$\\;]/.test(v))throw new Error('Unsafe AXS environment variable '+k);
        safe[k]=v;
      }
      await Terminal.startAxs(false,console.log,console.error,{failsafe,env:safe});
      return {ok:true,started:true,backend:'AXS',install_invoked:false};
    },
    async stop({authorized=false}={}){
      if(!authorized)throw new Error('Explicit stop authorization required');
      if(await Terminal.isAxsRunning())await Terminal.stopAxs();
      return {ok:true,stopped:true};
    }
  };
  module.exports=adapter;
});
