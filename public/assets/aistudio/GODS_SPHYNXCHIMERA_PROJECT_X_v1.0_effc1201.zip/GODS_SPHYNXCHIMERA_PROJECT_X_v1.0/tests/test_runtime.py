#!/usr/bin/env python3
"""Runs real, isolated, no-network acceptance tests in a temporary directory."""
import importlib.util, os, pathlib, subprocess, sys, tempfile, json
script=pathlib.Path(__file__).resolve().parents[1]/'src'/'gaia.py'
with tempfile.TemporaryDirectory(prefix='sphynx-test-') as root:
    env={**os.environ,'SPHYNX_ROOT':root}
    def call(*args):
        p=subprocess.run([sys.executable,str(script),*args],capture_output=True,text=True,env=env,check=True)
        return json.loads(p.stdout)
    assert call('init')['ok']
    sample=pathlib.Path(root)/'source.txt'
    sample.write_text('GAIA AURORA ADAM real test ✓',encoding='utf-8')
    obj=call('ingest',str(sample))
    restored=pathlib.Path(root)/'restored.txt'
    assert call('decompress',obj['id'],str(restored))['ok']
    assert restored.read_bytes()==sample.read_bytes()
    assert call('verify')['scope']=='LOCAL_ONLY'
    assert call('absorb','local-aeon','--repo-id','AEON-7/Qwen3.6-27B-AEON-Ultimate-Uncensored-BF16')['weights_copied'] is False
    assert call('doctor')['checks']['model_registry']==1
    # Verify tampering is detected.
    ledger=pathlib.Path(root)/'logs'/'tdoc-ledger.jsonl'
    lines=ledger.read_text().splitlines();lines[0]=lines[0].replace('INIT','MODIFIED')
    ledger.write_text('\n'.join(lines)+'\n')
    fail=subprocess.run([sys.executable,str(script),'verify'],env=env,capture_output=True,text=True)
    assert fail.returncode!=0,'Tampered ledger must fail'
print('PASS: local init, ingest, decompress, hash chain, registry, doctor, tamper detection')
