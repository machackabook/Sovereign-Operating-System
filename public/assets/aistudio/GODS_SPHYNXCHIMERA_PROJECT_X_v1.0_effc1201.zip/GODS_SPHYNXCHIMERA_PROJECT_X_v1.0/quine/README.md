# Verified quine seeds

These two independent formal quines print their full source byte-for-byte. Verify:

```bash
python3 quine/python_quine.py | cmp - quine/python_quine.py
node quine/javascript_quine.js | cmp - quine/javascript_quine.js
```

The wider distribution is a reproducible polyglot shell, not a single-file multi-language quine.
