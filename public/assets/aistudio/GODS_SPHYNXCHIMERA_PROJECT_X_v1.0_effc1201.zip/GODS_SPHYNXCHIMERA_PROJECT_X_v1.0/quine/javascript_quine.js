const f = () => {
  const src = f.toString();
  return `const f = ${src};\nprocess.stdout.write(f());\n`;
};
process.stdout.write(f());
