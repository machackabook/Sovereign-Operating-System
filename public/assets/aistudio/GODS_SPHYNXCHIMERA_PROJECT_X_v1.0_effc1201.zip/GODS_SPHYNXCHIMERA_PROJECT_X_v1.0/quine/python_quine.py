s = 's = %r\nprint(s %% s, end="")\n'
print(s % s, end="")
