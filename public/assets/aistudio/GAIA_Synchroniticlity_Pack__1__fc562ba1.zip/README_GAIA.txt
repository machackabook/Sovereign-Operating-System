GAIA — Ø/Œ/Þ/Æ Synchroniticlity Pack

Files:
- gaia_accordion_wallpaper.html  (procedural animated render + mic audio-react + parallax + border overlay)
- GAIA.ai  (Illustrator-openable PDF-compatible placeholder shell containing the required symbols + copyright)

How to export wallpaper images:
1) Open gaia_accordion_wallpaper.html in a browser.
2) Open DevTools console.
3) Run:
   exportImage('png', 4320, 7680)   // 8K-ish portrait for phones
   exportImage('webp', 4320, 7680)  // WebP export (supported widely)
   exportImage('avif', 4320, 7680)  // AVIF export (only if browser supports)

Audio reactive:
- Tap once to request microphone permission (tap again to disable).

Parallax:
- If supported, deviceorientation will add subtle movement.

Android Live Wallpaper APK (next step):
This pack includes the render logic. To turn it into an APK, wrap the HTML in a Live Wallpaper service with a WebView (see notes you requested).
