GAIA MEMORY PORTABLE HANDOFF — v1.0.0

Bring GAIA_MEMORY_HANDOFF.json to a client that supports remote MCP, or paste GAIA_MEMORY_CLIPBOARD.txt into the receiving conversation. The canonical bridge and endpoint are in both files. Authentication must complete inside that receiving client/browser. Verify a successful memory_status response before assuming the model can retrieve memory.

Browser rendering, model tool access, and a headless node are three separate access paths. Signing into an embedded browser may authenticate that browser only. Opening the same URL in main Chrome or mobile does not transfer that sandbox's cookies. Uploading MHTML is a static content handoff and cannot restore or refresh a session. Chat branches/projects do not change this boundary.

For continuity, use stable reference IDs and explicit branch/parent mappings. Record a real changed URL as a new revision with the old reference retained. An extra URL character, a chat move, and a valid ledger chain are different observations. There is no automatic provider file-move watcher connected in this bundle.

This bundle contains no credentials, cookies, node enrollment files, or memory records. Do not add them. Keep gaia-beacon-node.json and its service-access credentials on the enrolled device only.

The existing Memory Bridge is distinct from the GAIA Memory portal vault. The connector was reachable in the authoring conversation, but a receiving client still needs independent authorization. No native ChatGPT memory, Google-session import, or automatic provider ingestion is implied.
