# Stage 466 — lerp alpha is the literal 0.05 (2026-10-07 10:08 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `this.mesh.position.lerp(new THREE.Vector3(x, y, z), 0.05)`
- alpha is not scaled by `state.gravityPull`
- paste still allocates Vector3 inside lerp
- torus y identical to infinity y remains the prior hold
- paste not rewritten
- numeral `137451921129154466`
- no secrets, no root claim

Next: 467 lemniscate z stays `sin(theta) * cos(theta)` over the same denom.
