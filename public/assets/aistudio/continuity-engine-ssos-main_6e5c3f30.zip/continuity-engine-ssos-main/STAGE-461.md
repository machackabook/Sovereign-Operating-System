# Stage 461 — lemniscate denom (2026-10-06 20:07 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `denom = 1 + sin(theta)^2` divides infinity x and z only
- y stays `minor * sin(phi) * sin(t * 0.5 + idx)`
- scale stays `major * 1.5`
- hamiltonian y lift remains independent of hScale
- paste not rewritten
- numeral `137451921129154461`
- no secrets, no root claim

Next: 462 torus default fallthrough, no fifth case.
