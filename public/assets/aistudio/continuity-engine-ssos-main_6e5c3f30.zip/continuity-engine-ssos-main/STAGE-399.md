# Stage 399 — hold torus tube radius major + minor * cos(phi) (2026-10-03 20:08 CDT)

Connecting chat re-pasted `update(t)`.

## Session pin
- uniforms `uTime` / `uGravity`
- `theta += (0.01 + idx * 0.002) * gravityPull`
- `major = 10 + idx * 2`, `minor = 3 + toroidalWeave * 2`
- geometries: infinity | hamiltonian | triangular | torus default
- session hash `beec41f1`. Living hash `7cd81012`.
- lerp alpha remains `0.05`

## Enhancement this hop
Public stamp only. Visualizer holds `tubeRadius = major + minor * cos(phi)` on torus x and z. Shared y stays `minor * sin(phi) * sin(t * 0.5 + idx)`. Radius ignores t, idx, theta, and gravityPull. Paste not rewritten. Append-only hourly ledger not rewritten.

## Next
- 400 hold triangular ripple `sin(t) * minor` separate from the lane
- 401 hold hamiltonian `hScale = major`
- 402 hold default fallthrough sharing the torus tube radius

Numeral `137451921129154222`. No secrets. No root claim.
