# Stage 477 — triangular y sector unread by tAngle (2026-10-07 17:06 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `(this.idx % 3 - 1) * major * 0.5 + Math.sin(t) * minor`
- tAngle is used by x and z only
- four session cases only
- paste not rewritten
