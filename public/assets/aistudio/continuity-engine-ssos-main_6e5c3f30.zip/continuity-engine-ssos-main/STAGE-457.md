# Stage 457 — shared tube y (2026-10-06 18:15 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: infinity y equals torus y
- formula `minor * sin(phi) * sin(t * 0.5 + idx)`
- scale and denom stay off y
- paste not rewritten
- numeral `137451921129154457`
- no secrets, no root claim
