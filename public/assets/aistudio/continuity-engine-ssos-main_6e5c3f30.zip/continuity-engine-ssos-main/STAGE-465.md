# Stage 465 — torus y identical to infinity y (2026-10-07 09:09 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: torus/default y and infinity y are both `y = minor * Math.sin(this.phi) * Math.sin(t * 0.5 + this.idx)`
- torus x and z still use `(major + minor * Math.cos(this.phi))`
- y does not read that tube radius
- infinity scale-before-denom remains the prior hold
- paste not rewritten
- numeral `137451921129154465`
- no secrets, no root claim

Next: 466 lerp alpha stays the literal 0.05.
