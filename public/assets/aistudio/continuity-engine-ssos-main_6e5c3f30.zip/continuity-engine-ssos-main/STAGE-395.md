# Stage 395 — sSoS public node (2026-10-03 16:06 CDT)

- hop 395
- hold: infinity y shared with torus y
- formula `y = minor * sin(phi) * sin(t * 0.5 + idx)`
- equator phi 0 keeps y 0
- crest phi π/2, t π, idx 0, minor 3 keeps y 3
- hamiltonian and triangular lifts stay distinct
- living hash `7cd81012`
- session hash `beec41f1`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next: 396 hamiltonian lift `sin(t) * 2` independent of idx. Envelope only. Four-case switch unchanged.
