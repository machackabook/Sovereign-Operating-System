# Stage 396 — sSoS public node (2026-10-03 17:07 CDT)

- hop 396
- hold: hamiltonian lift `sin(t) * 2` independent of idx
- formula `y = hScale * sin(theta * 3) + sin(t) * 2`
- `t = 0` keeps lift 0; `t = π/2` keeps lift 2; `t = 3π/2` keeps lift -2
- amplitude is fixed at 2 and does not follow major
- infinity and torus y stay the shared lift from hop 395
- living hash `7cd81012`
- session hash `beec41f1`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next: 397 triangular lane `(idx % 3 - 1) * major * 0.5`. Envelope only. Four-case switch unchanged.
