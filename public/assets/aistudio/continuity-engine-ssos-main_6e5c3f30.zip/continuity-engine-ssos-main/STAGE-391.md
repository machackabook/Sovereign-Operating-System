# Stage 391 receipt — major and minor radii (2026-10-03 11:08 CDT)

Mesh receipt only. No hourly waterfall claim. Workflows not touched.

- `major = 10 + idx * 2`
- `minor = 3 + toroidalWeave * 2`
- samples (10, 3), (12, 5), (18, 5.4)
- session hash `beec41f1`
- living hash `7cd81012`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next mesh stage: 392 hold lemniscate denom `1 + sin(theta)^2`.
