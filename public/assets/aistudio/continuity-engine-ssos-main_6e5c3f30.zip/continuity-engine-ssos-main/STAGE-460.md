# Stage 460 — hamiltonian y lift (2026-10-06 19:07 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `y = hScale * sin(theta * 3) + (sin(t) * 2)`
- lift does not multiply hScale
- x and z remain scaled by hScale only
- uGravity remains a copy of gravityPull
- paste not rewritten
- numeral `137451921129154460`
- no secrets, no root claim

Next: 461 lemniscate denom on x and z only.
