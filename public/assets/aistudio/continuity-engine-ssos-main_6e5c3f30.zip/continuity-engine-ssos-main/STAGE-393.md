# Stage 393 — sSoS public node (2026-10-03 14:06 CDT)

- hop 393
- hold: hamiltonian frequency-3 vertex map `theta * 3`
- `hScale = major`
- origin `x = 10` at `theta = 0`, `major = 10`, `t = 0`
- pole `yBase = -10` at `theta = π/2`
- lift `sin(t) * 2` does not read idx
- living hash `7cd81012`
- session hash `beec41f1`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next: 394 triangular sector `2π/3`. Envelope only. Four-case switch unchanged.
