# Stage 478 — shared y tube on infinity and torus only (2026-10-07 17:06 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `minor * Math.sin(this.phi) * Math.sin(t * 0.5 + this.idx)` on infinity y and torus/default y
- hamiltonian and triangular do not use that tube
- four session cases only
- paste not rewritten
