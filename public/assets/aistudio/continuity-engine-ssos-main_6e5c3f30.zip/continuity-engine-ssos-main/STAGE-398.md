# Stage 398 — sSoS public node (2026-10-03 19:09 CDT)

- hop 398
- hold: lemniscate scale `major * 1.5`
- formula `const scale = major * 1.5` on the infinity arm only
- major 10 keeps scale 15; major 12 keeps scale 18; major 14 keeps scale 21
- theta 0, major 10 keeps x 15 and z 0; denom stays 1
- scale does not follow minor, idx, phi, t, or gravityPull
- y stays shared with torus and does not use scale
- hamiltonian hScale remains major (hop 401 will hold that contrast)
- living hash `7cd81012`
- session hash `beec41f1`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next: 399 torus tube radius `major + minor * cos(phi)` against the shared y. Envelope only. Four-case switch unchanged.
