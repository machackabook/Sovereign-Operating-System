# Stage 392 receipt — lemniscate denom (2026-10-03 12:06 CDT)

Mesh receipt only. No hourly waterfall claim. Workflows not touched.

- infinity arm `denom = 1 + sin(theta)^2`
- range `[1, 2]`, division cannot hit zero
- origin denom 1, x 15, z 0
- pole denom 2, x 0, z 0
- quarter denom 1.5
- y does not read denom
- session hash `beec41f1`
- living hash `7cd81012`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next mesh stage: 393 hold hamiltonian frequency-3 map `theta * 3`.
