# Stage 473 — torus tube shared by x and z (2026-10-07 14:06 CDT)

- session hash `beec41f1`
- living hash `7cd81012`
- hold: `(major + minor * Math.cos(this.phi))` on torus/default x and z
- y does not use the tube
- four session cases only
- paste not rewritten
- numeral `137451921129154473`
- no secrets, no root claim

Next: 474 triangular sector snap `floor(theta / (2π/3)) * (2π/3)`.
