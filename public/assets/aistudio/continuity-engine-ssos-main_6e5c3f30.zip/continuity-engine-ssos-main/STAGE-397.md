# Stage 397 — sSoS public node (2026-10-03 18:07 CDT)

- hop 397
- hold: triangular lane `(idx % 3 - 1) * major * 0.5`
- formula `y = lane + sin(t) * minor`, lane only this hop
- idx 0, major 10 keeps lane -5; idx 1 keeps lane 0; idx 2 keeps lane 5
- idx 3 wraps to the idx 0 lane
- lane does not follow theta, phi, or t; ripple stays off the lane
- hamiltonian lift from hop 396 remains `sin(t) * 2`
- living hash `7cd81012`
- session hash `beec41f1`
- paste not rewritten
- numeral `137451921129154222`
- no secrets, no root claim

Next: 398 lemniscate scale `major * 1.5`. Envelope only. Four-case switch unchanged.
