'use client';

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  Activity, 
  Layers, 
  Zap, 
  Database, 
  Terminal, 
  Cpu, 
  Workflow, 
  Box, 
  FolderOpen, 
  Search, 
  Filter, 
  ChevronRight, 
  Shield, 
  Volume2, 
  BarChart3, 
  Share2, 
  Settings, 
  MessageSquare, 
  History, 
  Trash2, 
  Plus, 
  Save, 
  Image as ImageIcon,
  Brain,
  Lightbulb,
  Ghost,
  LogOut,
  RefreshCw,
  X,
  PlusCircle,
  HelpCircle,
  ArrowUpRight,
  ArrowUpAZ,
  ArrowDownZA,
  Mic,
  ArrowDownToLine,
  Users,
  ShieldAlert,
  Send,
  UserCheck,
  Crown,
  Maximize2,
  Wifi,
  WifiOff,
  ArrowLeft,
  CheckSquare,
  Square,
  Clock,
  Calendar,
  Edit3,
  UserPlus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { gateway, TransmissionResult } from '@/lib/gateway';
import { mountSecurityProtocols, deobfuscate, obfuscate } from '@/lib/security';
import { SecureText } from '@/components/SecureText';

// --- Types & Roles ---

enum AgentRole {
  ARCHON = 'ARCHON',
  NEXUS = 'NEXUS',
  SHADOW = 'SHADOW',
  GENIE = 'GENIE'
}

interface Version {
  id: string;
  timestamp: string;
  name?: string;
  prompt?: string;
  author?: string;
}

interface TeamMember {
  userId: string;
  name: string;
  role: 'ADMIN' | 'COLLABORATOR' | 'VIEWER';
  color: string;
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: string;
}

interface Task {
  id: string;
  title: string;
  assignedTo: string;
  status: 'TODO' | 'IN_PROGRESS' | 'DONE';
  deadline?: string;
}

interface Milestone {
  id: string;
  title: string;
  completed: boolean;
  targetDate?: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  worldType: 'SINGULARITY' | 'CHRONOS' | 'SOLARIS' | 'NEURAL_NET';
  archived: boolean;
  currentVersionId: string;
  ownerId: string;
  versions: Version[];
  collaborators: TeamMember[];
  comments: Comment[];
  pipelinePhase?: 'ideation' | 'development' | 'training' | 'deployment';
  tasks?: Task[];
  milestones?: Milestone[];
  prompt?: string;
}

interface SystemUser {
  id: string;
  name: string;
  role: 'ADMIN' | 'COLLABORATOR' | 'VIEWER';
  color: string;
  cursor?: { x: number; y: number };
  activeProjectId?: string | null;
}

// Side Navigation Icons
const SidebarIcon = ({ icon: Icon, active, label, onClick }: { icon: any, active?: boolean, label: string, onClick?: () => void }) => (
  <button 
    onClick={onClick}
    className={`p-3 rounded-xl transition-all duration-300 group relative ${
      active 
        ? 'bg-cyan-500/10 text-cyan-500 shadow-[0_0_20px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/30' 
        : 'text-[#71717a] hover:bg-[#18181b] hover:text-white'
    }`}
  >
    <Icon className="w-5 h-5" />
    <span className="absolute left-16 px-2 py-1 bg-neutral-800 text-xs text-neutral-200 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest font-bold">
      {label}
    </span>
  </button>
);

const PipelineProgress = ({ activeTab }: { activeTab: string }) => (
  <div className="flex items-center gap-1 px-4 h-full border-l border-[#27272a] bg-[#18181b]/30">
    <div className="text-[8px] font-black tracking-[0.2em] text-[#71717a] mr-2">PIPELINE:</div>
    {[
      { t: 'flow', label: 'IDEATE' },
      { t: 'genie', label: 'SYNTHESIZE' },
      { t: 'deepmind', label: 'DEPLOY' }
    ].map((step, i) => (
      <React.Fragment key={step.t}>
        <div className={`text-[8px] font-black tracking-[0.2em] px-2 py-0.5 rounded ${activeTab === step.t ? 'text-cyan-400 bg-cyan-400/10' : 'text-[#3f3f46]'}`}>
          {step.label}
        </div>
        {i < 2 && <ChevronRight className="w-2.5 h-2.5 text-[#27272a] mx-1" />}
      </React.Fragment>
    ))}
  </div>
);

// --- Sub-components (Moved inside to support callbacks or defined separately with precise types) ---

const TelemetryCard = ({ label, value, color }: { label: string, value: string, color: string }) => (
  <div className="bg-[#18181b] p-3 rounded-lg border border-[#27272a] flex flex-col gap-1">
    <span className="text-[8px] font-black text-[#71717a] tracking-widest">{label}</span>
    <span className={`text-[10px] font-mono flex items-center gap-1 font-bold ${color}`}>
       {value}
    </span>
  </div>
);

const StatBar = ({ label, value, percent, color }: { label: string, value: string, percent: number, color: string }) => (
  <div className="space-y-2">
    <div className="flex justify-between items-end">
      <span className="text-[9px] font-bold text-[#71717a] uppercase tracking-widest">{label}</span>
      <span className="text-[10px] font-mono text-white font-bold">{value}</span>
    </div>
    <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
       <motion.div 
         initial={{ width: 0 }}
         animate={{ width: `${percent}%` }}
         transition={{ duration: 1 }}
         className={`h-full ${color}`} 
       />
    </div>
  </div>
);

export default function NexusStudio() {
  // Navigation & UI States
  const [activeTab, setActiveTab] = useState('flow');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [turboMode, setTurboMode] = useState(false);
  const [showStatsOverlay, setShowStatsOverlay] = useState(false);
  const [optimizationLevel, setOptimizationLevel] = useState<'STANDARD' | 'LOW_LATENCY' | 'SUPERGAUSSIAN_MAX'>('STANDARD');
  const [lastResponseMetadata, setLastResponseMetadata] = useState<TransmissionResult['metadata'] | null>(null);

  // Filters & Sorting
  const [projectSearchQuery, setProjectSearchQuery] = useState('');
  const [projectViewMode, setProjectViewMode] = useState<'active' | 'archived'>('active');
  const [projectSortBy, setProjectSortBy] = useState<'name' | 'worldType' | 'currentVersionId'>('name');
  const [projectSortOrder, setProjectSortOrder] = useState<'asc' | 'desc'>('asc');

  // Multi-user & Persistent Socket States
  const [projects, setProjects] = useState<Project[]>([]);
  const [globalChat, setGlobalChat] = useState<any[]>([]);
  const [onlineUsers, setOnlineUsers] = useState<SystemUser[]>([]);
  const [currentUser, setCurrentUser] = useState<SystemUser | null>(null);
  const [socketConnected, setSocketConnected] = useState(false);
  const [logs, setLogs] = useState<{ t: string, m: string, type?: 'info' | 'success' | 'warn' }[]>([]);
  const [reconnectCount, setReconnectCount] = useState(0);

  // User Profile Setup Dialog State
  const [showIdentityModal, setShowIdentityModal] = useState(true);
  const [customUsername, setCustomUsername] = useState('Architect_M');
  const [customUserRole, setCustomUserRole] = useState<'ADMIN' | 'COLLABORATOR' | 'VIEWER'>('ADMIN');
  const [customColor, setCustomColor] = useState('#06b6d4');

  // Permission Admin modal state
  const [permissionTargetProject, setPermissionTargetProject] = useState<Project | null>(null);
  const [currentCollaborators, setCurrentCollaborators] = useState<TeamMember[]>([]);
  const [inviteCollabName, setInviteCollabName] = useState('');
  const [inviteCollabRole, setInviteCollabRole] = useState<'ADMIN' | 'COLLABORATOR' | 'VIEWER'>('COLLABORATOR');

  // Project creator modal state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectWorld, setNewProjectWorld] = useState<'SINGULARITY' | 'CHRONOS' | 'SOLARIS' | 'NEURAL_NET'>('NEURAL_NET');

  // Project Comments sidebar state
  const [targetCommentsProject, setTargetCommentsProject] = useState<Project | null>(null);
  const [newCommentInput, setNewCommentInput] = useState('');

  // Local Genie state (specific message thread for current terminal connection)
  const [genieInput, setGenieInput] = useState('');
  const [genieMessages, setGenieMessages] = useState<{ role: 'user' | 'agent' | 'system', content: string, senderName?: string, timestamp?: string }[]>([]);

  // DeepMind open-source pipeline states
  const [deepmindResources, setDeepmindResources] = useState<any[]>([]);
  const [selectedResourceId, setSelectedResourceId] = useState<string>('dm-alphafold');
  const [deepmindInput, setDeepmindInput] = useState<string>('');
  const [deepmindProcessing, setDeepmindProcessing] = useState<boolean>(false);
  const [deepmindResult, setDeepmindResult] = useState<any | null>(null);
  const [syncTargetProjectId, setSyncTargetProjectId] = useState<string>('');

  const socketRef = useRef<WebSocket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastCursorSend = useRef<number>(0);

  // Helper log pipeline
  const addLog = useCallback((m: string, type: 'info' | 'success' | 'warn' = 'info') => {
    const timestamp = new Date().toLocaleTimeString('en-GB', { hour12: false });
    setLogs(prev => [{ t: timestamp, m, type }, ...prev].slice(0, 50));
  }, []);

  // Fetch DeepMind resources on mount
  useEffect(() => {
    const fetchDMResources = async () => {
      try {
        const res = await fetch('/api/deepmind');
        const data = await res.json();
        if (Array.isArray(data)) {
          setDeepmindResources(data);
          const defaultRes = data.find(r => r.id === 'dm-alphafold');
          if (defaultRes) {
            setDeepmindInput(defaultRes.sampleInput);
          }
        }
      } catch (err) {
        console.error("Failed to load DeepMind resources list from internal route", err);
      }
    };
    fetchDMResources();
  }, []);

  const handleSelectResource = (resourceId: string) => {
    setSelectedResourceId(resourceId);
    setDeepmindResult(null); // Clear previous results when changing resource type
    const found = deepmindResources.find(r => r.id === resourceId);
    if (found) {
      setDeepmindInput(found.sampleInput);
    }
  };

  const handleProcessDeepMind = async () => {
    if (!deepmindInput.trim() || !selectedResourceId) return;
    setDeepmindProcessing(true);
    addLog(`Initiating DeepMind open-source pipeline request for ${selectedResourceId}...`, 'info');
    
    try {
      const res = await fetch('/api/deepmind', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resourceId: selectedResourceId, payload: deepmindInput })
      });
      const data = await res.json();
      
      if (data.success) {
        setDeepmindResult(data);
        addLog(`DeepMind pipeline complete! Execution duration: ${data.processTimeMs}ms`, 'success');
      } else {
        addLog(`Resource processing failure: ${data.error || 'Unknown error'}`, 'warn');
      }
    } catch (err: any) {
      addLog(`Internal network bridge timeouts or failure. Details: ${err.message}`, 'warn');
    } finally {
      setDeepmindProcessing(false);
    }
  };

  const handleSyncToProject = () => {
    if (!deepmindResult || !syncTargetProjectId) {
      addLog("Please select a target Project before synchronization.", "warn");
      return;
    }
    const targetProj = projects.find(p => p.id === syncTargetProjectId);
    if (!targetProj) {
      addLog("Selected synchronization target project node not found.", "warn");
      return;
    }

    // Submit a comment report to this project via websocket so the entire multi-user studio sees the pipeline updates
    if (socketConnected && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'project:comment',
        data: {
          id: targetProj.id,
          content: `Synced DeepMind Pipeline output [${deepmindResult.resourceId}]: ${deepmindResult.result.summary}`
        }
      }));
      addLog(`Synchronized calculation metrics for ${targetProj.name} successfully.`, "success");
    } else {
      // Offline fallback: append commenting directly
      const fallbackComment = {
        id: 'c-fallback-' + Math.random().toString(36).substring(2, 9),
        userId: currentUser?.id || 'FALLBACK_UID',
        userName: currentUser?.name || 'SYNC_CLIENT',
        content: `Synced DeepMind Pipeline output [${deepmindResult.resourceId}]: ${deepmindResult.result.summary}`,
        timestamp: new Date().toISOString()
      };
      setProjects(prev => {
        const list = prev.map(p => {
          if (p.id === targetProj.id) {
            return {
              ...p,
              comments: [...(p.comments || []), fallbackComment]
            };
          }
          return p;
        });
        return list;
      });
      addLog(`Synchronized calculation metrics for ${targetProj.name} locally.`, "success");
    }
  };

  // Set up WebSocket Sync Connection
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Connect to WebSocket server running on same port
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/ws`;

    addLog(`Establishing connection to Synchronous Bridge...`, 'info');
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setSocketConnected(true);
      addLog(`Sub-channel connection established successfully.`, 'success');
    };

    ws.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        switch (payload.type) {
          case 'sync': {
            setProjects(payload.data.projects);
            setGlobalChat(payload.data.globalChat);
            setOnlineUsers(payload.data.users);
            setCurrentUser(payload.data.currentUser);
            addLog(`Full system state synchronized successfully.`, 'success');
            break;
          }
          case 'user:joined': {
            addLog(`Team Member joined: ${payload.data.name} [${payload.data.role}]`, 'info');
            break;
          }
          case 'user:left': {
            addLog(`Team Member disconnected [ID: ${payload.data}]`, 'warn');
            break;
          }
          case 'users:update': {
            setOnlineUsers(payload.data);
            break;
          }
          case 'cursor:moved': {
            // Live cursors are updated in onlineUsers real-time
            setOnlineUsers(prev => prev.map(usr => {
              if (usr.id === payload.data.userId) {
                return {
                  ...usr,
                  cursor: payload.data.cursor,
                  activeProjectId: payload.data.activeProjectId
                };
              }
              return usr;
            }));
            break;
          }
          case 'project:created': {
            setProjects(payload.data.projects);
            addLog(`New AI Pipeline deployed: ${payload.data.project.name}`, 'success');
            break;
          }
          case 'project:updated': {
            setProjects(payload.data.projects);
            // Sync current permission target if updated
            setPermissionTargetProject(prev => {
              if (prev && prev.id === payload.data.project.id) {
                setCurrentCollaborators(payload.data.project.collaborators);
                return payload.data.project;
              }
              return prev;
            });
            // Update comments target if updated
            setTargetCommentsProject(prev => {
              if (prev && prev.id === payload.data.project.id) {
                return payload.data.project;
              }
              return prev;
            });
            addLog(`AI Pipeline updated: ${payload.data.project.name}`, 'info');
            break;
          }
          case 'chat:message': {
            setGlobalChat(payload.data.globalChat);
            // Append back to live genie messages if appropriate
            const originMsg = payload.data.message;
            setGenieMessages(prev => [
              ...prev,
              { 
                role: 'system', 
                content: `[Broadcast] ${originMsg.userName}: ${originMsg.content}`,
                senderName: originMsg.userName,
                timestamp: originMsg.timestamp
              }
            ]);
            break;
          }
          case 'error': {
            addLog(`Error transmission received: ${payload.data}`, 'warn');
            break;
          }
          default:
            break;
        }
      } catch (e) {
        console.error('Bridge parsing error:', e);
      }
    };

    ws.onclose = () => {
      setSocketConnected(false);
      addLog(`Synchronous Bridge closed. Triggering backup frequency.`, 'warn');
      // Exponential automatic reconnect rules
      const timer = setTimeout(() => {
        setReconnectCount(prev => prev + 1);
      }, Math.min(1000 * Math.pow(2, reconnectCount), 15000));
      return () => clearTimeout(timer);
    };

    return () => {
      ws.close();
      socketRef.current = null;
    };
  }, [reconnectCount]);

  // Transmit Profile Information once customized
  const handleCompleteIdentity = () => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;
    
    socketRef.current.send(JSON.stringify({
      type: 'init',
      data: {
        name: customUsername,
        role: customUserRole,
        color: customColor
      }
    }));
    
    setShowIdentityModal(false);
    addLog(`Synched custom index: ${customUsername} [${customUserRole}]`, 'success');
  };

  // Cursor move reporting to other concurrent sessions
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!socketConnected || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;
    
    // Throttle cursor messages to 50ms (25 FPS) for stellar high-frequency network performance
    const now = Date.now();
    if (now - lastCursorSend.current < 40) return;
    lastCursorSend.current = now;

    // Get position relative to the main container
    const bounds = containerRef.current?.getBoundingClientRect();
    if (!bounds) return;

    const x = parseFloat(((e.clientX - bounds.left) / bounds.width).toFixed(4));
    const y = parseFloat(((e.clientY - bounds.top) / bounds.height).toFixed(4));

    socketRef.current.send(JSON.stringify({
      type: 'cursor:move',
      data: {
        cursor: { x, y },
        activeProjectId: activeProjectId
      }
    }));
  }, [socketConnected, activeProjectId]);

  // Sync active project state immediately when user enters/exits project workroom
  useEffect(() => {
    if (socketConnected && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'cursor:move',
        data: {
          cursor: { x: 0, y: 0 },
          activeProjectId: activeProjectId
        }
      }));
    }
  }, [activeProjectId, socketConnected]);

  // Send generalized project property updates over websocket/locally
  const handleUpdateProject = (pId: string, updates: Partial<Project>) => {
    if (socketConnected && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'project:update',
        data: {
          id: pId,
          ...updates
        }
      }));
    } else {
      setProjects(prev => prev.map(p => p.id === pId ? { ...p, ...updates } : p));
    }
  };

  // Submit live Genie transmission requests or peer chat
  const handleSendGenie = async () => {
    if (!genieInput.trim()) return;

    const userMsg = genieInput;
    setGenieInput('');
    
    // 1. Add locally
    setGenieMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsThinking(true);
    addLog(`Synthesizing commands through neural nodes...`, 'info');

    // 2. Broadcast via standard multi-user global chat channel as well!
    if (socketConnected && socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'chat:send',
        data: {
          content: userMsg
        }
      }));
    }

    try {
      const response = await gateway.transmit({
        prompt: userMsg,
        optimization: optimizationLevel === 'SUPERGAUSSIAN_MAX' ? 'SUPERGAUSSIAN' : 
                      optimizationLevel === 'LOW_LATENCY' ? 'VACUUM_STATE' : 'STANDARD',
        priority: turboMode ? 'LATENCY' : 'REASONING',
        authToken: `DM_ALPHAFOLD_SYNC_${Math.random().toString(36).substring(7).toUpperCase()}`
      });
      
      setGenieMessages(prev => [...prev, { role: 'agent', content: response.content }]);
      setLastResponseMetadata(response.metadata);
      addLog(`AI Synthesis Complete. Packet Size: ${response.metadata.packetSize}`, 'success');
    } catch (error) {
      addLog(`AI Synthesis connection timed out. Interface operating under local fallback.`, 'warn');
    } finally {
      setIsThinking(false);
    }
  };

  // Create Project Dispatch
  const handleCreateProject = () => {
    if (!newProjectName.trim()) return;
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      addLog(`Cannot construct node: offline fallback.`, 'warn');
      return;
    }

    socketRef.current.send(JSON.stringify({
      type: 'project:create',
      data: {
        name: newProjectName,
        description: newProjectDesc || 'No details provided.',
        worldType: newProjectWorld,
        currentVersionId: 'v1.0.0'
      }
    }));

    // Reset state
    setNewProjectName('');
    setNewProjectDesc('');
    setShowCreateModal(false);
  };

  // Update permissions modal state
  const handleOpenPermissions = (proj: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setPermissionTargetProject(proj);
    setCurrentCollaborators(proj.collaborators || []);
  };

  // Save updated collaborators & permission levels
  const handleSavePermissions = () => {
    if (!permissionTargetProject || !socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;

    socketRef.current.send(JSON.stringify({
      type: 'project:permissions',
      data: {
        id: permissionTargetProject.id,
        collaborators: currentCollaborators
      }
    }));

    setPermissionTargetProject(null);
    setInviteCollabName('');
    addLog(`Quantum permission vectors updated successfully.`, 'success');
  };

  // Invite user to collaboration roles
  const handleAddCollaborator = () => {
    if (!inviteCollabName.trim()) return;
    
    const roleColors = ['#06b6d4', '#ec4899', '#8b5cf6', '#10b981', '#f59e0b', '#3b82f6'];
    const newCollab: TeamMember = {
      userId: 'USR_INV_' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      name: inviteCollabName,
      role: inviteCollabRole,
      color: roleColors[Math.floor(Math.random() * roleColors.length)]
    };

    setCurrentCollaborators(prev => [...prev, newCollab]);
    setInviteCollabName('');
    addLog(`Colleague added: ${inviteCollabName} queued as ${inviteCollabRole}`, 'info');
  };

  // Remove collaborator
  const handleRemoveCollaborator = (userId: string) => {
    setCurrentCollaborators(prev => prev.filter(c => c.userId !== userId));
  };

  // Change individual user permissions
  const handleChangeRole = (userId: string, newRole: 'ADMIN' | 'COLLABORATOR' | 'VIEWER') => {
    setCurrentCollaborators(prev => prev.map(c => {
      if (c.userId === userId) {
        return { ...c, role: newRole };
      }
      return c;
    }));
  };

  // Post single comment
  const handleAddComment = () => {
    if (!newCommentInput.trim() || !targetCommentsProject) return;
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;

    socketRef.current.send(JSON.stringify({
      type: 'project:comment',
      data: {
        id: targetCommentsProject.id,
        content: newCommentInput
      }
    }));

    setNewCommentInput('');
  };

  // Scroll comment list
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [genieMessages, targetCommentsProject?.comments]);

  // Sorting logic
  const sortedProjects = useMemo(() => {
    return projects
      .filter(p => projectViewMode === 'active' ? !p.archived : p.archived)
      .filter(p => {
        const query = projectSearchQuery.toLowerCase();
        return p.name.toLowerCase().includes(query) || p.description.toLowerCase().includes(query);
      })
      .sort((a, b) => {
        const field = projectSortBy;
        const order = projectSortOrder === 'asc' ? 1 : -1;
        const valA = a[field] || '';
        const valB = b[field] || '';
        if (valA < valB) return -1 * order;
        if (valA > valB) return 1 * order;
        return 0;
      });
  }, [projects, projectViewMode, projectSearchQuery, projectSortBy, projectSortOrder]);

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="flex h-screen w-full overflow-hidden font-sans bg-[#09090b] text-neutral-300 select-none relative"
    >
      {/* Dynamic Multi-user Live Cursor Overlays */}
      {socketConnected && onlineUsers.map(usr => {
        if (!usr.cursor || usr.id === currentUser?.id) return null;
        
        // Translate relative percentages to the current browser viewport bounds
        return (
          <div 
            key={usr.id}
            style={{ 
              left: `${usr.cursor.x * 100}%`, 
              top: `${usr.cursor.y * 100}%`,
              transition: 'all 0.08s cubic-bezier(0.1, 0.8, 0.3, 1)'
            }}
            className="absolute z-[9999] pointer-events-none flex flex-col items-start gap-1"
          >
            {/* Custom styled glowing cursor pointer */}
            <svg 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              style={{ color: usr.color }}
              className="drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] filter"
            >
              <path 
                d="M5.65376 12.3962L15.9392 3.11181C16.4801 2.62413 17.3197 3.03378 17.2884 3.75924L16.8911 12.9818C16.8529 13.8698 17.8596 14.4371 18.5283 13.8549L20.446 12.1843C20.8996 11.7892 21.5721 12.1154 21.5721 12.7214V17.0674C21.5721 17.5855 21.2188 18.0336 20.716 18.1519L5.43958 21.7589C4.83296 21.9021 4.29851 21.328 4.49257 20.7388L5.65376 12.3962Z" 
                fill="currentColor"
                stroke="white"
                strokeWidth="1.5"
              />
            </svg>
            <div 
              style={{ backgroundColor: usr.color }}
              className="px-2 py-1 rounded text-[9px] font-black tracking-widest text-[#09090b] uppercase shadow-[0_4px_12px_rgba(0,0,0,0.4)] whitespace-nowrap"
            >
              {usr.name} {usr.activeProjectId ? `(${usr.activeProjectId})` : ''}
            </div>
          </div>
        );
      })}

      {/* Sidebar Navigation */}
      <aside className="w-20 border-r border-[#27272a] bg-[#09090b] flex flex-col items-center py-6 gap-8 z-50">
        <div className="w-10 h-10 rounded-2xl bg-cyan-600 flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] animate-pulse-cyan">
          <Workflow className="w-6 h-6 text-white" />
        </div>
        
        <div className="flex flex-col gap-4 flex-1">
          <SidebarIcon icon={Zap} active={activeTab === 'flow'} label="Slingshot Flow" onClick={() => setActiveTab('flow')} />
          <SidebarIcon icon={Brain} active={activeTab === 'genie'} label="Creation Genie" onClick={() => setActiveTab('genie')} />
          <SidebarIcon icon={Database} active={activeTab === 'deepmind'} label="DeepMind Registry" onClick={() => setActiveTab('deepmind')} />
          <SidebarIcon icon={History} active={activeTab === 'docs'} label="Documentation" onClick={() => setActiveTab('docs')} />
          <SidebarIcon icon={FolderOpen} active={activeTab === 'projects'} label="Projects" onClick={() => setActiveTab('projects')} />
        </div>

        <div className="mt-auto flex flex-col gap-4">
          <SidebarIcon icon={BarChart3} active={showStatsOverlay} label="Telemetry Overlay" onClick={() => setShowStatsOverlay(!showStatsOverlay)} />
          <button 
            onClick={() => setShowIdentityModal(true)}
            className="p-3 rounded-xl transition-all hover:bg-[#18181b] text-cyan-500 group relative ring-1 ring-white/5"
            style={{ color: currentUser?.color }}
          >
            <Users className="w-5 h-5 animate-pulse" />
            <span className="absolute left-16 px-2 py-1 bg-neutral-800 text-xs text-neutral-200 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest font-bold">
              My Profile
            </span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#09090b] relative">
        {/* Header Bar */}
        <header className="h-14 border-b border-[#27272a] bg-[#09090b]/85 backdrop-blur-md flex items-center justify-between px-6 z-40">
          <div className="flex items-center gap-4">
            <h1 className="text-sm font-black tracking-[0.3em] text-white uppercase flex items-center gap-2">
              Nexus AI Studio <span className="text-[#a1a1aa] font-medium opacity-50">//</span> <span className="text-cyan-500">Pipeline_Sync</span>
            </h1>
            <PipelineProgress activeTab={activeTab} />
          </div>
          
          <div className="flex items-center gap-4">
            {/* Simulate Offline Locally */}
            <button
              onClick={() => {
                setSocketConnected(prev => !prev);
                addLog(`Toggled local connection link state simulation to ${!socketConnected ? 'ONLINE' : 'OFFLINE'}.`, 'info');
              }}
              className={`px-3 py-1 text-[9px] font-black uppercase tracking-widest border rounded-full flex items-center gap-1.5 transition-all cursor-pointer ${
                socketConnected 
                  ? 'bg-neutral-800/80 border-neutral-700/80 hover:bg-neutral-700 hover:border-neutral-600 text-neutral-300' 
                  : 'bg-cyan-500/10 border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400 font-bold'
              }`}
              title={socketConnected ? "Simulate offline mode to test UI fallback state" : "End simulation and reconnect online simulated state"}
            >
              {socketConnected ? (
                <>
                  <WifiOff className="w-3 h-3 text-red-400" />
                  Simulate Offline
                </>
              ) : (
                <>
                  <Wifi className="w-3 h-3 text-emerald-400 animate-pulse" />
                  Simulate Online
                </>
              )}
            </button>

            {/* Live Synchronizer Presence Indicator */}
            {socketConnected ? (
              <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[9px] font-black tracking-widest text-emerald-400 uppercase">
                  Connected: {onlineUsers.length} Online
                </span>
              </div>
            ) : (
              <div className="px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full flex items-center gap-2">
                <span className="relative flex h-2 w-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-[9px] font-black tracking-widest text-red-400 uppercase">Offline Fallback</span>
              </div>
            )}

            <div className="text-xs font-mono flex items-center gap-2 border-l border-[#27272a] pl-4">
              <span className="text-neutral-500">INDEX:</span>
              <span className="text-cyan-500 font-bold" style={{ color: currentUser?.color }}>
                {currentUser?.name || 'SYNC_CLIENT'}
              </span>
              <span className="text-[9px] px-1.5 py-0.5 bg-cyan-500/10 text-cyan-400 rounded-md font-sans uppercase font-bold tracking-wider">
                {currentUser?.role || 'COLLABORATOR'}
              </span>
            </div>
          </div>
        </header>

        {/* View Content */}
        <main className="flex-1 overflow-hidden flex">
          <AnimatePresence mode="wait">
            <motion.div 
              key={activeTab + (activeProjectId ? '_' + activeProjectId : '')}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex-1 h-full flex flex-col min-w-0"
            >
              {activeTab === 'flow' && (
                activeProjectId ? (
                  <ProjectWorkspace 
                    projectId={activeProjectId}
                    projects={projects}
                    currentUser={currentUser}
                    onlineUsers={onlineUsers}
                    onBack={() => setActiveProjectId(null)}
                    onUpdateProject={(updates) => handleUpdateProject(activeProjectId, updates)}
                    onOpenComments={(p) => setTargetCommentsProject(p)}
                  />
                ) : (
                  <FlowView 
                    projects={sortedProjects} 
                    onCreateClick={() => setShowCreateModal(true)} 
                    onConfigurePermissions={handleOpenPermissions}
                    onOpenComments={(p) => setTargetCommentsProject(p)}
                    onCardClick={(proj) => setActiveProjectId(proj.id)}
                    onExportProject={(proj, e) => {
                      e.stopPropagation();
                      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(proj, null, 2));
                      const downloadAnchor = document.createElement('a');
                      downloadAnchor.setAttribute("href", dataStr);
                      downloadAnchor.setAttribute("download", `${proj.name.toLowerCase().trim().replace(/[^a-z0-9]/g, '_')}_metadata.json`);
                      document.body.appendChild(downloadAnchor);
                      downloadAnchor.click();
                      downloadAnchor.remove();
                      addLog(`Successfully exported project metadata: ${proj.name}`, 'success');
                    }}
                  />
                )
              )}
              {activeTab === 'projects' && (
                activeProjectId ? (
                  <ProjectWorkspace 
                    projectId={activeProjectId}
                    projects={projects}
                    currentUser={currentUser}
                    onlineUsers={onlineUsers}
                    onBack={() => setActiveProjectId(null)}
                    onUpdateProject={(updates) => handleUpdateProject(activeProjectId, updates)}
                    onOpenComments={(p) => setTargetCommentsProject(p)}
                  />
                ) : (
                  <ProjectsView 
                    projects={sortedProjects} 
                    search={projectSearchQuery} 
                    setSearch={setProjectSearchQuery}
                    viewMode={projectViewMode}
                    setViewMode={setProjectViewMode}
                    sortBy={projectSortBy}
                    setSortBy={setProjectSortBy}
                    sortOrder={projectSortOrder}
                    setSortOrder={setProjectSortOrder}
                    onConfigurePermissions={handleOpenPermissions}
                    onOpenComments={(p) => setTargetCommentsProject(p)}
                    onCardClick={(proj) => setActiveProjectId(proj.id)}
                  />
                )
              )}
              {activeTab === 'genie' && (
                <GenieView 
                  messages={genieMessages} 
                  onSend={handleSendGenie} 
                  input={genieInput} 
                  setInput={setGenieInput} 
                  isThinking={isThinking} 
                  scrollRef={scrollRef} 
                  optimizationLevel={optimizationLevel} 
                  setOptimizationLevel={setOptimizationLevel} 
                />
              )}
              {activeTab === 'deepmind' && (
                <DeepMindView 
                  resources={deepmindResources}
                  selectedId={selectedResourceId}
                  onSelect={handleSelectResource}
                  input={deepmindInput}
                  setInput={setDeepmindInput}
                  processing={deepmindProcessing}
                  onProcess={handleProcessDeepMind}
                  result={deepmindResult}
                  projects={projects}
                  syncProjectId={syncTargetProjectId}
                  setSyncProjectId={setSyncTargetProjectId}
                  onSync={handleSyncToProject}
                />
              )}
              {activeTab === 'docs' && (
                <div className="flex-1 flex flex-col items-center justify-center text-[#3f3f46] p-12">
                   <Ghost className="w-12 h-12 mb-4 opacity-20" />
                   <h2 className="text-xl font-bold uppercase tracking-widest">Portal Restricted</h2>
                   <p className="text-xs mt-2 uppercase font-mono tracking-widest">DM_Secure_Key Required for Node Initialization</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Right Sidebar - Telemetry & Active Team List */}
          <aside className="w-72 border-l border-[#27272a] bg-[#09090b] flex flex-col overflow-hidden shrink-0 z-10">
             {/* Telemetry Dashboard */}
             <div className="p-4 border-b border-[#27272a]">
               <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#71717a] mb-4 flex items-center justify-between">
                 Slingshot Telemetry
                 <span className="text-cyan-500 text-[8px] animate-pulse">LIVE</span>
               </h3>
               <div className="grid grid-cols-2 gap-2">
                 <TelemetryCard label="LATENCY" value={`${lastResponseMetadata?.latency?.toFixed(4) || '0.002'}ms`} color="text-blue-400" />
                 <TelemetryCard label="SYNC_QoS" value={lastResponseMetadata?.qos?.toFixed(2) || '0.99'} color="text-emerald-400" />
                 <TelemetryCard label="TX_THRUST" value={`${lastResponseMetadata?.transmissionSpeed?.toFixed(2) || '1.64'} T/s`} color="text-purple-400" />
                 <TelemetryCard label="SYS_NODE" value={lastResponseMetadata?.node || 'NODE_ALPHA'} color="text-cyan-400" />
               </div>
             </div>

             {/* Team & Collaboration Status */}
             <div className="p-4 border-b border-[#27272a] bg-[#121214]/20 flex flex-col">
               <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#71717a] mb-3 flex items-center justify-between">
                 Active Synchronizers
                 <span className="text-neutral-500">({onlineUsers.length})</span>
               </h3>
               <div className="space-y-2 max-h-44 overflow-y-auto custom-scrollbar pr-1">
                 {onlineUsers.map(usr => (
                   <div key={usr.id} className="flex items-center justify-between p-2 rounded-lg bg-white/5 border border-white/5">
                     <div className="flex items-center gap-2">
                       <span className="w-2 h-2 rounded-full animate-pulse shrink-0" style={{ backgroundColor: usr.color }} />
                       <div className="flex flex-col">
                         <span className="text-[10px] font-black text-white uppercase truncate max-w-[120px]">{usr.name} {usr.id === currentUser?.id ? '(You)' : ''}</span>
                         <span className="text-[8px] text-[#71717a] font-mono tracking-tight">{usr.role}</span>
                       </div>
                     </div>
                     <span className="text-[8px] font-mono px-1.5 py-0.5 bg-neutral-800 text-neutral-400 rounded">
                       {usr.activeProjectId ? `IN: ${usr.activeProjectId}` : 'OFFLINE'}
                     </span>
                   </div>
                 ))}
               </div>
             </div>

             {/* Log Stream Pipeline */}
             <div className="flex-1 p-4 flex flex-col overflow-hidden">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#71717a] mb-4">Pipeline Protocol Stream</h3>
                <div className="flex-1 space-y-2 overflow-y-auto custom-scrollbar font-mono text-[9px] pr-2">
                  {logs.map((log, i) => (
                    <div key={i} className="flex gap-2 leading-tight">
                       <span className="text-[#3f3f46] shrink-0">[{log.t}]</span>
                       <span className={log.type === 'success' ? 'text-emerald-500' : log.type === 'warn' ? 'text-orange-500' : 'text-[#71717a]'}>
                         {log.m}
                       </span>
                    </div>
                  ))}
                  {logs.length === 0 && <div className="text-[#3f3f46] italic">Awaiting node heartbeat...</div>}
                </div>
             </div>
          </aside>
        </main>

        {/* Footer Stats Bar */}
        <footer className="h-10 border-t border-[#27272a] bg-[#0c0c0e] flex items-center px-4 justify-between shrink-0 z-30">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold text-[#71717a] uppercase tracking-widest">Amalgamation:</span>
              <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-widest">Synchronized</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9px] text-[#71717a] font-mono tracking-tighter capitalize">Vacuum Protocol Stable</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4 text-[#71717a] font-mono text-[9px]">
            <span>PKT: {lastResponseMetadata?.packetSize || '0.24 KB'}</span>
            <span>SID: {currentUser?.id || '0x0000'}</span>
            <div className="h-4 w-[1px] bg-[#27272a]" />
            <span className="text-white">v1.1.0-ULTRA_SYNC</span>
          </div>
        </footer>
      </div>

      {/* Floating System Stats Overlay */}
      <AnimatePresence>
        {showStatsOverlay && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed bottom-16 right-72 mr-6 w-80 bg-[#121214]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl z-[100]"
          >
            <div className="flex items-center justify-between mb-6">
               <h3 className="text-xs font-black tracking-[0.2em] text-white uppercase">Neural Matrix Overview</h3>
               <button onClick={() => setShowStatsOverlay(false)} className="text-[#71717a] hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            
            <div className="space-y-6">
              <StatBar label="Dimensional Stability" value="99.98%" percent={99.98} color="bg-cyan-500" />
              <StatBar label="Flow Harmonics" value="Order 4" percent={85} color="bg-purple-500" />
              <StatBar label="Packet Refraction" value="Lossless" percent={100} color="bg-emerald-500" />
            </div>
            
            <div className="mt-8 pt-6 border-t border-[#27272a] flex justify-between items-center">
              <div className="flex flex-col">
                 <span className="text-[9px] text-[#71717a] uppercase font-bold tracking-widest">Active Engines</span>
                 <span className="text-xs text-white font-bold font-mono">{onlineUsers.length} Synchronized</span>
              </div>
              <button 
                onClick={() => setTurboMode(!turboMode)}
                className={`px-4 py-2 rounded-lg text-[10px] font-black tracking-widest uppercase transition-all ${
                  turboMode ? 'bg-orange-600 text-white shadow-[0_0_20px_rgba(234,88,12,0.3)]' : 'bg-white/5 text-[#71717a]'
                }`}
              >
                Slingshot Overclock
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Profile / Synchronizer Identity Setup Overlay */}
      <AnimatePresence>
        {showIdentityModal && (
          <div className="fixed inset-0 bg-[#000000]/80 backdrop-blur-md z-[9999] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#121214] border border-white/10 rounded-2xl p-6 shadow-2xl relative"
            >
              <h2 className="text-lg font-black tracking-[0.2em] text-white uppercase mb-1">
                Quantum Identity Sync
              </h2>
              <p className="text-xs text-[#71717a] uppercase font-mono tracking-widest mb-6">
                Map client node with neural spectrum profile
              </p>

              <div className="space-y-4">
                {/* Username Input */}
                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">
                    Codenm / Synchronizer Handle
                  </label>
                  <input 
                    type="text" 
                    value={customUsername} 
                    onChange={(e) => setCustomUsername(e.target.value)}
                    className="w-full bg-[#1c1c1f] border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                {/* Role selection */}
                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">
                    Security Authorization Level
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['ADMIN', 'COLLABORATOR', 'VIEWER'].map((role) => (
                      <button
                        key={role}
                        type="button"
                        onClick={() => setCustomUserRole(role as any)}
                        className={`py-2 rounded-xl text-[10px] font-bold tracking-widest uppercase transition-all ${
                          customUserRole === role 
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30' 
                            : 'bg-white/5 text-[#71717a] hover:bg-white/10 border border-transparent'
                        }`}
                      >
                        {role}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Scheme Picker */}
                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">
                    Spectrum Glow Signature
                  </label>
                  <div className="flex gap-3 justify-center py-2 bg-white/5 rounded-xl">
                    {['#06b6d4', '#ec4899', '#8b5cf6', '#10b981', '#f59e0b', '#3b82f6'].map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setCustomColor(color)}
                        style={{ backgroundColor: color }}
                        className={`w-8 h-8 rounded-full transition-transform ${
                          customColor === color ? 'ring-4 ring-white scale-110' : 'hover:scale-105'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-8 flex gap-3">
                <button
                  type="button"
                  onClick={handleCompleteIdentity}
                  className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-[11px] font-black tracking-[0.2em] transition-all uppercase shadow-[0_0_20px_rgba(6,182,212,0.3)]"
                >
                  DEACTIVATE STEALTH & JOIN CHANNEL
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Permissions Matrix & Role Management Modal */}
      <AnimatePresence>
        {permissionTargetProject && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-[9998] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl bg-[#121214] border border-white/10 rounded-2xl p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10">
                <div>
                  <h3 className="text-sm font-black tracking-widest text-white uppercase flex items-center gap-2">
                    <Shield className="w-4 h-4 text-cyan-400" />
                    Access Vector Controls
                  </h3>
                  <p className="text-[10px] text-neutral-500 font-mono tracking-tighter uppercase mt-0.5">
                    Project: {permissionTargetProject.name}
                  </p>
                </div>
                <button 
                  onClick={() => setPermissionTargetProject(null)}
                  className="p-1 hover:bg-white/5 rounded-lg text-neutral-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Add New Colleague */}
              <div className="bg-white/5 border border-white/5 rounded-xl p-4 mb-6">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 mb-3">Invite Team Member</h4>
                <div className="flex flex-col md:flex-row gap-3">
                  <input 
                    type="text"
                    value={inviteCollabName}
                    onChange={(e) => setInviteCollabName(e.target.value)}
                    placeholder="ENTER CODENAME..."
                    className="flex-1 bg-[#1a1a1c] border border-white/5 rounded-xl px-4 py-2 text-xs text-white uppercase tracking-widest font-mono focus:outline-none"
                  />
                  <select
                    value={inviteCollabRole}
                    onChange={(e) => setInviteCollabRole(e.target.value as any)}
                    className="bg-[#1a1a1c] border border-white/5 rounded-xl px-3 py-2 text-xs text-neutral-400 uppercase tracking-widest font-mono"
                  >
                    <option value="ADMIN">ADMIN</option>
                    <option value="COLLABORATOR">COLLABORATOR</option>
                    <option value="VIEWER">VIEWER</option>
                  </select>
                  <button
                    onClick={handleAddCollaborator}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl px-4 py-2 text-[10px] font-black uppercase tracking-wider transition-all"
                  >
                    ADD PARTICIPANT
                  </button>
                </div>
              </div>

              {/* Current Collaborators & Permissions List */}
              <div className="space-y-3 max-h-56 overflow-y-auto custom-scrollbar mb-6 pr-1">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-neutral-400">Current Collaborators & Security Roles</h4>
                {currentCollaborators.map((member) => (
                  <div key={member.userId} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: member.color }} />
                      <div className="flex flex-col">
                        <span className="text-xs font-black text-white uppercase tracking-widest">{member.name}</span>
                        <span className="text-[9px] font-mono text-neutral-500">ID: {member.userId}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      {/* Role selection dropdown */}
                      <select
                        value={member.role}
                        onChange={(e) => handleChangeRole(member.userId, e.target.value as any)}
                        className="bg-neutral-800 border-none text-neutral-300 text-[10px] font-black uppercase tracking-widest rounded px-2 py-1 focus:ring-1 focus:ring-cyan-500/50"
                      >
                        <option value="ADMIN">ADMIN</option>
                        <option value="COLLABORATOR">COLLABORATOR</option>
                        <option value="VIEWER">VIEWER</option>
                      </select>

                      <button
                        onClick={() => handleRemoveCollaborator(member.userId)}
                        className="p-1 hover:bg-red-500/10 text-[#71717a] hover:text-red-500 rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => setPermissionTargetProject(null)}
                  className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-[#71717a] hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  CANCEL
                </button>
                <button
                  onClick={handleSavePermissions}
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)]"
                >
                  SAVE ACCESS CHANGES
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Synchronized comments & notes bar */}
      <AnimatePresence>
        {targetCommentsProject && (
          <div className="fixed inset-y-0 right-0 w-96 bg-[#121214] border-l border-white/10 z-[100] shadow-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <div className="flex items-center gap-2 text-cyan-400">
                <MessageSquare className="w-4 h-4" />
                <h3 className="text-xs font-black tracking-widest uppercase">Project Comments</h3>
              </div>
              <button 
                onClick={() => setTargetCommentsProject(null)} 
                className="p-1 hover:bg-white/5 rounded-lg text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* List comments */}
            <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-4" ref={scrollRef}>
              {(targetCommentsProject.comments || []).map((comment) => (
                <div key={comment.id} className="p-3 bg-white/5 border border-white/5 rounded-xl">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] font-black text-white uppercase tracking-widest">{comment.userName}</span>
                    <span className="text-[8px] text-neutral-500 font-mono">{new Date(comment.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-xs text-neutral-300 italic">"{comment.content}"</p>
                </div>
              ))}
              {(targetCommentsProject.comments || []).length === 0 && (
                <div className="h-60 flex flex-col items-center justify-center text-neutral-600 italic text-center text-xs">
                  <span className="font-mono text-neutral-500">NO SECURE LOG COMMENTS DETECTED</span>
                </div>
              )}
            </div>

            {/* Post new comment */}
            <div className="p-4 border-t border-white/10 bg-black/20 flex flex-col gap-3">
              <textarea 
                value={newCommentInput}
                onChange={(e) => setNewCommentInput(e.target.value)}
                placeholder="Write secure comment..."
                className="w-full bg-[#18181b] border border-white/5 rounded-xl p-3 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-cyan-500 font-mono resize-none h-20"
              />
              <button
                onClick={handleAddComment}
                className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.2)]"
              >
                SUBMIT COMMENT LOG
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Create New Project Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 bg-[#000000]/80 backdrop-blur-md z-[9998] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-[#121214] border border-white/10 rounded-2xl p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-sm font-black tracking-[0.2em] text-white uppercase">Initialize AI Creation Node</h3>
                <button onClick={() => setShowCreateModal(false)} className="text-[#71717a] hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">Matrix Name</label>
                  <input 
                    type="text" 
                    value={newProjectName} 
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="E.G. CHRONOS_ENGINE"
                    className="w-full bg-[#1c1c1f] border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">Refraction Description</label>
                  <input 
                    type="text" 
                    value={newProjectDesc} 
                    onChange={(e) => setNewProjectDesc(e.target.value)}
                    placeholder="Waveform reflection logic specifications"
                    className="w-full bg-[#1c1c1f] border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-neutral-400 tracking-wider uppercase mb-2">World System Type</label>
                  <select
                    value={newProjectWorld}
                    onChange={(e) => setNewProjectWorld(e.target.value as any)}
                    className="w-full bg-[#1c1c1f] border border-white/5 rounded-xl px-4 py-3 text-xs text-neutral-400 uppercase tracking-widest font-mono"
                  >
                    <option value="SINGULARITY">SINGULARITY</option>
                    <option value="CHRONOS">CHRONOS</option>
                    <option value="SOLARIS">SOLARIS</option>
                    <option value="NEURAL_NET">NEURAL_NET</option>
                  </select>
                </div>
              </div>

              <div className="mt-8 flex gap-3">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="w-1/2 py-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  ABORT
                </button>
                <button
                  onClick={handleCreateProject}
                  className="w-1/2 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)]"
                >
                  DEPLOY NODE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Project Workspace Component ---

const ProjectWorkspace = ({
  projectId,
  projects,
  currentUser,
  onlineUsers,
  onBack,
  onUpdateProject,
  onOpenComments
}: {
  projectId: string,
  projects: Project[],
  currentUser: SystemUser | null,
  onlineUsers: SystemUser[],
  onBack: () => void,
  onUpdateProject: (updates: Partial<Project>) => void,
  onOpenComments: (proj: Project) => void
}) => {
  const project = useMemo(() => projects.find(p => p.id === projectId), [projects, projectId]);

  // Task Creator Form
  const [taskTitle, setTaskTitle] = useState('');
  const [taskAssignee, setTaskAssignee] = useState('');
  const [taskDeadline, setTaskDeadline] = useState('');

  // Milestone Form
  const [milestoneTitle, setMilestoneTitle] = useState('');
  const [milestoneDate, setMilestoneDate] = useState('');

  // Version Builder Form
  const [newVersionTag, setNewVersionTag] = useState('');
  const [newVersionName, setNewVersionName] = useState('');

  // Scribe Invite form state
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<'ADMIN' | 'COLLABORATOR' | 'VIEWER'>('COLLABORATOR');

  // Local active prompt text area state
  const [localPrompt, setLocalPrompt] = useState('');

  useEffect(() => {
    if (project) {
      setLocalPrompt(project.prompt || '');
    }
  }, [projectId, project?.prompt]);

  // Synchronize local changes to remote state
  const propagatePrompt = (val: string) => {
    setLocalPrompt(val);
    onUpdateProject({ prompt: val });
  };

  if (!project) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-12 text-[#71717a] font-mono">
        <HelpCircle className="w-12 h-12 mb-4 animate-pulse text-cyan-500" />
        <h3 className="text-sm font-black tracking-widest uppercase text-white">Project Node Deselected or Missing</h3>
        <button onClick={onBack} className="mt-6 px-6 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl text-[10px] font-black uppercase tracking-widest cursor-pointer">
          Return to Registry
        </button>
      </div>
    );
  }

  const pipelinePhases = ['ideation', 'development', 'training', 'deployment'] as const;
  const currentPhase = project.pipelinePhase || 'ideation';
  const phaseIndex = pipelinePhases.indexOf(currentPhase);
  const progressPercent = Math.round(((phaseIndex + 1) / pipelinePhases.length) * 100);

  const tasks = project.tasks || [];
  const milestones = project.milestones || [];
  const versions = project.versions || [];

  const completedTasks = tasks.filter(t => t.status === 'DONE').length;
  const completedMilestones = milestones.filter(m => m.completed).length;

  const handleSetPhase = (phase: typeof pipelinePhases[number]) => {
    onUpdateProject({ pipelinePhase: phase });
  };

  // Task creation handler
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;

    const newTask: Task = {
      id: 'task-' + Math.random().toString(36).substring(2, 9),
      title: taskTitle.trim(),
      assignedTo: taskAssignee || 'Unassigned',
      status: 'TODO',
      deadline: taskDeadline || undefined
    };

    onUpdateProject({
      tasks: [...tasks, newTask]
    });

    setTaskTitle('');
    setTaskAssignee('');
    setTaskDeadline('');
  };

  const handleToggleTaskStatus = (taskId: string, currentStatus: Task['status']) => {
    const sequence: Task['status'][] = ['TODO', 'IN_PROGRESS', 'DONE'];
    const nextVal = sequence[(sequence.indexOf(currentStatus) + 1) % sequence.length];
    
    onUpdateProject({
      tasks: tasks.map(t => t.id === taskId ? { ...t, status: nextVal } : t)
    });
  };

  const handleDeleteTask = (taskId: string) => {
    onUpdateProject({
      tasks: tasks.filter(t => t.id !== taskId)
    });
  };

  // Milestone creation handler
  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!milestoneTitle.trim()) return;

    const newMilestone: Milestone = {
      id: 'ms-' + Math.random().toString(36).substring(2, 9),
      title: milestoneTitle.trim(),
      completed: false,
      targetDate: milestoneDate || undefined
    };

    onUpdateProject({
      milestones: [...milestones, newMilestone]
    });

    setMilestoneTitle('');
    setMilestoneDate('');
  };

  const handleToggleMilestone = (msId: string) => {
    onUpdateProject({
      milestones: milestones.map(m => m.id === msId ? { ...m, completed: !m.completed } : m)
    });
  };

  const handleDeleteMilestone = (msId: string) => {
    onUpdateProject({
      milestones: milestones.filter(m => m.id !== msId)
    });
  };

  // Save named model version snapshot
  const handleSaveModelSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    const tag = newVersionTag.trim() || 'v' + (versions.length + 1) + '.0.0';
    const label = newVersionName.trim() || 'Custom Model Save';

    const newVer: Version = {
      id: tag,
      timestamp: new Date().toISOString(),
      name: label,
      prompt: localPrompt,
      author: currentUser?.name || 'Architect_M'
    };

    onUpdateProject({
      currentVersionId: tag,
      versions: [newVer, ...versions]
    });

    setNewVersionTag('');
    setNewVersionName('');
  };

  // Invite user / add collaborator
  const handleInviteCollaborator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim()) return;

    const existingCollabs = project.collaborators || [];
    if (existingCollabs.some(c => c.name.toLowerCase() === inviteName.toLowerCase())) {
      setInviteName('');
      return;
    }

    const availableColors = ['#ec4899', '#8b5cf6', '#10b981', '#f59e0b', '#3b82f6', '#ef4444'];
    const randomColor = availableColors[Math.floor(Math.random() * availableColors.length)];

    const newCollaborator: TeamMember = {
      userId: 'USR_INV_' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      name: inviteName.trim(),
      role: inviteRole,
      color: randomColor
    };

    onUpdateProject({
      collaborators: [...existingCollabs, newCollaborator]
    });

    setInviteName('');
  };

  const handleRevertPrompt = (ver: Version) => {
    if (ver.prompt !== undefined) {
      setLocalPrompt(ver.prompt);
      onUpdateProject({
        currentVersionId: ver.id,
        prompt: ver.prompt
      });
    } else {
      onUpdateProject({
        currentVersionId: ver.id
      });
    }
  };

  const membersInRoom = onlineUsers.filter(usr => usr.activeProjectId === projectId);

  return (
    <div className="flex-grow overflow-y-auto custom-scrollbar p-6 space-y-6">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#27272a] bg-[#121214]/65 p-4 rounded-2xl">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-3 bg-[#18181b] hover:bg-[#27272a] text-[#71717a] hover:text-white rounded-xl transition-all cursor-pointer border border-[#27272a]"
            title="Registry list"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-cyan-400 font-bold px-2 py-0.5 bg-cyan-400/10 rounded uppercase">
                {project.worldType}
              </span>
              <span className="text-[10px] font-mono text-[#71717a]">
                ID: {project.id}
              </span>
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight mt-1">
              <SecureText content={obfuscate(project.name)} />
            </h2>
          </div>
        </div>

        {/* Presence & co-editing team indicator */}
        <div className="flex items-center gap-4 self-end md:self-center">
          <div className="flex items-center gap-2 bg-[#18181b] border border-[#27272a] px-3 py-1.5 rounded-xl text-[10px] font-bold text-neutral-300">
            <Users className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-cyan-400">{membersInRoom.length + 1} ACTIVE</span>
            <div className="flex -space-x-1 ml-1">
              <div 
                className="w-4 h-4 rounded-full flex items-center justify-center text-[6px] font-bold text-[#09090b] font-mono uppercase"
                style={{ backgroundColor: currentUser?.color || '#06b6d4' }}
                title={`${currentUser?.name} (You)`}
              >
                {currentUser?.name ? currentUser.name.substring(0, 2) : 'ME'}
              </div>
              {membersInRoom.map(m => (
                <div 
                  key={m.id}
                  className="w-4 h-4 rounded-full flex items-center justify-center text-[6px] font-bold text-[#09090b] font-mono uppercase border border-[#121214]"
                  style={{ backgroundColor: m.color }}
                  title={`${m.name} (Online)`}
                >
                  {m.name.substring(0,2)}
                </div>
              ))}
            </div>
          </div>

          <button 
            type="button"
            onClick={() => onOpenComments(project)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] rounded-xl text-[10px] font-black tracking-widest text-[#71717a] hover:text-white transition-all cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" /> COMMENTS ({project.comments?.length || 0})
          </button>
        </div>
      </div>

      {/* Grid containing PM Dashboard and Model Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left 7 Columns: PM Dashboard, Pipelines, Tasks & Milestones */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Creative Pipeline Stage Tracker */}
          <div className="bg-[#18181b]/40 border border-[#27272a] rounded-2xl p-6 relative overflow-hidden backdrop-blur-sm">
            <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] mb-4 uppercase">AI Creative Pipeline</h3>
            
            {/* Horizontal stages list */}
            <div className="relative pb-4">
              {/* Connecting progress line */}
              <div className="absolute top-[18px] left-[10%] right-[10%] h-[2px] bg-neutral-850 z-0 border-[#27272a] border">
                <div 
                  className="h-full bg-cyan-500 transition-all duration-500" 
                  style={{ width: `${(phaseIndex / (pipelinePhases.length - 1)) * 100}%` }}
                />
              </div>

              <div className="flex justify-between items-center relative z-10">
                {pipelinePhases.map((phase, index) => {
                  const state = index < phaseIndex ? 'completed' : index === phaseIndex ? 'active' : 'pending';
                  return (
                    <button
                      key={phase}
                      type="button"
                      onClick={() => handleSetPhase(phase)}
                      className="flex flex-col items-center group cursor-pointer"
                    >
                      <div className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
                        state === 'completed'
                          ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                          : state === 'active'
                          ? 'bg-[#083344] text-white border-cyan-400 font-bold scale-110 shadow-[0_0_20px_rgba(6,182,212,0.4)]'
                          : 'bg-[#121214] border-neutral-750 text-neutral-500 group-hover:border-neutral-500'
                      }`}>
                        {index + 1}
                      </div>
                      <span className={`text-[9px] font-black tracking-wider uppercase mt-2 ${
                        state === 'active' ? 'text-cyan-400' : 'text-neutral-550 group-hover:text-neutral-300'
                      }`}>
                        {phase}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Overall progress bar info */}
            <div className="flex items-center justify-between text-[10px] font-mono text-[#71717a] mt-4 pt-4 border-t border-[#27272a]/50">
              <span>PIPELINE STATE PROGRESS: {progressPercent}%</span>
              <span>MILESTONES COMPLETE: {completedMilestones}/{milestones.length}</span>
            </div>
          </div>

          {/* Collaborative Task Management Board */}
          <div className="bg-[#18181b]/30 border border-[#27272a] rounded-2xl p-6 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] uppercase">Pipeline Assignments & Deadlines</h3>
                <p className="text-[9px] text-[#71717a] mt-1 uppercase font-mono">Tasks metrics: {completedTasks}/{tasks.length} Completed</p>
              </div>
            </div>

            {/* Task list container */}
            <div className="space-y-2 max-h-[250px] overflow-y-auto custom-scrollbar pr-1">
              {tasks.length === 0 ? (
                <div className="text-center py-6 text-[10px] text-neutral-500 uppercase italic font-mono border border-dashed border-[#27272a] rounded-xl">
                  No tasks active. Deploy assignments below.
                </div>
              ) : (
                tasks.map(task => (
                  <div 
                    key={task.id}
                    className="flex items-center justify-between p-3 bg-black/35 rounded-xl border border-[#27272a] hover:border-cyan-500/20 transition-all font-mono text-[10px]"
                  >
                    <div className="flex items-center gap-3.5 flex-1 min-w-0 pr-4">
                      {/* Interactive toggle Status button */}
                      <button 
                        type="button"
                        onClick={() => handleToggleTaskStatus(task.id, task.status)}
                        className={`p-1 rounded-md border transition-all cursor-pointer ${
                          task.status === 'DONE' 
                            ? 'bg-emerald-550/20 border-emerald-500 text-emerald-400' 
                            : task.status === 'IN_PROGRESS'
                            ? 'bg-amber-550/20 border-amber-500 text-amber-400 animate-pulse'
                            : 'bg-[#18181b] border-neutral-700 text-neutral-550'
                        }`}
                        title="Click to advance status"
                      >
                        {task.status === 'DONE' ? (
                          <CheckSquare className="w-3.5 h-3.5 text-cyan-400" />
                        ) : (
                          <Square className="w-3.5 h-3.5 text-neutral-600 hover:text-white" />
                        )}
                      </button>

                      <div className="truncate">
                        <span className={`font-semibold ${task.status === 'DONE' ? 'line-through text-neutral-600 font-normal' : 'text-neutral-200'}`}>
                          {task.title}
                        </span>
                        
                        <div className="flex items-center gap-3 text-[8px] text-[#71717a] uppercase mt-1">
                          <span className="text-cyan-400 font-bold">BY: {task.assignedTo}</span>
                          {task.deadline && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5 text-neutral-500" /> DEADLINE: {task.deadline}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        task.status === 'DONE'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : task.status === 'IN_PROGRESS'
                          ? 'bg-amber-500/10 text-amber-405'
                          : 'bg-neutral-850 text-neutral-450'
                      }`}>
                        {task.status}
                      </span>

                      <button 
                        type="button"
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-1 hover:bg-red-500/10 rounded-md text-[#71717a] hover:text-red-400 transition-all cursor-pointer"
                        title="Delete Task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Task Add Form */}
            <form onSubmit={handleAddTask} className="grid grid-cols-1 md:grid-cols-4 gap-2 pt-2 border-t border-[#27272a]/40 font-mono text-[9px]">
              <input 
                type="text" 
                required
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="TASK TITLE..."
                className="col-span-2 bg-black/40 border border-[#27272a] rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/40"
              />
              <select
                value={taskAssignee}
                onChange={(e) => setTaskAssignee(e.target.value)}
                className="bg-black/40 border border-[#27272a] rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/40 appearance-none cursor-pointer"
              >
                <option value="">ASSIGN TO...</option>
                <option value="Unassigned">UNASSIGNED</option>
                <option value={currentUser?.name || 'Architect_M'}>ME ({currentUser?.name || 'Architect_M'})</option>
                {project.collaborators?.map(c => (
                  <option key={c.userId} value={c.name}>{c.name}</option>
                ))}
              </select>
              <input 
                type="date" 
                value={taskDeadline}
                onChange={(e) => setTaskDeadline(e.target.value)}
                className="bg-black/40 border border-[#27272a] rounded-xl px-3 py-2 text-white focus:outline-none"
              />
              <button 
                type="submit"
                className="md:col-span-4 w-full py-2 bg-[#18181b] hover:bg-[#27272a] text-cyan-400 border border-cyan-500/20 hover:border-cyan-500/40 rounded-xl font-bold tracking-widest text-[9px] uppercase transition-all cursor-pointer"
              >
                DEPLOY NEW ASSIGNMENT
              </button>
            </form>
          </div>

          {/* Milestones Visualization & Checklist */}
          <div className="bg-[#18181b]/30 border border-[#27272a] rounded-2xl p-6 space-y-4">
            <div>
              <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] uppercase">Studio Milestones Tracker</h3>
              <p className="text-[9px] text-[#71717a] uppercase font-mono mt-1">Completion: {completedMilestones}/{milestones.length} Reached</p>
            </div>

            {/* Milestones list */}
            <div className="space-y-2 max-h-[160px] overflow-y-auto custom-scrollbar pr-1">
              {milestones.length === 0 ? (
                <div className="text-center py-6 text-[10px] text-neutral-500 uppercase italic font-mono border border-dashed border-[#27272a] rounded-xl">
                  No core milestones active. Setup milestones below.
                </div>
              ) : (
                milestones.map(m => (
                  <div 
                    key={m.id}
                    className="flex items-center justify-between p-3 bg-black/25 rounded-md border border-[#27272a] hover:border-cyan-500/10 font-mono text-[9px]"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0 pr-4">
                      {/* Check box indicator */}
                      <button 
                        type="button"
                        onClick={() => handleToggleMilestone(m.id)}
                        className={`p-1 rounded-md border transition-all cursor-pointer ${
                          m.completed 
                            ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400' 
                            : 'bg-[#18181b] border-neutral-700 text-neutral-550'
                        }`}
                      >
                        {m.completed ? (
                          <CheckSquare className="w-3.5 h-3.5 text-cyan-400" />
                        ) : (
                          <Square className="w-3.5 h-3.5 text-neutral-600 hover:text-white" />
                        )}
                      </button>

                      <div className="truncate">
                        <span className={`font-bold ${m.completed ? 'text-neutral-500 font-normal line-through' : 'text-neutral-200'}`}>
                          {m.title}
                        </span>
                        {m.targetDate && (
                          <span className="block text-[8px] text-[#71717a] uppercase mt-0.5 font-mono">
                            TARGET DATE: {m.targetDate}
                          </span>
                        )}
                      </div>
                    </div>

                    <button 
                      type="button"
                      onClick={() => handleDeleteMilestone(m.id)}
                      className="p-1 text-[#71717a] hover:text-red-400 transition-all cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Milestone Add Form */}
            <form onSubmit={handleAddMilestone} className="flex gap-2 font-mono text-[9px] border-t border-[#27272a]/30 pt-3">
              <input 
                type="text" 
                required
                value={milestoneTitle}
                onChange={(e) => setMilestoneTitle(e.target.value)}
                placeholder="MILESTONE LABEL..."
                className="flex-1 bg-black/40 border border-[#27272a] rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/40"
              />
              <input 
                type="date"
                value={milestoneDate}
                onChange={(e) => setMilestoneDate(e.target.value)}
                className="bg-black/40 border border-[#27272a] rounded-xl px-3 py-2 text-white focus:outline-none"
              />
              <button 
                type="submit" 
                className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 hover:text-white text-neutral-400 rounded-xl font-bold uppercase cursor-pointer"
              >
                ADD
              </button>
            </form>
          </div>

        </div>

        {/* Right 5 Columns: Model Blueprints, versioning, Co-editing with Named Snapshots */}
        <div className="lg:col-span-5 space-y-6">

          {/* Prompt/Weights Sandbox (Real-time Co-editing Workspace) */}
          <div className="bg-[#18181b]/40 border border-[#27272a] rounded-2xl p-6 relative backdrop-blur-sm space-y-4">
            <div>
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] uppercase">Co-editing Weights Playground</h3>
                <span className="px-2 py-0.5 rounded text-[8px] bg-red-500/10 text-red-400 font-mono tracking-widest uppercase animate-pulse">Live prompt edits</span>
              </div>
              <p className="text-[9px] text-[#71717a] uppercase font-mono mt-1">Changes are broadcasted instantly to workspace peers.</p>
            </div>

            <div className="relative">
              <textarea 
                value={localPrompt}
                onChange={(e) => propagatePrompt(e.target.value)}
                placeholder="system_instruction: Integrate taxonomic fish layers into neural arrays..."
                className="w-full min-h-[160px] bg-black/45 border border-[#27272a] p-4 rounded-xl text-xs font-mono text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/40 custom-scrollbar leading-relaxed"
              />
              <div className="absolute bottom-3 right-3 text-[7px] text-[#71717a] font-mono uppercase bg-neutral-900/80 px-2 py-1 rounded">
                Characters: {localPrompt.length}
              </div>
            </div>

            {/* Name and Save Current version Snapshot */}
            <form onSubmit={handleSaveModelSnapshot} className="bg-black/25 p-4 rounded-xl border border-[#27272a] space-y-3 font-mono text-[9px]">
              <h4 className="text-[10px] font-bold text-neutral-300 uppercase">Save Named Model Checkpoint</h4>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[8px] text-[#71717a] uppercase block mb-1">Version tag</label>
                  <input 
                    type="text" 
                    required
                    value={newVersionTag}
                    onChange={(e) => setNewVersionTag(e.target.value)}
                    placeholder="e.g. v1.1.0"
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[8px] text-[#71717a] uppercase block mb-1">Checkpoint name</label>
                  <input 
                    type="text" 
                    required
                    value={newVersionName}
                    onChange={(e) => setNewVersionName(e.target.value)}
                    placeholder="e.g. Fast Convergence"
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                  />
                </div>
              </div>
              <button 
                type="submit"
                className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-[9px] font-black tracking-widest uppercase transition-all mt-1 cursor-pointer"
              >
                DEPLOY WEIGHTS VERSION
              </button>
            </form>
          </div>

          {/* Robust Version history list and reversions */}
          <div className="bg-[#18181b]/30 border border-[#27272a] rounded-2xl p-6 space-y-4">
            <div>
              <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] uppercase">Configuration Change Log</h3>
              <p className="text-[9px] text-[#71717a] uppercase font-mono mt-1">Revert prompt back to historical checkpoints seamlessly.</p>
            </div>

            {/* Versions timeline list */}
            <div className="space-y-2 max-h-[170px] overflow-y-auto custom-scrollbar pr-1">
              {versions.length === 0 ? (
                <div className="text-center py-4 text-[10px] text-neutral-500 font-mono italic">
                  No configuration updates saved.
                </div>
              ) : (
                versions.map(ver => (
                  <div 
                    key={ver.id || ver.timestamp}
                    className="p-3 bg-black/25 hover:bg-black/45 rounded-xl border border-[#27272a] flex items-center justify-between gap-4 font-mono text-[9px] transition-all"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-cyan-400 font-bold px-1.5 py-0.5 bg-cyan-400/10 rounded font-mono text-[8px]">
                          {ver.id}
                        </span>
                        <span className="text-neutral-300 font-black truncate">{ver.name || 'Weights Snapshot'}</span>
                      </div>
                      <p className="text-[8px] text-[#71717a] mt-1 uppercase truncate font-mono">
                        by: {ver.author || 'Architect'} • {new Date(ver.timestamp).toLocaleTimeString()}
                      </p>
                    </div>

                    <button 
                      type="button"
                      onClick={() => handleRevertPrompt(ver)}
                      className="px-2.5 py-1.5 bg-neutral-800 hover:bg-cyan-600/20 hover:text-cyan-400 text-neutral-400 hover:border-cyan-500/30 border border-[#27272a] rounded-xl text-[8px] font-black uppercase transition-all cursor-pointer whitespace-nowrap"
                      title="Load this snapshot live"
                    >
                      revert
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Invitation block & team members role assignment panel */}
          <div className="bg-[#18181b]/30 border border-[#27272a] rounded-2xl p-6 space-y-4">
            <div>
              <h3 className="text-xs font-black tracking-[0.2em] text-[#71717a] uppercase">Room Invitation & Access Roles</h3>
              <p className="text-[9px] text-[#71717a] uppercase font-mono mt-1">Co-editors who have permission to work on this wave node.</p>
            </div>

            <div className="space-y-1.5 max-h-[120px] overflow-y-auto custom-scrollbar pr-1">
              {project.collaborators?.map(c => (
                <div key={c.userId} className="flex items-center justify-between p-2.5 bg-black/15 border border-[#27272a] rounded-xl font-mono text-[9px]">
                  <div className="flex items-center gap-2">
                    <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: c.color }} />
                    <span className="text-neutral-200 font-black">{c.name}</span>
                  </div>
                  <span className="text-[8px] text-cyan-500 bg-cyan-500/10 px-1.5 py-0.5 rounded uppercase font-bold text-[8px]">
                    {c.role}
                  </span>
                </div>
              ))}
            </div>

            {/* Invite Form */}
            <form onSubmit={handleInviteCollaborator} className="flex gap-2 font-mono text-[9px] border-t border-[#27272a]/30 pt-3">
              <input 
                type="text" 
                required
                value={inviteName}
                onChange={(e) => setInviteName(e.target.value)}
                placeholder="COLLABORATOR NAME..."
                className="flex-1 bg-black/40 border border-[#27272a] rounded-xl px-2.5 py-2 text-white focus:outline-none"
              />
              <select
                value={inviteRole}
                onChange={(e: any) => setInviteRole(e.target.value)}
                className="bg-black/40 border border-[#27272a] rounded-xl px-2.5 py-2 text-white focus:outline-none cursor-pointer appearance-none"
              >
                <option value="COLLABORATOR">COLLAB</option>
                <option value="ADMIN">ADMIN</option>
                <option value="VIEWER">VIEWER</option>
              </select>
              <button 
                type="submit"
                className="px-3.5 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-xl font-black uppercase tracking-widest cursor-pointer"
              >
                INVITE
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
};

// --- Views & Modules ---

const FlowView = ({ 
  projects, 
  onCreateClick, 
  onConfigurePermissions,
  onOpenComments,
  onExportProject,
  onCardClick
}: { 
  projects: Project[], 
  onCreateClick: () => void,
  onConfigurePermissions: (proj: Project, e: React.MouseEvent) => void,
  onOpenComments: (proj: Project) => void,
  onExportProject: (proj: Project, e: React.MouseEvent) => void,
  onCardClick: (proj: Project) => void
}) => {
  return (
    <div className="flex-1 p-8 overflow-y-auto custom-scrollbar flex flex-col gap-8">
       <section>
          <div className="flex justify-between items-end mb-6">
             <div>
                <h2 className="text-3xl font-black tracking-tighter text-white uppercase italic">Active Creation Nodes</h2>
                <p className="text-[10px] text-[#71717a] font-mono uppercase tracking-[0.2em] mt-1">Real-time collaborative hub</p>
             </div>
             <button 
               onClick={onCreateClick}
               className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 rounded-xl text-[10px] font-black tracking-widest transition-all cursor-pointer"
             >
               <PlusCircle className="w-4 h-4" /> CREATE NEW WAVE
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {projects.map(proj => (
                <div 
                  key={proj.id} 
                  onClick={() => onCardClick(proj)}
                  className="bg-[#18181b]/50 border border-[#27272a] rounded-2xl p-6 group hover:border-cyan-500/50 transition-all cursor-pointer relative overflow-hidden backdrop-blur-sm flex flex-col justify-between min-h-[250px]"
                >
                   <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity pointer-events-none">
                      <Workflow className="w-16 h-16" />
                   </div>
                   
                   <div>
                     <div className="flex items-center justify-between mb-4">
                        <div className="p-3 bg-cyan-500/10 rounded-2xl group-hover:scale-110 transition-transform">
                           <Cpu className="w-6 h-6 text-cyan-500" />
                        </div>
                        <span className="text-[10px] font-mono text-cyan-400 font-bold px-2 py-1 bg-cyan-400/10 rounded-lg">{proj.currentVersionId}</span>
                     </div>
                     
                     <h3 className="text-xl font-black text-white uppercase mb-2 tracking-tight">
                       <SecureText content={obfuscate(proj.name)} />
                     </h3>
                     
                     <p className="text-xs text-[#71717a] leading-relaxed mb-4 italic">
                       "<SecureText content={obfuscate(proj.description)} />"
                     </p>
                   </div>
                   
                   <div className="space-y-4 pt-4 border-t border-[#27272a]/80">
                     {/* Team / Collaborators lists & permissions quick view */}
                     <div className="flex items-center justify-between">
                       <div className="flex -space-x-2 overflow-hidden">
                         {(proj.collaborators || []).slice(0, 4).map((member) => (
                           <div 
                             key={member.userId} 
                             className="w-6 h-6 rounded-full border-2 border-[#121214] flex items-center justify-center text-[8px] font-bold text-[#09090b] uppercase shadow-md font-mono"
                             style={{ backgroundColor: member.color }}
                             title={`${member.name} (${member.role})`}
                           >
                             {member.name.substring(0, 2)}
                           </div>
                         ))}
                         {(proj.collaborators || []).length > 4 && (
                           <div className="w-6 h-6 rounded-full bg-neutral-800 border-2 border-[#121214] flex items-center justify-center text-[8px] text-neutral-400 font-bold">
                             +{(proj.collaborators || []).length - 4}
                           </div>
                         )}
                       </div>

                       <div className="flex items-center gap-1.5 animate-pulse-cyan">
                         {/* Secure project comments button indicator */}
                         <button
                           onClick={(e) => { e.stopPropagation(); onOpenComments(proj); }}
                           className="p-1.5 hover:bg-white/5 rounded-lg text-neutral-500 hover:text-white transition-all relative"
                           title="Comments logs"
                         >
                           <MessageSquare className="w-3.5 h-3.5" />
                           {(proj.comments || []).length > 0 && (
                             <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-cyan-500 rounded-full text-[7px] text-[#09090b] font-black flex items-center justify-center font-mono">
                               {(proj.comments || []).length}
                             </span>
                           )}
                         </button>

                         <button
                           onClick={(e) => onConfigurePermissions(proj, e)}
                           className="p-1.5 hover:bg-cyan-500/10 rounded-lg text-neutral-500 hover:text-cyan-400 transition-all flex items-center gap-1"
                           title="Permissions settings"
                         >
                           <Shield className="w-3.5 h-3.5" />
                           <span className="text-[8px] uppercase tracking-wider font-bold">Roles</span>
                         </button>

                         <button
                           onClick={(e) => onExportProject(proj, e)}
                           className="p-1.5 hover:bg-cyan-500/10 rounded-lg text-neutral-500 hover:text-cyan-400 transition-all flex items-center gap-1"
                           title="Export metadata configuration JSON"
                         >
                           <ArrowDownToLine className="w-3.5 h-3.5" />
                           <span className="text-[8px] uppercase tracking-wider font-bold">Export</span>
                         </button>
                       </div>
                     </div>

                     <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2">
                           <div className="w-2 h-2 rounded-full bg-emerald-500" />
                           <span className="text-[10px] font-bold text-[#71717a] uppercase tracking-widest">{proj.worldType}</span>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[#3f3f46] group-hover:text-cyan-500 transition-colors" />
                     </div>
                   </div>
                </div>
             ))}
          </div>
       </section>

       <section className="bg-cyan-500/5 border border-cyan-500/20 rounded-3xl p-8 flex items-center justify-between">
          <div className="flex items-center gap-6">
             <div className="w-16 h-16 rounded-2xl bg-cyan-600/20 flex items-center justify-center border border-cyan-500/30">
                <Activity className="w-8 h-8 text-cyan-500" />
             </div>
             <div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">Alphafold Pipeline Optimization</h3>
                <p className="text-xs text-[#71717a] max-w-md mt-1 leading-relaxed">
                   Real-time synchronization actively tracks concurrent editing waves. Live telemetry broadcast logs ensure sub-nanosecond jitter reduction.
                </p>
             </div>
          </div>
          <button 
            onClick={onCreateClick}
            className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 rounded-2xl text-[11px] font-black tracking-[0.2em] transition-all uppercase shadow-[0_0_30px_rgba(6,182,212,0.2)] cursor-pointer"
          >
             Initialize wave
          </button>
       </section>
    </div>
  );
};

const ProjectsView = ({ 
  projects, 
  search, 
  setSearch, 
  viewMode, 
  setViewMode, 
  sortBy, 
  setSortBy, 
  sortOrder, 
  setSortOrder,
  onConfigurePermissions,
  onOpenComments,
  onCardClick
}: { 
  projects: Project[], 
  search: string, 
  setSearch: (v: string) => void,
  viewMode: 'active' | 'archived',
  setViewMode: (v: 'active' | 'archived') => void,
  sortBy: any,
  setSortBy: (v: any) => void,
  sortOrder: any,
  setSortOrder: (v: any) => void,
  onConfigurePermissions: (proj: Project, e: React.MouseEvent) => void,
  onOpenComments: (proj: Project) => void,
  onCardClick: (proj: Project) => void
}) => (
  <div className="flex-1 p-8 overflow-y-auto custom-scrollbar flex flex-col gap-8">
     <div className="flex justify-between items-center">
        <h2 className="text-3xl font-black tracking-tighter text-white uppercase">Project Registry</h2>
        <div className="flex bg-[#18181b] border border-[#27272a] rounded-2xl p-1 gap-1">
           <button onClick={() => setViewMode('active')} className={`px-4 py-2 rounded-xl text-[10px] font-bold tracking-widest uppercase transition-all ${viewMode === 'active' ? 'bg-cyan-600 text-white' : 'text-[#71717a]'}`}>Active</button>
           <button onClick={() => setViewMode('archived')} className={`px-4 py-2 rounded-xl text-[10px] font-bold tracking-widest uppercase transition-all ${viewMode === 'archived' ? 'bg-cyan-600 text-white' : 'text-[#71717a]'}`}>Archived</button>
        </div>
     </div>

     <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative col-span-2">
           <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#71717a]" />
           <input 
             type="text" 
             value={search}
             onChange={(e) => setSearch(e.target.value)}
             placeholder="FILTER PROJECT_ID..." 
             className="w-full bg-[#18181b] border border-[#27272a] rounded-2xl pl-12 pr-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono"
           />
        </div>
        <select 
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="bg-[#18181b] border border-[#27272a] rounded-2xl px-4 py-3 text-xs text-white uppercase font-bold tracking-widest appearance-none cursor-pointer focus:outline-none"
        >
          <option value="name">SORT: NAME</option>
          <option value="worldType">SORT: WORLD</option>
          <option value="currentVersionId">SORT: VERSION</option>
        </select>
        <button 
          onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
          className="flex items-center justify-center gap-2 bg-[#18181b] border border-[#27272a] rounded-2xl p-3 text-xs font-bold text-white hover:bg-white/5 transition-all uppercase tracking-widest"
        >
          {sortOrder === 'asc' ? <ArrowUpAZ className="w-4 h-4" /> : <ArrowDownZA className="w-4 h-4" />}
          {sortOrder.toUpperCase()}
        </button>
     </div>

     <div className="flex-1 space-y-3">
        {projects.map(proj => (
          <div 
            key={proj.id} 
            onClick={() => onCardClick(proj)}
            className="bg-[#18181b]/30 border border-[#27272a] p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between group hover:bg-white/5 transition-all gap-4 cursor-pointer"
          >
             <div className="flex items-center gap-6">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white/20 font-black text-xl font-mono ${proj.worldType === 'SINGULARITY' ? 'bg-purple-600/10' : 'bg-cyan-600/10'}`}>
                   {proj.worldType.substring(0,1)}
                </div>
                <div>
                   <h4 className="text-sm font-black text-white uppercase tracking-tight flex items-center gap-2">
                     <SecureText content={obfuscate(proj.name)} />
                     <span className="text-[9px] text-cyan-500 font-mono">[{proj.id}]</span>
                   </h4>
                   <div className="flex items-center gap-3 mt-1 text-[10px] text-[#71717a] font-mono whitespace-nowrap">
                     <span>OWNER: {proj.ownerId}</span>
                     <span>//</span>
                     <span>TEAM: {(proj.collaborators || []).length}</span>
                     <span>//</span>
                     <span className="text-cyan-500 flex items-center gap-1">
                       <MessageSquare className="w-3 h-3" /> {(proj.comments || []).length} Comments
                     </span>
                   </div>
                </div>
             </div>

             <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-[#27272a] pt-3 md:pt-0">
                <div className="flex -space-x-1.5 overflow-hidden">
                  {(proj.collaborators || []).slice(0, 3).map((collab) => (
                    <span 
                      key={collab.userId}
                      style={{ backgroundColor: collab.color }}
                      className="w-5 h-5 rounded-full border border-[#121214] flex items-center justify-center text-[7px] font-bold text-[#09090b] font-mono uppercase"
                      title={collab.name}
                    >
                      {collab.name.substring(0, 2)}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={(e) => onConfigurePermissions(proj, e)}
                    className="p-2 hover:bg-cyan-500/10 border border-[#27272a] hover:border-cyan-500/30 rounded-xl transition-all text-[#71717a] hover:text-cyan-400 flex items-center gap-1.5 text-[9px] font-bold tracking-widest uppercase"
                  >
                    <Shield className="w-3.5 h-3.5" /> Roles
                  </button>

                  <button 
                    onClick={(e) => { e.stopPropagation(); onOpenComments(proj); }}
                    className="p-2 hover:bg-[#27272a] border border-[#27272a] rounded-xl transition-all text-[#71717a] hover:text-white flex items-center gap-1.5 text-[9px] font-bold tracking-widest uppercase"
                  >
                    <MessageSquare className="w-3.5 h-3.5" /> Notes
                  </button>
                </div>

                <div className="text-right shrink-0">
                   <div className="text-[10px] font-black text-white uppercase tracking-widest mb-1">{proj.currentVersionId}</div>
                   <div className="text-[8px] text-[#71717a] font-mono tracking-tighter capitalize">Active syncing</div>
                </div>
             </div>
          </div>
        ))}
        {projects.length === 0 && (
          <div className="h-40 flex flex-col items-center justify-center border border-dashed border-[#27272a] rounded-2xl text-[#3f3f46] gap-2">
             <Box className="w-10 h-10 opacity-20" />
             <span className="text-[10px] uppercase font-black tracking-widest">No Projects Found in Current Matrix</span>
          </div>
        )}
     </div>
  </div>
);

const GenieView = ({ 
  messages, 
  onSend, 
  input, 
  setInput, 
  isThinking, 
  scrollRef, 
  optimizationLevel, 
  setOptimizationLevel 
}: any) => (
  <div className="flex-1 flex flex-col relative h-full">
     <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar pb-36 h-full" ref={scrollRef}>
        <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-4 flex items-center justify-between mb-4">
           <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-emerald-500 animate-pulse" />
              <div className="flex flex-col">
                 <span className="text-[10px] font-black text-white uppercase tracking-widest">Nexus_Gen_Procedure</span>
                 <span className="text-[8px] text-emerald-500 font-mono tracking-tighter">Status: Multi-User Secure Link Active</span>
              </div>
           </div>
           <div className="flex items-center gap-4 text-[9px] font-mono text-[#71717a]">
              <span>NODE: ALPHA</span>
              <span>AUTH: COLLAB_GSI</span>
           </div>
        </div>

        {messages.map((msg: any, i: number) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
             <div className={`max-w-[80%] p-4 rounded-2xl backdrop-blur-md border ${
               msg.role === 'user' ? 'bg-[#18181b]/70 border-white/5' : 
               msg.role === 'system' ? 'bg-cyan-500/5 border-cyan-500/10' : 'bg-cyan-500/5 border-cyan-500/20'
             }`}>
                <div className="flex items-center gap-2 mb-2 justify-between">
                   <div className="flex items-center gap-2">
                     <div className={`w-1.5 h-1.5 rounded-full ${
                       msg.role === 'user' ? 'bg-blue-500' : 
                       msg.role === 'system' ? 'bg-cyan-500' : 'bg-purple-500'
                     }`} />
                     <span className={`text-[9px] font-mono uppercase tracking-widest font-black ${
                       msg.role === 'user' ? 'text-blue-500' : 
                       msg.role === 'system' ? 'text-cyan-400' : 'text-purple-500'
                     }`}>
                       {msg.role === 'system' ? 'COLLAB_BROADCAST' : msg.role}
                     </span>
                   </div>
                   {msg.senderName && (
                     <span className="text-[9px] font-mono px-1 bg-white/5 rounded text-neutral-500 uppercase font-bold tracking-widest">{msg.senderName}</span>
                   )}
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed whitespace-pre-wrap">{msg.content}</p>
             </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex justify-start">
             <div className="bg-white/5 p-4 rounded-2xl flex gap-2 items-center border border-white/5">
                <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce" />
                <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                <span className="text-[9px] font-black text-[#71717a] ml-2 uppercase tracking-widest">Synthesizing wave...</span>
             </div>
          </div>
        )}
        
        {messages.length === 0 && (
          <div className="h-60 flex flex-col items-center justify-center text-[#3f3f46] gap-4 opacity-50">
             <Brain className="w-12 h-12" />
             <div className="text-center">
                <h3 className="text-sm font-black uppercase tracking-widest text-white">Genie Sync Gate</h3>
                <p className="text-[10px] mt-1">Ready for shared synthesis command streams.</p>
             </div>
          </div>
        )}
     </div>

     {/* Sticky relative positioning container to make sure the chat panel stays fully aligned on all screens */}
     <div className="absolute bottom-6 left-0 right-0 px-8">
        <div className="bg-[#121214]/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-2xl flex flex-col gap-3">
           <div className="flex gap-2 mb-1">
              {['STANDARD', 'LOW_LATENCY', 'SUPERGAUSSIAN_MAX'].map(level => (
                <button 
                  key={level}
                  onClick={() => setOptimizationLevel(level as any)}
                  className={`px-3 py-1 rounded-lg text-[8px] font-black tracking-widest uppercase transition-all ${
                    optimizationLevel === level ? 'bg-cyan-600 text-white' : 'bg-white/5 text-[#71717a] hover:text-white'
                  }`}
                >
                  {level.replace('_MAX', '').replace('_', ' ')}
                </button>
              ))}
           </div>
           
           <div className="flex gap-4 items-end">
              <textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), onSend())}
                placeholder="TRANSMIT SECURE TRANSMISSION TO EVERYONE..."
                className="flex-1 bg-transparent border-none outline-none focus:ring-0 text-xs text-white resize-none h-10 py-1 font-mono placeholder:text-neutral-600"
              />
              <div className="flex gap-2">
                 <button className="p-2 hover:bg-white/5 rounded-xl text-[#71717a] transition-colors"><ImageIcon className="w-4 h-4" /></button>
                 <button className="p-2 hover:bg-white/5 rounded-xl text-[#71717a] transition-colors"><Mic className="w-4 h-4" /></button>
                 <button 
                   onClick={onSend}
                   disabled={!input.trim() || isThinking}
                   className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-[10px] font-black tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] flex items-center gap-1 shrink-0 cursor-pointer"
                 >
                   <Send className="w-3.5 h-3.5" /> RUN_SYNC
                 </button>
              </div>
           </div>
        </div>
     </div>
  </div>
);

const DeepMindView = ({
  resources,
  selectedId,
  onSelect,
  input,
  setInput,
  processing,
  onProcess,
  result,
  projects,
  syncProjectId,
  setSyncProjectId,
  onSync
}: {
  resources: any[],
  selectedId: string,
  onSelect: (id: string) => void,
  input: string,
  setInput: (v: string) => void,
  processing: boolean,
  onProcess: () => void,
  result: any | null,
  projects: Project[],
  syncProjectId: string,
  setSyncProjectId: (id: string) => void,
  onSync: () => void
}) => {
  const [dmSearch, setDmSearch] = useState('');
  
  const filtered = useMemo(() => {
    return resources.filter(r => 
      r.name.toLowerCase().includes(dmSearch.toLowerCase()) || 
      r.category.toLowerCase().includes(dmSearch.toLowerCase()) ||
      r.description.toLowerCase().includes(dmSearch.toLowerCase())
    );
  }, [resources, dmSearch]);

  const selectedResource = useMemo(() => {
    return resources.find(r => r.id === selectedId) || resources[0];
  }, [resources, selectedId]);

  return (
    <div className="flex-1 flex overflow-hidden h-full">
      {/* Left panel - 3/5 width */}
      <div className="flex-1 p-8 overflow-y-auto custom-scrollbar flex flex-col gap-6">
        <div>
           <h2 className="text-3xl font-black tracking-tighter text-white uppercase italic">DeepMind Registry</h2>
           <p className="text-[10px] text-[#71717a] font-mono uppercase tracking-[0.2em] mt-1">Accessing and Utilizing Google DeepMind Open-Source pipelines</p>
        </div>

        {/* Search */}
        <div className="relative">
           <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#71717a]" />
           <input 
             type="text" 
             value={dmSearch}
             onChange={(e) => setDmSearch(e.target.value)}
             placeholder="FILTER DEEPMIND RESOURCES (E.G., ALPHAFOLD, GNOME...)" 
             className="w-full bg-[#18181b]/50 border border-[#27272a] rounded-2xl pl-12 pr-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all font-mono"
           />
        </div>

        {/* Resources card grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(res => {
            const isSelected = res.id === selectedId;
            return (
              <div
                key={res.id}
                onClick={() => onSelect(res.id)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-4 ${
                  isSelected 
                    ? 'bg-cyan-500/10 border-cyan-500 shadow-[0_0_25px_rgba(6,182,212,0.1)]' 
                    : 'bg-[#18181b]/40 border-[#27272a] hover:border-neutral-700 hover:bg-[#18181b]/60'
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-[#27272a] text-neutral-300">
                      {res.category}
                    </span>
                    <a 
                      href={res.repoUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="text-[#71717a] hover:text-cyan-400 flex items-center gap-1 text-[9px] font-mono transition-transform hover:translate-x-0.5"
                    >
                      GitHub <ArrowUpRight className="w-3 h-3" />
                    </a>
                  </div>

                  <h3 className="text-sm font-black text-white uppercase tracking-tight mb-2">
                    {res.name}
                  </h3>
                  <p className="text-xs text-[#71717a] leading-relaxed line-clamp-2">
                    {res.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#27272a]/80 space-y-2">
                  <div className="text-[9px] font-bold text-neutral-500 uppercase tracking-wide">Key Pipelines:</div>
                  <div className="flex flex-wrap gap-1">
                    {res.capabilities.map((cap: string, i: number) => (
                      <span key={i} className="text-[8px] font-mono px-2 py-0.5 bg-neutral-800/85 rounded border border-white/5 text-neutral-300">
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="col-span-2 h-40 flex flex-col items-center justify-center border border-dashed border-[#27272a] rounded-2xl text-[#3f3f46]">
               <Database className="w-8 h-8 mb-2 opacity-20" />
               <span className="text-[10px] uppercase font-bold tracking-widest">No DeepMind resources matched filter</span>
            </div>
          )}
        </div>

        {/* Input specifications of selected model */}
        {selectedResource && (
          <div className="bg-[#18181b]/30 border border-[#27272a] rounded-2xl p-6 flex flex-col gap-4 mt-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-cyan-500" />
                <h3 className="text-xs font-black tracking-widest text-white uppercase font-sans">
                  Execute model: {selectedResource.name}
                </h3>
              </div>
              <span className="text-[9.5px] font-mono text-cyan-400 font-bold px-2 py-0.5 rounded bg-cyan-400/10">
                {selectedResource.apiVersion}
              </span>
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[9px] font-mono uppercase font-black text-[#71717a] tracking-widest">
                  Input Sequence Dataset / Specifications
                </label>
                <button 
                  type="button"
                  className="text-[9px] font-mono uppercase font-bold text-cyan-500 hover:text-cyan-400 transition-colors"
                  onClick={() => setInput(selectedResource.sampleInput)}
                >
                  Load Default Dataset
                </button>
              </div>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={selectedResource.inputPlaceholder}
                className="w-full bg-[#141416]/90 border border-[#27272a] rounded-xl p-4 text-xs font-mono text-white placeholder-neutral-700 min-h-[140px] focus:outline-none focus:border-cyan-500/80"
              />
            </div>

            <button
              onClick={onProcess}
              disabled={processing || !input.trim()}
              className="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-xs font-black tracking-[0.2em] uppercase transition-all shadow-[0_0_25px_rgba(6,182,212,0.25)] flex items-center justify-center gap-2 cursor-pointer"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  SYNCHRONIZING COMPUTATIONAL WEIGHTS...
                </>
              ) : (
                <>
                  <Cpu className="w-4 h-4" />
                  EXECUTE RESEARCH PIPELINE
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Right panel - 2/5 width */}
      <div className="w-96 border-l border-[#27272a] bg-[#0c0c0e]/60 flex flex-col overflow-hidden shrink-0 h-full text-left">
        {/* Results Panel Title */}
        <div className="p-6 border-b border-[#27272a] flex flex-col gap-1">
          <div className="flex items-center gap-2 text-cyan-400">
            <Activity className="w-4 h-4" />
            <h3 className="text-xs font-black tracking-[0.15em] uppercase font-sans">Pipeline Stream Results</h3>
          </div>
          <p className="text-[8px] text-[#71717a] font-mono uppercase tracking-[0.15em]">Neural refraction visualizer</p>
        </div>

        {/* Processing Details / Interactive Graphs */}
        <div className="flex-1 p-6 overflow-y-auto custom-scrollbar flex flex-col gap-6">
          {processing ? (
            <div className="flex-1 flex flex-col justify-center items-center h-full text-[#71717a] gap-3 pt-20">
              <RefreshCw className="w-10 h-10 animate-spin text-cyan-500 mb-2" />
              <div className="text-[10px] font-black tracking-widest text-white uppercase text-center font-sans">Folding Matrix Structure</div>
              <div className="text-[8px] font-mono tracking-tighter text-center uppercase">Querying open-source database clusters...</div>
            </div>
          ) : result ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6 text-left"
            >
              {/* Timing Metric */}
              <div className="bg-white/5 border border-white/5 rounded-xl p-3 flex justify-between items-center">
                <span className="text-[9px] font-mono text-neutral-500 uppercase font-black">Sync Time</span>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                  {result.processTimeMs}ms
                </span>
              </div>

              {/* Specific graphical output depends on selected ID */}
              {result.resourceId === 'dm-alphafold' && (
                <div className="space-y-4 text-left">
                  {/* Accuracy Bar */}
                  <StatBar 
                    label="Structure Confidence (pLDDT)" 
                    value={`${result.result.mean_plddt}%`} 
                    percent={result.result.mean_plddt} 
                    color="bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]" 
                  />
                  <StatBar 
                    label="Global Template Match (TM-Score)" 
                    value={result.result.tm_score.toString()} 
                    percent={result.result.tm_score * 100} 
                    color="bg-cyan-500" 
                  />

                  {/* Folded complexes */}
                  <div className="bg-[#18181b]/65 border border-[#27272a] rounded-xl p-4 gap-2 space-y-2">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest block">Identified Subunits:</span>
                    <div className="space-y-1.5 pt-1">
                      {result.result.predicted_complexes.map((c: string, idx: number) => (
                        <div key={idx} className="flex items-center gap-2 text-xs font-mono text-white">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                          {c}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Coordinates Reference */}
                  <div className="bg-white/5 p-3 rounded-xl flex justify-between items-center text-[10px] font-mono">
                    <span className="text-[#71717a]">PDB REFERENCE</span>
                    <span className="text-white bg-neutral-800 px-2 py-1 rounded select-all font-bold">
                      {result.result.folded_coordinates_ref}
                    </span>
                  </div>
                </div>
              )}

              {result.resourceId === 'dm-gnome' && (
                <div className="space-y-4 text-left">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-white/5 p-3 rounded-xl flex flex-col gap-1">
                      <span className="text-[8px] text-[#71717a] uppercase font-mono font-black">Space Group</span>
                      <span className="text-base text-white font-mono font-bold uppercase">{result.result.space_group}</span>
                    </div>
                    <div className="bg-white/5 p-3 rounded-xl flex flex-col gap-1">
                      <span className="text-[8px] text-[#71717a] uppercase font-mono font-black">Stable Verdict</span>
                      <span className={`text-base font-black font-sans uppercase ${result.result.is_stable ? 'text-emerald-400' : 'text-amber-500'}`}>
                        {result.result.is_stable ? 'STABLE' : 'META-STABLE'}
                      </span>
                    </div>
                  </div>

                  <StatBar 
                    label="Thermodynamic Stability (Energy Hull)" 
                    value={`${result.result.energy_above_hull_ev} eV/at`} 
                    percent={Math.max(10, 100 - (result.result.energy_above_hull_ev * 400))} 
                    color={result.result.is_stable ? "bg-emerald-500" : "bg-amber-500"} 
                  />

                  <div className="bg-[#18181b]/65 border border-[#27272a] rounded-xl p-4 space-y-2">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest block">Electronic & Quantum Properties:</span>
                    <div className="space-y-1.5 pt-1 text-xs font-mono text-neutral-300">
                      <div className="flex justify-between">
                        <span>Electron Bandgap:</span>
                        <span className="text-white font-bold">{result.result.predicted_properties.bandgap_ev} eV</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Superconductive Tc:</span>
                        <span className="text-[#a1a1aa]">{result.result.predicted_properties.superconductivity_offset_k} K</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-[9px] text-[#71717a] font-mono uppercase bg-white/5 px-2.5 py-1.5 rounded-lg flex justify-between">
                    <span>PHASE DIAGRAM VECTOR</span>
                    <span className="text-neutral-400">{result.result.ternary_phase_diagram_ref}</span>
                  </div>
                </div>
              )}

              {result.resourceId === 'dm-alphadev' && (
                <div className="space-y-4 text-left">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-white/5 p-3 rounded-xl flex flex-col gap-1 items-center justify-center">
                      <span className="text-neutral-500 text-[8px] uppercase tracking-wider">Before</span>
                      <span className="font-mono text-base font-bold text-red-400 line-through">{result.result.original_instructions} inst.</span>
                    </div>
                    <div className="bg-white/5 p-3 rounded-xl flex flex-col gap-1 items-center justify-center border border-emerald-500/20">
                      <span className="text-neutral-500 text-[8px] uppercase tracking-wider text-emerald-400 font-bold">Optimized</span>
                      <span className="font-mono text-lg font-bold text-emerald-400">{result.result.optimized_instructions} inst.</span>
                    </div>
                  </div>

                  <StatBar 
                    label="Algorithmic Speed Latency reduction" 
                    value={`-${result.result.latency_reduction_pct}%`} 
                    percent={result.result.latency_reduction_pct} 
                    color="bg-purple-500" 
                  />

                  {/* Assembly Code */}
                  <div className="flex flex-col gap-1 pt-1">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest block">Discovered Instructions Sequence:</span>
                    <pre className="p-3 bg-[#131315] rounded-xl border border-white/5 font-mono text-[9.5px] leading-relaxed text-white select-all text-left overflow-x-auto">
                      {result.result.optimized_assembly}
                    </pre>
                  </div>
                </div>
              )}

              {result.resourceId === 'dm-synthid' && (
                <div className="space-y-4 text-left">
                  <StatBar 
                    label="Auth Watermark Detection Confidence" 
                    value={`${(result.result.detection_probability * 100).toFixed(2)}%`} 
                    percent={result.result.detection_probability * 100} 
                    color={result.result.watermark_detected ? "bg-emerald-500" : "bg-cyan-500"} 
                  />

                  <div className="bg-[#18181b]/65 border border-[#27272a] rounded-xl p-4 space-y-2">
                    <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest block">Digital Audit Log:</span>
                    <div className="space-y-2 pt-1 text-xs font-mono text-neutral-300">
                      <div className="flex justify-between">
                        <span>Generation Node:</span>
                        <span className="text-white font-bold">{result.result.payload_audit.generation_node}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Signature Integrity:</span>
                        <span className="text-emerald-400 font-bold">{result.result.payload_audit.signature_integrity}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Watermark Noise Margin:</span>
                        <span className="text-neutral-400">{result.result.payload_audit.noise_margin}% margin</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Brief Summary Description */}
              <div className="p-4 bg-cyan-400/5 border border-cyan-500/10 rounded-2xl text-xs text-[#a1a1aa] leading-relaxed italic">
                "{result.result.summary}"
              </div>

              {/* Synchronization to Projects Section */}
              <div className="pt-6 border-t border-[#27272a] space-y-4">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#71717a] block">Sync Data to Studio Pipeline</span>
                  <span className="text-[8px] uppercase tracking-widest font-mono text-neutral-500 block">Inject outcomes directly into a Flow Creation Node</span>
                </div>

                <div className="flex flex-col gap-2">
                  <select
                    value={syncProjectId}
                    onChange={(e) => setSyncProjectId(e.target.value)}
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-xl px-4 py-2.5 text-xs text-white uppercase font-bold tracking-widest appearance-none cursor-pointer focus:outline-none"
                  >
                    <option value="">-- SELECT FLOW PROJECT NODE --</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.name} [{p.id}]</option>
                    ))}
                  </select>

                  <button
                    onClick={onSync}
                    disabled={!syncProjectId}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black text-[10px] uppercase tracking-widest rounded-xl transition-all shadow-[0_0_15px_rgba(16,185,129,0.2)] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    BROADCAST OUTCOME TO NODE
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="flex-1 flex flex-col justify-center items-center h-full text-neutral-600 gap-3 pt-20">
              <Database className="w-10 h-10 opacity-15 mb-1 text-cyan-500" />
              <div className="text-[9px] font-black tracking-widest uppercase text-white font-sans">No stream packets in bridge buffer</div>
              <p className="text-[8px] text-[#71717a] font-mono text-center max-w-[200px] leading-relaxed uppercase">Select research resource and run calculations on primary sequence</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
