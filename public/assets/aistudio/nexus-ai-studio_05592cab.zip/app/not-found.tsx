import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#09090b] text-white p-4 font-mono">
      <h2 className="text-4xl font-bold mb-4 text-blue-500">404 // NODE_NOT_FOUND</h2>
      <p className="text-sm text-[#71717a] mb-8 uppercase tracking-widest">The requested dimensional coordinate is unreachable.</p>
      <Link 
        href="/"
        className="px-6 py-2 border border-blue-500/30 bg-blue-500/10 hover:bg-blue-500 hover:text-black transition-all text-xs font-bold uppercase tracking-widest"
      >
        Re-engage Master_Gate
      </Link>
    </div>
  )
}
