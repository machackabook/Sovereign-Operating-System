'use client';

import React from 'react';

/**
 * Loading component shown during route transitions.
 */
export default function Loading() {
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-[#09090b] backdrop-blur-sm">
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 border-4 border-cyan-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
        <div className="flex flex-col items-center gap-1">
          <span className="text-[10px] font-bold text-white uppercase tracking-[0.3em] animate-pulse">Syncing_Matrix</span>
          <div className="w-32 h-1 bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-500 animate-loading-bar"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
