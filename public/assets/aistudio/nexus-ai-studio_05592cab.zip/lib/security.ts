/**
 * Security utilities to deter scraping and obfuscate data in the shared application.
 */

export const obfuscate = (text: string): string => {
  if (!text) return '';
  return btoa(text.split('').reverse().join('')).replace(/=/g, '');
};

export const deobfuscate = (obfuscated: string): string => {
  if (!obfuscated) return '';
  try {
    let padded = obfuscated;
    while (padded.length % 4 !== 0) padded += '=';
    return atob(padded).split('').reverse().join('');
  } catch (e) {
    return obfuscated;
  }
};

export const mountSecurityProtocols = () => {
  if (typeof window === 'undefined') return () => {};

  const handleContextMenu = (e: MouseEvent) => {
    e.preventDefault();
    return false;
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (
      e.keyCode === 123 || 
      (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) ||
      (e.ctrlKey && e.keyCode === 85)
    ) {
      e.preventDefault();
      return false;
    }
  };

  window.addEventListener('contextmenu', handleContextMenu);
  window.addEventListener('keydown', handleKeyDown);
  
  return () => {
    window.removeEventListener('contextmenu', handleContextMenu);
    window.removeEventListener('keydown', handleKeyDown);
  };
};
