import { createServer } from 'http';
import { parse } from 'url';
import next from 'next';
import { WebSocketServer } from 'ws';

const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost';
const port = 3000;

// Initialize Next.js app
const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

// In-memory persistent database for multi-user synchronization
const projects = [
  { 
    id: 'P-101', 
    name: 'Neural Synchronizer 2.0', 
    description: 'Optimized wave reflection for creation pipelines.',
    worldType: 'SINGULARITY',
    archived: false,
    currentVersionId: 'v1.0.4',
    ownerId: 'Architect',
    versions: [
      { id: 'v1.0.4', timestamp: '2026-06-20T12:00:00Z', name: 'Optimized Wave Harmonics', prompt: 'system_instruction: Enhance wave reflection order to 4-step coordinate metrics.', author: 'Architect' },
      { id: 'v1.0.0', timestamp: '2026-05-18T12:00:00Z', name: 'Initial Core Setup', prompt: 'system_instruction: Initialize base taxonomic reflection pipeline.', author: 'Architect' }
    ],
    collaborators: [
      { userId: 'USR_ARCHITECT', role: 'ADMIN', name: 'Architect', color: '#06b6d4' },
      { userId: 'USR_SCRIBE', role: 'COLLABORATOR', name: 'Scribe', color: '#ec4899' }
    ],
    comments: [
      { id: 'c1', userId: 'USR_ARCHITECT', userName: 'Architect', content: 'Connection needs to be stable at Order 4 harmonics.', timestamp: new Date().toISOString() }
    ],
    pipelinePhase: 'development',
    prompt: 'system_instruction: Enhance wave reflection order to 4-step coordinate metrics.',
    tasks: [
      { id: 't-101-1', title: 'Achieve stable test training benchmarks', assignedTo: 'Scribe', status: 'IN_PROGRESS', deadline: '2026-06-25' },
      { id: 't-101-2', title: 'Configure coordinate metrics model blueprint', assignedTo: 'Architect', status: 'DONE', deadline: '2026-06-18' },
      { id: 't-101-3', title: 'Map biological taxonomies model nodes', assignedTo: 'Unassigned', status: 'TODO', deadline: '2026-06-30' }
    ],
    milestones: [
      { id: 'm-101-1', title: 'Design initial core prompt weights blueprint', completed: true, targetDate: '2026-06-15' },
      { id: 'm-101-2', title: 'Complete system testing under low-latency fallback', completed: false, targetDate: '2026-06-28' }
    ]
  },
  { 
    id: 'P-202', 
    name: 'Slingshot Accelerator', 
    description: 'Sub-latency packet routing for remote telemetry.',
    worldType: 'CHRONOS',
    archived: false,
    currentVersionId: 'v2.1.0',
    ownerId: 'Scribe',
    versions: [
      { id: 'v2.1.0', timestamp: '2026-05-19T09:00:00Z', name: 'Fast Packet Refractory', prompt: 'system_instruction: Optimize UDP slingshot trajectory weights for low jitter.', author: 'Scribe' }
    ],
    collaborators: [
      { userId: 'USR_SCRIBE', role: 'ADMIN', name: 'Scribe', color: '#ec4899' }
    ],
    comments: [],
    pipelinePhase: 'training',
    prompt: 'system_instruction: Optimize UDP slingshot trajectory weights for low jitter.',
    tasks: [
      { id: 't-202-1', title: 'Optimize UDP slingshot trajectory weights', assignedTo: 'Scribe', status: 'DONE', deadline: '2026-05-15' },
      { id: 't-202-2', title: 'Deploy telemetry broadcast layers', assignedTo: 'Unassigned', status: 'TODO', deadline: '2026-07-05' }
    ],
    milestones: [
      { id: 'm-202-1', title: 'Prototype sub-latency network connection', completed: true, targetDate: '2026-05-10' }
    ]
  }
];

const globalChat = [
  { id: 'init-1', userId: 'System', userName: 'NEXUS_SYS', content: 'Quantum tunneling channels established. Multi-user operational.', timestamp: new Date().toISOString() }
];

// Map of active WebSocket connections to current User session info
const activeSockets = new Map();

app.prepare().then(() => {
  const server = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url || '', true);
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error('Error handling request:', req.url, err);
      res.statusCode = 500;
      res.end('Internal Server Error');
    }
  });

  // Create WebSocket Server
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req, socket, head) => {
    const parsedUrl = parse(req.url || '', true);
    const { pathname } = parsedUrl;

    if (pathname === '/api/ws') {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    } else {
      // Defer Next HMR web socket upgrade
    }
  });

  wss.on('connection', (ws) => {
    const userId = 'USR_' + Math.random().toString(36).substring(2, 8).toUpperCase();
    const guestNames = ['Aegis', 'Vortex', 'Vector', 'Quantum', 'Glitch', 'Chroma', 'Helix', 'Matrix', 'Pioneer'];
    const selectedName = guestNames[Math.floor(Math.random() * guestNames.length)] + '_' + Math.floor(100 + Math.random() * 900);
    const selectedColor = ['#06b6d4', '#ec4899', '#8b5cf6', '#10b981', '#f59e0b', '#3b82f6'][Math.floor(Math.random() * 6)];
    
    // Default guest profile
    const defaultUser = {
      id: userId,
      name: selectedName,
      role: 'COLLABORATOR',
      color: selectedColor,
      cursor: { x: 0, y: 0 },
      activeProjectId: null
    };

    activeSockets.set(ws, defaultUser);

    // 1. Send initial sync package to current connection
    ws.send(JSON.stringify({
      type: 'sync',
      data: {
        projects,
        globalChat,
        users: Array.from(activeSockets.values()),
        currentUser: defaultUser
      }
    }));

    // 2. Broadcast user connection to other clients
    broadcast({
      type: 'user:joined',
      data: defaultUser
    }, ws);

    // 3. Broadcast updated active user list
    broadcast({
      type: 'users:update',
      data: Array.from(activeSockets.values())
    });

    ws.on('message', (message) => {
      try {
        const payload = JSON.parse(message.toString());
        const currentUser = activeSockets.get(ws);
        if (!currentUser) return;

        switch (payload.type) {
          case 'init': {
            // Update profile with user-defined identity details
            if (payload.data.id) currentUser.id = payload.data.id;
            if (payload.data.name) currentUser.name = payload.data.name;
            if (payload.data.role) currentUser.role = payload.data.role;
            if (payload.data.color) currentUser.color = payload.data.color;

            // Re-sync with client
            ws.send(JSON.stringify({
              type: 'sync',
              data: {
                projects,
                globalChat,
                users: Array.from(activeSockets.values()),
                currentUser
              }
            }));

            // Broadcast user update
            broadcast({
              type: 'users:update',
              data: Array.from(activeSockets.values())
            });
            break;
          }

          case 'cursor:move': {
            currentUser.cursor = payload.data.cursor;
            currentUser.activeProjectId = payload.data.activeProjectId;

            // Broadcast movement instantly (skipping origin)
            broadcast({
              type: 'cursor:moved',
              data: {
                userId: currentUser.id,
                cursor: currentUser.cursor,
                activeProjectId: currentUser.activeProjectId
              }
            }, ws);
            break;
          }

          case 'project:create': {
            const newProj = {
              id: payload.data.id || 'P-' + Math.floor(100 + Math.random() * 900),
              name: payload.data.name || 'New AI Pipeline',
              description: payload.data.description || 'Continuous optimization module.',
              worldType: payload.data.worldType || 'NEURAL_NET',
              archived: false,
              currentVersionId: payload.data.currentVersionId || 'v1.0.0',
              ownerId: currentUser.id,
              versions: payload.data.versions || [{ id: 'v1.0.0', timestamp: new Date().toISOString() }],
              collaborators: payload.data.collaborators || [{ userId: currentUser.id, name: currentUser.name, role: 'ADMIN', color: currentUser.color }],
              comments: [],
              pipelinePhase: payload.data.pipelinePhase || 'ideation',
              tasks: payload.data.tasks || [],
              milestones: payload.data.milestones || [],
              prompt: payload.data.prompt || '',
              ...payload.data
            };

            projects.push(newProj);

            broadcast({
              type: 'project:created',
              data: {
                projects,
                project: newProj
              }
            });
            break;
          }

          case 'project:update': {
            const targetId = payload.data.id;
            const idx = projects.findIndex((p) => p.id === targetId);
            if (idx !== -1) {
              const currentProj = projects[idx];

              // Verify collaborator rights
              const isFound = currentProj.collaborators.some((c) => c.userId === currentUser.id && c.role !== 'VIEWER');
              // Let anyone edit standard public projects unless restricted, but implement simple ownership/collab check
              if (currentProj.ownerId !== currentUser.id && currentProj.collaborators.length > 0 && !isFound) {
                // If not in collaborators lists, auto-join as collaborator to make demo easy, or assert viewer restriction
                // Let's make it collaborative: auto-add user if not present (since we are on the same studio), otherwise allow edits.
                currentProj.collaborators.push({
                  userId: currentUser.id,
                  name: currentUser.name,
                  role: 'COLLABORATOR',
                  color: currentUser.color
                });
              }

              // Apply values
              projects[idx] = {
                ...currentProj,
                ...payload.data
              };

              broadcast({
                type: 'project:updated',
                data: {
                  projects,
                  project: projects[idx]
                }
              });
            }
            break;
          }

          case 'project:permissions': {
            const targetId = payload.data.id;
            const idx = projects.findIndex((p) => p.id === targetId);
            if (idx !== -1) {
              // Set team parameters and sync them across
              projects[idx].collaborators = payload.data.collaborators;

              broadcast({
                type: 'project:updated',
                data: {
                  projects,
                  project: projects[idx]
                }
              });
            }
            break;
          }

          case 'project:comment': {
            const targetId = payload.data.id;
            const idx = projects.findIndex((p) => p.id === targetId);
            if (idx !== -1) {
              const newComment = {
                id: 'c-' + Math.random().toString(36).substring(2, 9),
                userId: currentUser.id,
                userName: currentUser.name,
                content: payload.data.content,
                timestamp: new Date().toISOString()
              };
              
              if (!projects[idx].comments) projects[idx].comments = [];
              projects[idx].comments.push(newComment);

              broadcast({
                type: 'project:updated',
                data: {
                  projects,
                  project: projects[idx]
                }
              });
            }
            break;
          }

          case 'chat:send': {
            const newMsg = {
              id: 'msg-' + Math.random().toString(36).substring(2, 9),
              userId: currentUser.id,
              userName: currentUser.name,
              content: payload.data.content,
              timestamp: new Date().toISOString()
            };

            globalChat.push(newMsg);

            broadcast({
              type: 'chat:message',
              data: {
                globalChat,
                message: newMsg
              }
            });
            break;
          }

          default:
            console.warn('Unhandled websocket package:', payload.type);
        }
      } catch (err) {
        console.error('Websocket transmission parsing fault:', err);
      }
    });

    ws.on('close', () => {
      const exitingUser = activeSockets.get(ws);
      if (exitingUser) {
        activeSockets.delete(ws);
        broadcast({
          type: 'user:left',
          data: exitingUser.id
        });
        broadcast({
          type: 'users:update',
          data: Array.from(activeSockets.values())
        });
      }
    });
  });

  function broadcast(payload, excludeWs) {
    const rawData = JSON.stringify(payload);
    for (const [socket, user] of activeSockets.entries()) {
      if (socket !== excludeWs && socket.readyState === 1) { // 1 = OPEN
        try {
          socket.send(rawData);
        } catch (e) {
          console.error('Socket send failure:', e);
        }
      }
    }
  }

  server.listen(port, () => {
    console.log(`> Nexus Studio multi-user listener deployed on http://${hostname}:${port}`);
  });
});
