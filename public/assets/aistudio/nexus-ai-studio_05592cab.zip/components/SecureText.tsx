'use client';

import React, { useState, useEffect } from 'react';
import { deobfuscate } from '@/lib/security';

interface SecureTextProps {
  content: string;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
}

export const SecureText: React.FC<SecureTextProps> = ({ 
  content, 
  className = '', 
  as: Component = 'span' 
}) => {
  const [displayText, setDisplayText] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDisplayText(deobfuscate(content));
    }, 10);
    return () => clearTimeout(timer);
  }, [content]);

  return (
    <Component className={className}>
      {displayText || '••••••••'}
    </Component>
  );
};
