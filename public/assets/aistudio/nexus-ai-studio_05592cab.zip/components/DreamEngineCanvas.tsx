'use client';

import React, { useEffect, useRef, useState } from 'react';

const pseudoHash = (input: string) => {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
};

export const DreamEngineCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [utc, setUtc] = useState('--');
  const [heartbeat, setHeartbeat] = useState(0);
  const [sessionAge, setSessionAge] = useState(0);
  const [dwellDelta, setDwellDelta] = useState(0);
  const [hash, setHash] = useState('genesis');
  const [logs, setLogs] = useState<string[]>(['Genesis block reconstructed.']);
  
  const startTimeRef = useRef(Date.now());

  useEffect(() => {
    const start = Date.now();
    const lastClose = Number(localStorage.getItem('dream.lastClose') || start);
    const delta = Math.floor((start - lastClose) / 1000);
    setDwellDelta(delta);
    if (delta > 0) {
      setLogs(prev => [`Dwell simulation resumed after ${delta}s.`, ...prev]);
    }

    const interval = setInterval(() => {
      setHeartbeat(prev => {
        const next = prev + 1;
        const now = new Date();
        setUtc(now.toISOString());
        setSessionAge(Math.floor((Date.now() - startTimeRef.current) / 1000));
        setHash(pseudoHash(now.toISOString() + next));
        
        if (next % 5 === 0) {
          setLogs(l => [`Heartbeat ${next}: ledger checkpoint committed.`, ...l].slice(0, 16));
        }
        return next;
      });
    }, 1000);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const particles = Array.from({length: 180}, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: Math.random() * 2 + 0.5,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      phase: Math.random() * Math.PI * 2
    }));

    const resize = () => {
      canvas.width = window.innerWidth * devicePixelRatio;
      canvas.height = window.innerHeight * devicePixelRatio;
      ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    };
    window.addEventListener('resize', resize);
    resize();

    const render = (t: number) => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

      const grad = ctx.createLinearGradient(0, 0, window.innerWidth, window.innerHeight);
      grad.addColorStop(0, '#00bfff');
      grad.addColorStop(0.5, '#8a2be2');
      grad.addColorStop(1, '#ff6a00');

      ctx.strokeStyle = 'rgba(255,255,255,0.04)';
      for (let x = 0; x < window.innerWidth; x += 64) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, window.innerHeight); ctx.stroke(); }
      for (let y = 0; y < window.innerHeight; y += 64) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(window.innerWidth, y); ctx.stroke(); }

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > window.innerWidth) p.vx *= -1;
        if (p.y < 0 || p.y > window.innerHeight) p.vy *= -1;

        const glow = 0.5 + 0.5 * Math.sin(t * 0.001 + p.phase);
        ctx.fillStyle = grad;
        ctx.globalAlpha = glow;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r + glow * 2, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;

      animationId = requestAnimationFrame(render);
    };
    animationId = requestAnimationFrame(render);

    const handleUnload = () => {
      localStorage.setItem('dream.lastClose', String(Date.now()));
    };
    window.addEventListener('beforeunload', handleUnload);

    return () => {
      clearInterval(interval);
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden bg-black/40 rounded-2xl border border-white/10">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      
      <div className="absolute top-4 left-4 w-[min(320px,calc(100%-32px))] p-4 border border-white/15 rounded-2xl backdrop-blur-md bg-black/70 shadow-2xl z-10 font-mono pointer-events-none">
        <h1 className="text-sm font-bold m-0 mb-2 bg-gradient-to-r from-[#00bfff] via-[#8a2be2] to-[#ff6a00] bg-clip-text text-transparent">
          Dream Engine • Chronos Heartbeat
        </h1>
        <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 text-[10px]">
          <div className="text-neutral-500">UTC</div><div className="text-neutral-300">{utc}</div>
          <div className="text-neutral-500">Heartbeat</div><div className="text-neutral-300">{heartbeat}</div>
          <div className="text-neutral-500">Session Age</div><div className="text-neutral-300">{sessionAge}s</div>
          <div className="text-neutral-500">Dwell Delta</div><div className="text-neutral-300">{dwellDelta}s</div>
          <div className="text-neutral-500">Ledger Hash</div><div className="text-neutral-300 text-[9px]">{hash}</div>
        </div>
        
        <div className="mt-3 max-h-32 overflow-auto text-[9px] leading-relaxed border-t border-white/10 pt-2 text-neutral-400">
          {logs.map((log, i) => (
            <div key={i}>{log}</div>
          ))}
        </div>
        
        <div className="mt-2 text-[8px] text-neutral-600 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00ff99] shadow-[0_0_8px_#00ff99]" />
          State reconstructed from elapsed time.
        </div>
      </div>
    </div>
  );
};
