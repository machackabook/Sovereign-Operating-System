'use client';

import { useEffect } from 'react';

/**
 * ServiceWorkerRegistration component handles the registration of the PWA Service Worker.
 * It includes special handling for the AI Studio preview environment (sandboxed iframes)
 * where worker registration is restricted by the browser's sandbox policy.
 */
export default function ServiceWorkerRegistration() {
  useEffect(() => {
    // Only attempt registration in a browser environment that supports service workers
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      const registerSW = async () => {
        try {
          // Check if we are in an iframe
          const isInIframe = window.self !== window.top;
          
          if (isInIframe) {
            console.debug('[PWA] Service Worker skipped: Worker disallowed in sandboxed iframes. PWA functionality will be active when opened in a new tab.');
            return;
          }

          // Register with specific scope
          const registration = await navigator.serviceWorker.register('/sw.js', {
            scope: '/',
          });
          
          console.log('[PWA] Service Worker registration successful with scope:', registration.scope);
          
          // Optional: Handle updates
          registration.onupdatefound = () => {
            const installingWorker = registration.installing;
            if (installingWorker) {
              installingWorker.onstatechange = () => {
                if (installingWorker.state === 'installed') {
                  if (navigator.serviceWorker.controller) {
                    console.log('[PWA] New content is available; please refresh.');
                  } else {
                    console.log('[PWA] Content is cached for offline use.');
                  }
                }
              };
            }
          };
        } catch (error) {
          if (error instanceof Error) {
            // Handle the specific 'Worker disallowed' error gracefully
            if (error.message.includes('Worker disallowed') || error.name === 'SecurityError') {
              console.info('[PWA] Service Worker registration restricted by environment (Worker disallowed). This is expected in the AI Studio preview.');
            } else {
              console.error('[PWA] Service Worker registration failed:', error.message);
            }
          }
        }
      };

      // Wait for load to ensure better performance and reliability
      if (document.readyState === 'complete') {
        registerSW();
      } else {
        window.addEventListener('load', registerSW);
        return () => window.removeEventListener('load', registerSW);
      }
    }
  }, []);

  return null; // This component doesn't render anything
}
