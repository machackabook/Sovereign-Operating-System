'use client';

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const AnimusV7Canvas = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0a0f, 0.03);

    // Camera
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 25;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);

    // Geometry
    const geometry = new THREE.TorusKnotGeometry(10, 2.5, 200, 32);

    // Materials
    const wireframeMaterial = new THREE.MeshBasicMaterial({ 
      color: 0x00bfff, // Data-Blue
      wireframe: true,
      transparent: true,
      opacity: 0.35
    });
    const mesh = new THREE.Mesh(geometry, wireframeMaterial);
    scene.add(mesh);

    const pointMaterial = new THREE.PointsMaterial({
      color: 0xff6a00, // Void-Orange
      size: 0.15,
      transparent: true,
      opacity: 0.8
    });
    const particles = new THREE.Points(geometry, pointMaterial);
    scene.add(particles);

    // Execution Loop
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      mesh.rotation.x += 0.003;
      mesh.rotation.y += 0.007;

      particles.rotation.x += 0.003;
      particles.rotation.y += 0.007;

      const time = Date.now() * 0.001;
      const scale = 1 + Math.sin(time * 2) * 0.05;
      particles.scale.set(scale, scale, scale);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      renderer.dispose();
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-[#0a0a0f] rounded-2xl border border-white/10 overflow-hidden">
      <div ref={containerRef} className="absolute inset-0 w-full h-full" />
      <div className="absolute top-5 left-5 text-[#00bfff] font-mono pointer-events-none drop-shadow-[0_0_5px_rgba(0,191,255,0.8)]">
        <h2 className="text-sm font-bold uppercase mb-1">[ANIMUS_V7 CANVAS ACTIVE]</h2>
        <p className="text-[10px]">Geometry: Torus Knot Neural Mesh</p>
        <p className="text-[10px]">Status: <span className="text-[#ff6a00]">SYNCED TO 6TH SYNAPSE</span></p>
      </div>
    </div>
  );
};
