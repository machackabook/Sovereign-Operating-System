import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import tailwindcss from '@tailwindcss/vite';
import OpenAI from 'openai';

function apiPlugin(envApiKey: string) {
  const handleChatRequest = async (req: any, res: any) => {
    if (req.method !== 'POST') {
      res.statusCode = 405;
      res.end(JSON.stringify({ error: 'Method not allowed' }));
      return;
    }

    let bodyStr = '';
    req.on('data', (chunk: any) => {
      bodyStr += chunk;
    });

    req.on('end', async () => {
      try {
        const body = JSON.parse(bodyStr || '{}');
        const { messages, model = 'gemini-3.6-flash', temperature = 0.7, jsonMode = false, stream = true } = body;

        const apiKey = process.env.GEMINI_API_KEY || envApiKey;
        if (!apiKey) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: 'GEMINI_API_KEY environment variable is missing.' }));
          return;
        }

        const openai = new OpenAI({
          apiKey: apiKey,
          baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
        });

        // Strip 'models/' prefix if user or code accidentally passes it
        const cleanModel = model.replace(/^models\//, '') || 'gemini-3.6-flash';

        if (stream) {
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');

          const responseStream = await openai.chat.completions.create({
            model: cleanModel,
            messages: messages || [],
            temperature: Number(temperature),
            response_format: jsonMode ? { type: 'json_object' } : undefined,
            stream: true,
          });

          for await (const chunk of responseStream) {
            const text = chunk.choices[0]?.delta?.content || '';
            if (text) {
              res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
            }
          }
          res.write('data: [DONE]\n\n');
          res.end();
        } else {
          const completion = await openai.chat.completions.create({
            model: cleanModel,
            messages: messages || [],
            temperature: Number(temperature),
            response_format: jsonMode ? { type: 'json_object' } : undefined,
            stream: false,
          });

          res.setHeader('Content-Type', 'application/json');
          res.end(
            JSON.stringify({
              content: completion.choices[0]?.message?.content || '',
              usage: completion.usage,
              model: completion.model,
            })
          );
        }
      } catch (error: any) {
        console.error('API Error:', error);
        res.statusCode = error.status || 500;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: error.message || 'Error connecting to Gemini OpenAI API' }));
      }
    });
  };

  return {
    name: 'openai-gemini-api',
    configureServer(server: any) {
      server.middlewares.use('/api/chat', handleChatRequest);
    },
    configurePreviewServer(server: any) {
      server.middlewares.use('/api/chat', handleChatRequest);
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    server: {
      port: 3000,
      host: '0.0.0.0',
    },
    plugins: [
      tailwindcss(),
      apiPlugin(env.GEMINI_API_KEY || '')
    ],
    define: {
      'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      }
    }
  };
});
