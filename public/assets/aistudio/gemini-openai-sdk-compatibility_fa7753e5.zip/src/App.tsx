import React, { useState } from 'react';
import { ChatPlayground } from './components/ChatPlayground';
import { CodeInspector } from './components/CodeInspector';
import { CompatibilityMatrix } from './components/CompatibilityMatrix';
import {
  Code2,
  Sparkles,
  CheckCircle2,
  Layers,
  Terminal,
  ExternalLink,
  ShieldCheck,
  Cpu,
} from 'lucide-react';

export default function App() {
  const [model, setModel] = useState('gemini-3.6-flash');
  const [systemPrompt, setSystemPrompt] = useState('You are a helpful, precise AI assistant.');
  const [temperature, setTemperature] = useState(0.7);
  const [stream, setStream] = useState(true);
  const [jsonMode, setJsonMode] = useState(false);
  const [activeTab, setActiveTab] = useState<'playground' | 'matrix'>('playground');
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'user',
      content: 'Explain how Gemini models can be called using the OpenAI SDK.',
    },
  ]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Top Banner & Header */}
      <header id="app-header" className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-400 p-0.5 shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-indigo-400">
                <Code2 className="w-5 h-5" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 id="app-title" className="text-base font-bold text-slate-100 tracking-tight">
                  Gemini with OpenAI SDK
                </h1>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full">
                  Compatibility Gateway
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Run Gemini models seamlessly using official <code className="text-indigo-300 font-mono">openai</code> npm package
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Status indicator */}
            <div className="hidden sm:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl text-xs text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[11px] text-slate-400">Endpoint:</span>
              <span className="font-mono text-[11px] text-emerald-400 font-medium">/v1beta/openai/</span>
            </div>

            {/* Navigation Tabs */}
            <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-xl">
              <button
                id="tab-btn-playground"
                onClick={() => setActiveTab('playground')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'playground'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Playground</span>
              </button>
              <button
                id="tab-btn-matrix"
                onClick={() => setActiveTab('matrix')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'matrix'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Features</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col gap-6">
        {activeTab === 'playground' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-1">
            {/* Left Column: Interactive Chat Playground */}
            <div className="lg:col-span-7 flex flex-col min-h-[580px]">
              <ChatPlayground
                model={model}
                setModel={setModel}
                systemPrompt={systemPrompt}
                setSystemPrompt={setSystemPrompt}
                temperature={temperature}
                setTemperature={setTemperature}
                stream={stream}
                setStream={setStream}
                jsonMode={jsonMode}
                setJsonMode={setJsonMode}
                onMessageUpdate={setChatMessages}
              />
            </div>

            {/* Right Column: Live Code Inspector */}
            <div className="lg:col-span-5 flex flex-col min-h-[580px]">
              <CodeInspector
                model={model}
                systemPrompt={systemPrompt}
                temperature={temperature}
                stream={stream}
                jsonMode={jsonMode}
                messages={chatMessages}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <CompatibilityMatrix />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer id="app-footer" className="border-t border-slate-800/80 bg-slate-950 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Server-side API key proxy protection enabled.</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Base URL: <code className="text-indigo-300 font-mono">https://generativelanguage.googleapis.com/v1beta/openai/</code></span>
            <span>SDK: <code className="text-slate-300 font-mono">openai</code></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
