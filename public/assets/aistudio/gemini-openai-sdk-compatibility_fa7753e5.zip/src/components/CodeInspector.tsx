import React, { useState } from 'react';
import { Code2, Copy, Check, Terminal, Sparkles } from 'lucide-react';

interface CodeInspectorProps {
  model: string;
  systemPrompt: string;
  temperature: number;
  stream: boolean;
  jsonMode: boolean;
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
}

export const CodeInspector: React.FC<CodeInspectorProps> = ({
  model,
  systemPrompt,
  temperature,
  stream,
  jsonMode,
  messages,
}) => {
  const [copied, setCopied] = useState(false);

  const formattedMessages = [
    ...(systemPrompt.trim() ? [{ role: 'system', content: systemPrompt }] : []),
    ...messages,
  ];

  const codeSnippet = `import OpenAI from 'openai';

// Initialize OpenAI client pointing to Google's Gemini endpoint
const openai = new OpenAI({
  apiKey: process.env.GEMINI_API_KEY,
  baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/',
});

async function main() {
  ${
    stream
      ? `const responseStream = await openai.chat.completions.create({
    model: '${model}',
    messages: ${JSON.stringify(formattedMessages, null, 6)},
    temperature: ${temperature},${jsonMode ? `\n    response_format: { type: 'json_object' },` : ''}
    stream: true,
  });

  for await (const chunk of responseStream) {
    process.stdout.write(chunk.choices[0]?.delta?.content || '');
  }`
      : `const completion = await openai.chat.completions.create({
    model: '${model}',
    messages: ${JSON.stringify(formattedMessages, null, 6)},
    temperature: ${temperature},${jsonMode ? `\n    response_format: { type: 'json_object' },` : ''}
    stream: false,
  });

  console.log(completion.choices[0].message.content);`
  }
}

main();`;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(codeSnippet);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  return (
    <div id="code-inspector-container" className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-full">
      <div id="code-inspector-header" className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-sm text-slate-200">Server Execution Snippet</span>
          <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded-full font-mono">
            OpenAI SDK v4+
          </span>
        </div>
        <button
          id="copy-code-btn"
          onClick={copyToClipboard}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-lg border border-slate-700/60 transition-all active:scale-95 cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Code</span>
            </>
          )}
        </button>
      </div>

      <div id="code-inspector-body" className="p-4 bg-slate-950/60 font-mono text-xs overflow-x-auto flex-1 text-slate-300 leading-relaxed">
        <pre className="selection:bg-indigo-500/40">
          <code>{codeSnippet}</code>
        </pre>
      </div>

      <div id="code-inspector-footer" className="bg-slate-950/90 px-4 py-3 border-t border-slate-800/80 text-xs text-slate-400 flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
        <span>
          Zero code changes required when switching from OpenAI to Gemini — simply change <code className="text-indigo-300 bg-slate-900 px-1 py-0.5 rounded">baseURL</code> and use a Gemini model ID like <code className="text-emerald-300 bg-slate-900 px-1 py-0.5 rounded">{model}</code>.
        </span>
      </div>
    </div>
  );
};
