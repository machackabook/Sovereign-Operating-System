import React from 'react';
import { CheckCircle2, Zap, Shield, Cpu, Code2, Layers } from 'lucide-react';

export const CompatibilityMatrix: React.FC = () => {
  const features = [
    {
      title: 'Chat Completions',
      method: 'openai.chat.completions.create()',
      description: 'Standard OpenAI completion structure with user, assistant, and system messages.',
      status: 'Supported',
      icon: Code2,
    },
    {
      title: 'Real-Time Streaming',
      method: 'stream: true',
      description: 'Async iterable streaming delivering partial completion chunks via SSE.',
      status: 'Supported',
      icon: Zap,
    },
    {
      title: 'System Instructions',
      method: "{ role: 'system', content: '...' }",
      description: 'Define persona, guidelines, and behavioral boundaries for Gemini models.',
      status: 'Supported',
      icon: Shield,
    },
    {
      title: 'Temperature & Sampling',
      method: 'temperature: 0.0 - 2.0',
      description: 'Control response creativity and determinism seamlessly.',
      status: 'Supported',
      icon: Cpu,
    },
    {
      title: 'Structured JSON Mode',
      method: "response_format: { type: 'json_object' }",
      description: 'Enforce valid JSON output responses directly from Gemini.',
      status: 'Supported',
      icon: Layers,
    },
    {
      title: 'Custom Base URL',
      method: "baseURL: 'https://generativelanguage.googleapis.com/v1beta/openai/'",
      description: 'Plug-and-play drop-in replacement for existing OpenAI client codebases.',
      status: 'Supported',
      icon: CheckCircle2,
    },
  ];

  return (
    <div id="compatibility-matrix-section" className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 id="compatibility-heading" className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            OpenAI SDK Compatibility Matrix
          </h2>
          <p id="compatibility-subheading" className="text-sm text-slate-400 mt-1">
            Features verified working with Google Gemini models via <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-indigo-300">https://generativelanguage.googleapis.com/v1beta/openai/</code>
          </p>
        </div>
        <span id="compatibility-badge" className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-full flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          100% Endpoint Compatible
        </span>
      </div>

      <div id="compatibility-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((feat, idx) => {
          const Icon = feat.icon;
          return (
            <div
              key={idx}
              id={`compatibility-card-${idx}`}
              className="bg-slate-950/80 border border-slate-800/80 hover:border-slate-700/80 transition-all duration-200 rounded-xl p-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-medium px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {feat.status}
                  </span>
                </div>
                <h3 className="font-semibold text-slate-200 text-sm mb-1">{feat.title}</h3>
                <p className="text-xs text-slate-400 mb-3">{feat.description}</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-indigo-300 truncate">
                {feat.method}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
