import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, RefreshCw, Sliders, Sparkles, AlertCircle, FileText, Settings2, Trash2, Copy, Check } from 'lucide-react';
import { marked } from 'marked';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ChatPlaygroundProps {
  model: string;
  setModel: (m: string) => void;
  systemPrompt: string;
  setSystemPrompt: (s: string) => void;
  temperature: number;
  setTemperature: (t: number) => void;
  stream: boolean;
  setStream: (s: boolean) => void;
  jsonMode: boolean;
  setJsonMode: (j: boolean) => void;
  onMessageUpdate?: (messages: Array<{ role: 'user' | 'assistant'; content: string }>) => void;
}

const PRESET_PROMPTS = [
  {
    title: 'Explain AI Principles',
    category: 'Educational',
    prompt: 'Explain how generative AI models work under the hood using an analogy a 10-year-old can understand.',
  },
  {
    title: 'TypeScript Function',
    category: 'Coding',
    prompt: 'Write a clean TypeScript generic function for debouncing async API requests with cancellation.',
  },
  {
    title: 'Structured Output (JSON)',
    category: 'Data',
    prompt: 'Return a JSON list of 3 popular space missions with keys: missionName, launchYear, and primaryObjective.',
  },
  {
    title: 'Creative Storyteller',
    category: 'Creative',
    prompt: 'Write a brief sci-fi scenario about quantum computing breakthroughs in deep space navigation.',
  },
];

export const ChatPlayground: React.FC<ChatPlaygroundProps> = ({
  model,
  setModel,
  systemPrompt,
  setSystemPrompt,
  temperature,
  setTemperature,
  stream,
  setStream,
  jsonMode,
  setJsonMode,
  onMessageUpdate,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-msg',
      role: 'assistant',
      content:
        'Hello! I am connected to Google Gemini via the official **OpenAI SDK** compatibility layer (`https://generativelanguage.googleapis.com/v1beta/openai/`).\n\nHow can I help you today?',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const handleCopyMessage = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedMessageId(id);
      setTimeout(() => {
        setCopiedMessageId((current) => (current === id ? null : current));
      }, 2000);
    } catch (err) {
      console.error('Failed to copy message:', err);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
    if (onMessageUpdate) {
      onMessageUpdate(
        messages.map((m) => ({ role: m.role, content: m.content }))
      );
    }
  }, [messages]);

  const handleSend = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const messageText = (customText || input).trim();
    if (!messageText || isGenerating) return;

    setError(null);
    setInput('');

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setIsGenerating(true);

    const assistantMsgId = (Date.now() + 1).toString();
    const initialAssistantMsg: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, initialAssistantMsg]);

    try {
      const apiMessages = [
        ...(systemPrompt.trim()
          ? [{ role: 'system', content: systemPrompt }]
          : []),
        ...newMessages.map((m) => ({ role: m.role, content: m.content })),
      ];

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: apiMessages,
          model,
          temperature,
          stream,
          jsonMode,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP error ${response.status}`);
      }

      if (stream) {
        const reader = response.body?.getReader();
        const decoder = new TextDecoder('utf-8');

        if (!reader) {
          throw new Error('Response body reader not available.');
        }

        let accumulatedContent = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const dataStr = line.slice(6).trim();
              if (dataStr === '[DONE]') break;

              try {
                const parsed = JSON.parse(dataStr);
                if (parsed.content) {
                  accumulatedContent += parsed.content;
                  setMessages((prev) =>
                    prev.map((msg) =>
                      msg.id === assistantMsgId
                        ? { ...msg, content: accumulatedContent }
                        : msg
                    )
                  );
                }
              } catch (err) {
                // Ignore chunk parse error if split across boundaries
              }
            }
          }
        }
      } else {
        const data = await response.json();
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMsgId
              ? { ...msg, content: data.content || 'No response returned.' }
              : msg
          )
        );
      }
    } catch (err: any) {
      console.error('Generation failed:', err);
      setError(err.message || 'An error occurred during response generation.');
      // Remove placeholder assistant message on error
      setMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));
    } finally {
      setIsGenerating(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: Date.now().toString(),
        role: 'assistant',
        content:
          'Chat history cleared. Send a new prompt to test OpenAI SDK with Gemini!',
        timestamp: new Date(),
      },
    ]);
    setError(null);
  };

  const parseMarkdown = (raw: string) => {
    try {
      return { __html: marked.parse(raw) as string };
    } catch (e) {
      return { __html: raw };
    }
  };

  return (
    <div id="chat-playground-container" className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-full">
      {/* Header Controls */}
      <div id="chat-playground-header" className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 id="chat-playground-title" className="font-semibold text-sm text-slate-100 flex items-center gap-2">
              Gemini OpenAI SDK Playground
            </h2>
            <p className="text-[11px] text-slate-400">Interactive endpoint testing</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Model Selector */}
          <select
            id="model-selector"
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 transition-colors"
          >
            <option value="gemini-3.6-flash">gemini-3.6-flash (Default)</option>
            <option value="gemini-flash-latest">gemini-flash-latest</option>
          </select>

          <button
            id="toggle-settings-btn"
            onClick={() => setShowSettings(!showSettings)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
              showSettings
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-slate-800 text-slate-300 border-slate-700/60 hover:bg-slate-700'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>Config</span>
          </button>

          <button
            id="clear-history-btn"
            onClick={handleClearHistory}
            className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-800/80 hover:bg-slate-800 rounded-lg border border-slate-700/60 transition-colors cursor-pointer"
            title="Clear Chat History"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Expandable Configurations */}
      {showSettings && (
        <div id="settings-panel" className="bg-slate-950/90 border-b border-slate-800/80 p-4 space-y-4 text-xs animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* System Prompt */}
            <div className="md:col-span-3">
              <label className="block text-slate-300 font-medium mb-1 flex items-center justify-between">
                <span>System Instruction</span>
                <span className="text-[10px] text-slate-500">role: 'system'</span>
              </label>
              <input
                id="system-prompt-input"
                type="text"
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                placeholder="e.g. You are a helpful, concise assistant."
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Temperature Slider */}
            <div>
              <div className="flex justify-between text-slate-300 font-medium mb-1">
                <span>Temperature</span>
                <span className="text-indigo-400 font-mono">{temperature}</span>
              </div>
              <input
                id="temperature-slider"
                type="range"
                min="0"
                max="2"
                step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-indigo-500 cursor-pointer"
              />
            </div>

            {/* Streaming Toggle */}
            <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 p-2.5 rounded-lg">
              <div>
                <span className="text-slate-300 font-medium block">Stream Response</span>
                <span className="text-[10px] text-slate-500">stream: true</span>
              </div>
              <button
                id="toggle-stream-btn"
                type="button"
                onClick={() => setStream(!stream)}
                className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${
                  stream ? 'bg-indigo-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.75 ${
                    stream ? 'right-0.75' : 'left-0.75'
                  }`}
                />
              </button>
            </div>

            {/* JSON Mode Toggle */}
            <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 p-2.5 rounded-lg">
              <div>
                <span className="text-slate-300 font-medium block">JSON Output Mode</span>
                <span className="text-[10px] text-slate-500">response_format: json_object</span>
              </div>
              <button
                id="toggle-json-mode-btn"
                type="button"
                onClick={() => setJsonMode(!jsonMode)}
                className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${
                  jsonMode ? 'bg-indigo-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform absolute top-0.75 ${
                    jsonMode ? 'right-0.75' : 'left-0.75'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message Stream */}
      <div id="message-stream-container" className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[500px]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            id={`message-bubble-${msg.id}`}
            className={`flex gap-3 text-sm ${
              msg.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-none'
                  : 'bg-slate-800/80 border border-slate-700/60 text-slate-200 rounded-bl-none shadow-sm'
              }`}
            >
              {msg.role === 'assistant' ? (
                <>
                  <div
                    className="prose prose-invert prose-sm max-w-none prose-pre:bg-slate-950 prose-pre:border prose-pre:border-slate-800"
                    dangerouslySetInnerHTML={parseMarkdown(msg.content || '*(Generating response...)*')}
                  />
                  <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-700/40 text-[10px] text-slate-400">
                    <button
                      id={`copy-msg-btn-${msg.id}`}
                      type="button"
                      onClick={() => handleCopyMessage(msg.id, msg.content)}
                      disabled={!msg.content}
                      className="flex items-center gap-1.5 py-1 px-2 rounded-md bg-slate-900/80 hover:bg-slate-900 border border-slate-700/60 text-slate-300 hover:text-white transition-all active:scale-95 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Copy assistant response"
                    >
                      {copiedMessageId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400 font-medium">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                    <span className="opacity-60">
                      {msg.timestamp.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                  <div className="text-[10px] mt-1.5 opacity-60 text-right text-indigo-100">
                    {msg.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </>
              )}
            </div>

            {msg.role === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {error && (
          <div id="chat-error-banner" className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Presets Bar */}
      <div id="presets-container" className="bg-slate-950/40 border-t border-slate-800/60 p-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[11px] text-slate-400 font-medium shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-indigo-400" /> Presets:
        </span>
        {PRESET_PROMPTS.map((preset, idx) => (
          <button
            key={idx}
            id={`preset-prompt-btn-${idx}`}
            onClick={() => handleSend(undefined, preset.prompt)}
            disabled={isGenerating}
            className="text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 px-2.5 py-1 rounded-full whitespace-nowrap transition-all disabled:opacity-50 cursor-pointer"
          >
            {preset.title}
          </button>
        ))}
      </div>

      {/* Input Form */}
      <form id="chat-input-form" onSubmit={handleSend} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
        <input
          id="chat-text-input"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message to test OpenAI SDK with Gemini..."
          disabled={isGenerating}
          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-colors"
        />

        <button
          id="send-message-btn"
          type="submit"
          disabled={!input.trim() || isGenerating}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-medium text-sm px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed shadow-md"
        >
          {isGenerating ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          <span className="hidden sm:inline">{isGenerating ? 'Generating' : 'Send'}</span>
        </button>
      </form>
    </div>
  );
};
