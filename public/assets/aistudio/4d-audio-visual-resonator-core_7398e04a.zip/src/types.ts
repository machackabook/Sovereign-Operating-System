export type DiffMode = 'mix' | 'spoken' | 'instrument';
export type AiRoute = 'direct' | 'matrix' | 'predictive';
export type CameraPreset = 'orbit' | 'core' | 'planar' | 'free';
export type VisualTopology = 'fractal' | 'vocal_string' | 'harmonic_field' | 'tesseract_4d';

export interface ResonatorSettings {
  text: string;
  voiceIndex: number;
  aiRoute: AiRoute;
  attenuationDb: number;      // 0 to 48 dB/oct
  procSpeed: number;          // 0.25 to 3.0
  noiseFloorDb: number;       // -120 to -40 dB
  syncIndex: number;          // 0 to 100
  deepHorizonDb: number;      // -48 to 0 dB
  foregroundActive: boolean;
  backgroundActive: boolean;
  diffMode: DiffMode;
  micActive?: boolean;
}

export interface NodeDiagnostic {
  name: string;
  channel: string;
  latencyMs: number;
  parity: string;
  packets: number;
  status: 'ONLINE' | 'ACTIVE' | 'STANDBY';
  intensity: number;
}

export interface SpectralMetrics {
  bass: number;
  mid: number;
  treble: number;
  centroidHz: number;
  rmsDb: number;
}

export interface TelemetryState {
  patternVectors: [number, number, number, number]; // 4D [X, Y, Z, W]
  foreshadowText: string;
  topologyForm: string;
  fractalIntensity: number;
  flowProgress: number;
  wordIndex: number | null;
  activeNodes: {
    nodeA: boolean;
    nodeB: boolean;
    sat04: boolean;
  };
  compoundingStack: number[];
  isResonating: boolean;
  statusText: string;
  spectralMetrics: SpectralMetrics;
  nodesDetail: {
    nodeA: NodeDiagnostic;
    nodeB: NodeDiagnostic;
    sat04: NodeDiagnostic;
  };
}
