import { useState, useEffect, useRef, useCallback } from 'react';
import { ResonatorSettings, TelemetryState, VisualTopology } from './types';
import { resonatorEngine } from './audio/resonatorAudioEngine';
import { ControlDeck } from './components/ControlDeck';
import { ThreeResonatorArena } from './components/ThreeResonatorArena';
import { DiagnosticsModal } from './components/DiagnosticsModal';

const SEQUENCE_PRESETS: Record<1 | 2 | 3 | 4, string> = {
  1: 'Executing continuous hyper-dimensional fractal sequences. Reconfiguring high-frequency acoustic attenuation curves across isolated Dolby layers.',
  2: 'Polymorphic neural topology matrix verified. Projecting predictive melodic flow patterns into the environment to clear underlying noise floors.',
  3: 'Filtering all known unknowns through precision rhythm and tone synchronization arrays. Deep horizon ambient compounding activated.',
  4: 'Synchronizing peripheral link modules. Satellite arrays A, B, and room network channel 04 establishing adaptive vocal resonance grids.',
};

export default function App() {
  const [settings, setSettings] = useState<ResonatorSettings>({
    text: SEQUENCE_PRESETS[1],
    voiceIndex: 0,
    aiRoute: 'direct',
    attenuationDb: 24,
    procSpeed: 1.0,
    noiseFloorDb: -96,
    syncIndex: 100,
    deepHorizonDb: -12,
    foregroundActive: true,
    backgroundActive: true,
    diffMode: 'mix',
    micActive: false,
  });

  const [activePresetId, setActivePresetId] = useState<number | null>(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [syllableImpulse, setSyllableImpulse] = useState(0);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);

  const [telemetry, setTelemetry] = useState<TelemetryState>({
    patternVectors: [0.42, -0.19, 0.88, 0.31],
    foreshadowText: 'Stable Ambient Cache (Learned)',
    topologyForm: 'Polymorphic Neural Fractal Cage',
    fractalIntensity: 0.12,
    flowProgress: 35,
    wordIndex: null,
    activeNodes: { nodeA: false, nodeB: false, sat04: false },
    compoundingStack: [20, 40, 30, 15, 10],
    isResonating: false,
    statusText: 'POLYMORPHIC BALANCED',
    spectralMetrics: {
      bass: 0.25,
      mid: 0.45,
      treble: 0.15,
      centroidHz: 1420,
      rmsDb: -42,
    },
    nodesDetail: {
      nodeA: {
        name: 'Neural Node Alpha',
        channel: 'CH-01 (Spatial Lead)',
        latencyMs: 12,
        parity: '0x9F4C (Clean)',
        packets: 14280,
        status: 'ONLINE',
        intensity: 0.2,
      },
      nodeB: {
        name: 'Neural Node Beta',
        channel: 'CH-02 (Harmonic Sub)',
        latencyMs: 8,
        parity: '0x3E1B (Clean)',
        packets: 19842,
        status: 'ONLINE',
        intensity: 0.15,
      },
      sat04: {
        name: 'Satellite Array 04',
        channel: 'CH-04 (Horizon Bus)',
        latencyMs: 15,
        parity: '0x7A0D (Active)',
        packets: 8420,
        status: 'ACTIVE',
        intensity: 0.3,
      },
    },
  });

  const settingsRef = useRef(settings);
  useEffect(() => {
    settingsRef.current = settings;
    // Live update topology form when diffMode changes
    setTelemetry((prev) => ({
      ...prev,
      topologyForm:
        settings.diffMode === 'spoken'
          ? 'Linear Vocal Chord String'
          : settings.diffMode === 'instrument'
          ? 'Hyper-Dispersed Harmonic Field'
          : settings.aiRoute === 'predictive'
          ? '4D Quantum Tesseract Hypercube'
          : 'Polymorphic Neural Fractal Cage',
    }));
    resonatorEngine.applySettings(settings);
  }, [settings]);

  // Load available synthesis voices on start
  useEffect(() => {
    resonatorEngine.initVoices((loadedVoices) => {
      setVoices(loadedVoices);
      const enIndex = loadedVoices.findIndex(
        (v) => v.default || v.lang.includes('en-US') || v.lang.includes('en')
      );
      if (enIndex !== -1) {
        setSettings((prev) => ({ ...prev, voiceIndex: enIndex }));
      }
    });
  }, []);

  // Update real-time channel levels stack graph, FFT spectral metrics and 4D coordinates
  useEffect(() => {
    let frameId: number;
    let tick = 0;

    const tickTelemetry = () => {
      tick += 0.05;
      const audioData = resonatorEngine.getAudioData();
      const current = settingsRef.current;
      const isLive = telemetry.isResonating;

      const boost = isLive ? 1.0 + audioData.freqAverage * 2.2 : 0.25;
      const fgFactor = current.foregroundActive ? 1 : 0.3;
      const bgFactor = current.backgroundActive ? 1 : 0.1;

      const s1 = Math.max(8, (18 + Math.sin(tick * 3.5) * 12) * boost);
      const s2 = Math.max(12, (38 + Math.cos(tick * 4.2) * 16) * boost);
      const s3 = Math.max(8, (28 + Math.sin(tick * 5.1) * 14) * fgFactor);
      const s4 = Math.max(5, (16 + Math.cos(tick * 2.2) * 9) * bgFactor);
      const s5 = Math.max(4, (10 + Math.sin(tick * 6.0) * 6) * boost);

      // Mutate 4D coordinates gently with time and audio
      const wRot = Math.sin(tick * 0.4) * (0.3 + audioData.freqAverage);

      setTelemetry((prev) => ({
        ...prev,
        compoundingStack: [s1, s2, s3, s4, s5],
        fractalIntensity: isLive ? 0.45 + audioData.freqAverage * 1.6 : 0.12,
        spectralMetrics: audioData.metrics,
        patternVectors: [
          parseFloat((prev.patternVectors[0] + Math.sin(tick) * 0.01).toFixed(3)),
          parseFloat((prev.patternVectors[1] + Math.cos(tick * 1.1) * 0.01).toFixed(3)),
          parseFloat((prev.patternVectors[2] + Math.sin(tick * 0.9) * 0.01).toFixed(3)),
          parseFloat(wRot.toFixed(3)),
        ],
      }));

      frameId = requestAnimationFrame(tickTelemetry);
    };

    frameId = requestAnimationFrame(tickTelemetry);
    return () => cancelAnimationFrame(frameId);
  }, [telemetry.isResonating]);

  // Word boundary event handler during speech or instrument resonance
  const handleWordBoundary = useCallback((charIndex: number) => {
    setSyllableImpulse(2.4);

    const randomVectors: [number, number, number, number] = [
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
    ];

    const pickNode = Math.floor(Math.random() * 3);

    setTelemetry((prev) => ({
      ...prev,
      wordIndex: charIndex,
      patternVectors: randomVectors,
      flowProgress: Math.floor(Math.random() * 55) + 45,
      foreshadowText: `Anticipating Index: #${charIndex} (Resonant)`,
      activeNodes: {
        nodeA: pickNode === 0,
        nodeB: pickNode === 1,
        sat04: pickNode === 2,
      },
      nodesDetail: {
        ...prev.nodesDetail,
        nodeA: {
          ...prev.nodesDetail.nodeA,
          intensity: pickNode === 0 ? 0.95 : 0.2,
          packets: prev.nodesDetail.nodeA.packets + 12,
        },
        nodeB: {
          ...prev.nodesDetail.nodeB,
          intensity: pickNode === 1 ? 0.95 : 0.2,
          packets: prev.nodesDetail.nodeB.packets + 14,
        },
        sat04: {
          ...prev.nodesDetail.sat04,
          intensity: pickNode === 2 ? 0.95 : 0.2,
          packets: prev.nodesDetail.sat04.packets + 8,
        },
      },
    }));

    // Reset node flash after 320ms
    setTimeout(() => {
      setTelemetry((prev) => ({
        ...prev,
        activeNodes: { nodeA: false, nodeB: false, sat04: false },
        nodesDetail: {
          ...prev.nodesDetail,
          nodeA: { ...prev.nodesDetail.nodeA, intensity: 0.2 },
          nodeB: { ...prev.nodesDetail.nodeB, intensity: 0.15 },
          sat04: { ...prev.nodesDetail.sat04, intensity: 0.25 },
        },
      }));
    }, 320);
  }, []);

  const handleResonateEnd = useCallback(() => {
    setSyllableImpulse(0);
    setTelemetry((prev) => ({
      ...prev,
      isResonating: false,
      statusText: 'POLYMORPHIC BALANCED',
      foreshadowText: 'Stable Ambient Cache (Learned)',
      flowProgress: 35,
    }));
  }, []);

  const handleResonate = () => {
    if (telemetry.isResonating) {
      resonatorEngine.stop();
      resonatorEngine.playCue('kill');
      handleResonateEnd();
      return;
    }

    setTelemetry((prev) => ({
      ...prev,
      isResonating: true,
      statusText: 'NEURAL ROUTING LIVE',
      foreshadowText: 'Anticipating Next Structural Interval...',
    }));

    resonatorEngine.start(settings, handleWordBoundary, handleResonateEnd);
  };

  const handleKill = () => {
    resonatorEngine.playCue('kill');
    resonatorEngine.stop();
    handleResonateEnd();
  };

  const handleLoadPreset = (id: 1 | 2 | 3 | 4) => {
    resonatorEngine.playCue('preset');
    const text = SEQUENCE_PRESETS[id];
    setActivePresetId(id);
    setSettings((prev) => ({ ...prev, text }));

    const randomVectors: [number, number, number, number] = [
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
      parseFloat((Math.random() * 2 - 1).toFixed(3)),
    ];

    setTelemetry((prev) => ({
      ...prev,
      patternVectors: randomVectors,
      flowProgress: Math.floor(Math.random() * 45) + 40,
    }));
  };

  const handleSelectTopology = (topology: VisualTopology) => {
    const topologyLabels: Record<VisualTopology, string> = {
      fractal: 'Polymorphic Neural Fractal Cage',
      vocal_string: 'Linear Vocal Chord String',
      harmonic_field: 'Hyper-Dispersed Harmonic Field',
      tesseract_4d: '4D Quantum Tesseract Hypercube',
    };
    setTelemetry((prev) => ({
      ...prev,
      topologyForm: topologyLabels[topology],
    }));
  };

  // Keyboard shortcut controls for studio workflow
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts when typing inside the textarea
      if (e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLInputElement) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        handleResonate();
      } else if (e.code === 'Escape') {
        e.preventDefault();
        handleKill();
        setIsDiagnosticsOpen(false);
      } else if (e.key === '1') {
        handleLoadPreset(1);
      } else if (e.key === '2') {
        handleLoadPreset(2);
      } else if (e.key === '3') {
        handleLoadPreset(3);
      } else if (e.key === '4') {
        handleLoadPreset(4);
      } else if (e.key.toLowerCase() === 'd') {
        setIsDiagnosticsOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [telemetry.isResonating, settings]);

  return (
    <div className="min-h-screen flex flex-col xl:flex-row antialiased bg-slate-950 text-slate-100 overflow-x-hidden">
      {/* Primary Control Panel Configuration Deck */}
      <ControlDeck
        settings={settings}
        setSettings={setSettings}
        telemetry={telemetry}
        voices={voices}
        activePresetId={activePresetId}
        onResonate={handleResonate}
        onKill={handleKill}
        onLoadPreset={handleLoadPreset}
      />

      {/* Hyper-Dimensional WebGL Viewing Arena and HUD Controls Overlay */}
      <ThreeResonatorArena
        settings={settings}
        telemetry={telemetry}
        syllableImpulse={syllableImpulse}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        onSelectTopology={handleSelectTopology}
      />

      {/* Deep Telemetry & Peripheral Satellite Inspector Modal */}
      <DiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        telemetry={telemetry}
        settings={settings}
      />
    </div>
  );
}
