import { ResonatorSettings, SpectralMetrics } from '../types';

export class ResonatorAudioEngine {
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private dolbyLowpass: BiquadFilterNode | null = null;
  private dolbyHighShelf: BiquadFilterNode | null = null;
  private spatialPanner: StereoPannerNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  
  // Drone & synth elements
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private droneGain: GainNode | null = null;
  private lfoOsc: OscillatorNode | null = null;
  private lfoGain: GainNode | null = null;
  private synthInterval: number | null = null;
  private pannerInterval: number | null = null;
  
  // Microphone input
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private micGain: GainNode | null = null;

  // Speech synthesis
  private utterance: SpeechSynthesisUtterance | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private formantOsc: OscillatorNode | null = null;
  private formantGain: GainNode | null = null;

  private onWordBoundaryCb?: (charIndex: number) => void;
  private onEndCb?: () => void;
  private isResonating = false;
  private isMicActive = false;

  constructor() {
    this.initVoices();
  }

  public initVoices(callback?: (voices: SpeechSynthesisVoice[]) => void) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    const loadVoices = () => {
      this.voices = window.speechSynthesis.getVoices();
      if (callback) callback(this.voices);
    };

    loadVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.voices.length === 0 && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.voices = window.speechSynthesis.getVoices();
    }
    return this.voices;
  }

  public ensureAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtx();

      // Analyser for real-time FFT
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 1024;
      this.analyser.smoothingTimeConstant = 0.85;

      // Primary Dolby 4-pole lowpass filter
      this.dolbyLowpass = this.audioCtx.createBiquadFilter();
      this.dolbyLowpass.type = 'lowpass';
      this.dolbyLowpass.frequency.value = 8000;
      this.dolbyLowpass.Q.value = 1.4;

      // Secondary Dolby High Shelf for high-end damping
      this.dolbyHighShelf = this.audioCtx.createBiquadFilter();
      this.dolbyHighShelf.type = 'highshelf';
      this.dolbyHighShelf.frequency.value = 4000;
      this.dolbyHighShelf.gain.value = -6;

      // Stereo Panner for Multi-Channel Spatial Routing
      if (typeof this.audioCtx.createStereoPanner === 'function') {
        this.spatialPanner = this.audioCtx.createStereoPanner();
      }

      // Deep Horizon Ambient Delay Line
      this.delayNode = this.audioCtx.createDelay(2.0);
      this.delayNode.delayTime.value = 0.38;
      this.delayFeedback = this.audioCtx.createGain();
      this.delayFeedback.gain.value = 0.28;

      this.delayNode.connect(this.delayFeedback);
      this.delayFeedback.connect(this.delayNode);

      // Master output gain
      this.masterGain = this.audioCtx.createGain();
      this.masterGain.gain.value = 0.4;

      // Routing topology:
      // Sources -> dolbyLowpass -> dolbyHighShelf -> (spatialPanner / delay) -> analyser -> masterGain -> destination
      this.dolbyLowpass.connect(this.dolbyHighShelf);

      if (this.spatialPanner) {
        this.dolbyHighShelf.connect(this.spatialPanner);
        this.spatialPanner.connect(this.analyser);
        this.spatialPanner.connect(this.delayNode);
      } else {
        this.dolbyHighShelf.connect(this.analyser);
        this.dolbyHighShelf.connect(this.delayNode);
      }

      this.delayNode.connect(this.analyser);
      this.analyser.connect(this.masterGain);
      this.masterGain.connect(this.audioCtx.destination);
    }

    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }

    return this.audioCtx;
  }

  public playCue(type: 'click' | 'engage' | 'kill' | 'preset') {
    try {
      const ctx = this.ensureAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'preset') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.08); // A5
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
        osc.start(now);
        osc.stop(now + 0.1);
      } else if (type === 'engage') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(146.83, now);
        osc.frequency.exponentialRampToValueAtTime(440, now + 0.18);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.22);
      } else if (type === 'kill') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(60, now + 0.15);
        gain.gain.setValueAtTime(0.09, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);
        osc.start(now);
        osc.stop(now + 0.18);
      }
    } catch {
      // Audio cue failure benign
    }
  }

  public async toggleMicrophone(active: boolean): Promise<boolean> {
    const ctx = this.ensureAudioContext();

    if (!active) {
      if (this.micStream) {
        this.micStream.getTracks().forEach((track) => track.stop());
        this.micStream = null;
      }
      if (this.micSource) {
        try { this.micSource.disconnect(); } catch { /* ignore */ }
        this.micSource = null;
      }
      this.isMicActive = false;
      return false;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      this.micStream = stream;
      this.micSource = ctx.createMediaStreamSource(stream);
      this.micGain = ctx.createGain();
      this.micGain.gain.value = 1.0;

      this.micSource.connect(this.micGain);
      if (this.dolbyLowpass) {
        this.micGain.connect(this.dolbyLowpass);
      }
      this.isMicActive = true;
      return true;
    } catch (err) {
      console.warn('Microphone access denied or unavailable', err);
      this.isMicActive = false;
      return false;
    }
  }

  public start(
    settings: ResonatorSettings,
    onWordBoundary: (charIndex: number) => void,
    onEnd: () => void
  ) {
    this.stop();
    this.ensureAudioContext();
    this.isResonating = true;
    this.onWordBoundaryCb = onWordBoundary;
    this.onEndCb = onEnd;

    this.playCue('engage');
    this.applySettings(settings);

    // Setup multi-channel spatial panning oscillation for 'matrix' route
    if (this.spatialPanner && settings.aiRoute === 'matrix') {
      let pan = 0;
      let dir = 1;
      this.pannerInterval = window.setInterval(() => {
        pan += 0.15 * dir;
        if (pan > 0.85) { pan = 0.85; dir = -1; }
        if (pan < -0.85) { pan = -0.85; dir = 1; }
        if (this.spatialPanner && this.audioCtx) {
          this.spatialPanner.pan.setTargetAtTime(pan, this.audioCtx.currentTime, 0.08);
        }
      }, 100);
    }

    // 1. Synthesizer Drone & Sub-Bass Foundation
    this.startSynthDrone(settings);

    // 2. Continuous Speech Synthesis or Instrument Sequence
    if (settings.diffMode !== 'instrument' && settings.text.trim()) {
      this.startSpeech(settings);
    } else {
      this.startInstrumentSequence(settings);
    }
  }

  private startSpeech(settings: ResonatorSettings) {
    if (!('speechSynthesis' in window)) {
      this.startInstrumentSequence(settings);
      return;
    }

    window.speechSynthesis.cancel();
    this.utterance = new SpeechSynthesisUtterance(settings.text);

    const voices = this.getVoices();
    if (voices[settings.voiceIndex]) {
      this.utterance.voice = voices[settings.voiceIndex];
    }

    // Rate mapped to procSpeed
    this.utterance.rate = Math.max(0.4, Math.min(2.5, settings.procSpeed));
    // Pitch mapped to rhythm & tone syncIndex
    this.utterance.pitch = Math.max(0.4, Math.min(2.0, 0.75 + (settings.syncIndex / 100) * 0.5));

    // Create synchronized vocal formant carrier wave in WebAudio so visualizer and stack receive rich audio
    this.startVocalFormantCarrier();

    this.utterance.onboundary = (e) => {
      if (e.name === 'word') {
        this.triggerSyllableChord(settings);
        this.pulseFormantCarrier();
        if (this.onWordBoundaryCb) {
          this.onWordBoundaryCb(e.charIndex);
        }
      }
    };

    this.utterance.onend = () => {
      this.isResonating = false;
      this.stopFormantCarrier();
      if (this.onEndCb) {
        this.onEndCb();
      }
    };

    this.utterance.onerror = () => {
      this.isResonating = false;
      this.stopFormantCarrier();
      if (this.onEndCb) {
        this.onEndCb();
      }
    };

    window.speechSynthesis.speak(this.utterance);
  }

  private startVocalFormantCarrier() {
    if (!this.audioCtx || !this.dolbyLowpass) return;

    this.formantOsc = this.audioCtx.createOscillator();
    this.formantGain = this.audioCtx.createGain();

    this.formantOsc.type = 'triangle';
    this.formantOsc.frequency.setValueAtTime(220, this.audioCtx.currentTime);

    this.formantGain.gain.setValueAtTime(0.02, this.audioCtx.currentTime);

    this.formantOsc.connect(this.formantGain);
    this.formantGain.connect(this.dolbyLowpass);

    this.formantOsc.start();
  }

  private pulseFormantCarrier() {
    if (!this.audioCtx || !this.formantGain || !this.formantOsc) return;
    const now = this.audioCtx.currentTime;
    // Morph frequency on word impulse
    const pitches = [196, 220, 246.94, 293.66, 329.63, 392, 440];
    const p = pitches[Math.floor(Math.random() * pitches.length)];
    this.formantOsc.frequency.setTargetAtTime(p, now, 0.04);

    this.formantGain.gain.cancelScheduledValues(now);
    this.formantGain.gain.setValueAtTime(0.09, now);
    this.formantGain.gain.exponentialRampToValueAtTime(0.015, now + 0.28);
  }

  private stopFormantCarrier() {
    if (this.formantOsc) {
      try { this.formantOsc.stop(); } catch { /* ignore */ }
      this.formantOsc = null;
    }
  }

  private startSynthDrone(settings: ResonatorSettings) {
    if (!this.audioCtx || !this.dolbyLowpass) return;

    // Harmonic carrier base frequency
    let baseFreq = 110.0; // A2
    if (settings.diffMode === 'instrument') baseFreq = 146.83; // D3
    if (settings.aiRoute === 'predictive') baseFreq = 130.81; // C3

    const osc1 = this.audioCtx.createOscillator();
    const osc2 = this.audioCtx.createOscillator();
    const droneGain = this.audioCtx.createGain();

    if (settings.aiRoute === 'matrix') {
      osc1.type = 'sawtooth';
      osc2.type = 'sawtooth';
      osc1.detune.value = -8;
      osc2.detune.value = 8;
    } else if (settings.diffMode === 'instrument') {
      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
    } else {
      osc1.type = 'sine';
      osc2.type = 'triangle';
    }

    osc1.frequency.setValueAtTime(baseFreq, this.audioCtx.currentTime);
    osc2.frequency.setValueAtTime(baseFreq * 1.5, this.audioCtx.currentTime); // Perfect fifth

    const droneLevel = settings.backgroundActive ? 0.08 : 0.012;
    droneGain.gain.setValueAtTime(0.001, this.audioCtx.currentTime);
    droneGain.gain.exponentialRampToValueAtTime(droneLevel, this.audioCtx.currentTime + 0.6);

    osc1.connect(droneGain);
    osc2.connect(droneGain);
    droneGain.connect(this.dolbyLowpass);

    osc1.start();
    osc2.start();

    this.droneOsc1 = osc1;
    this.droneOsc2 = osc2;
    this.droneGain = droneGain;
  }

  private triggerSyllableChord(settings: ResonatorSettings) {
    if (!this.audioCtx || !this.dolbyLowpass) return;

    const scale = [220, 246.94, 277.18, 329.63, 369.99, 440, 493.88, 554.37, 659.25];
    const note = scale[Math.floor(Math.random() * scale.length)];

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = settings.diffMode === 'spoken' ? 'sine' : 'triangle';
    osc.frequency.setValueAtTime(note, this.audioCtx.currentTime);

    // If predictive route, add an octave overtone
    if (settings.aiRoute === 'predictive') {
      const shimmer = this.audioCtx.createOscillator();
      const shimmerGain = this.audioCtx.createGain();
      shimmer.type = 'sine';
      shimmer.frequency.setValueAtTime(note * 2, this.audioCtx.currentTime);
      shimmerGain.gain.setValueAtTime(0.03, this.audioCtx.currentTime);
      shimmerGain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.35);
      shimmer.connect(shimmerGain);
      shimmerGain.connect(this.dolbyLowpass);
      shimmer.start();
      shimmer.stop(this.audioCtx.currentTime + 0.36);
    }

    const initialGain = settings.foregroundActive ? 0.11 : 0.025;
    gain.gain.setValueAtTime(initialGain, this.audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(this.dolbyLowpass);

    osc.start();
    osc.stop(this.audioCtx.currentTime + 0.42);
  }

  private startInstrumentSequence(settings: ResonatorSettings) {
    if (!this.audioCtx) return;

    const chords = [
      [146.83, 220.0, 261.63, 329.63, 440.0], // Dm9
      [174.61, 220.0, 261.63, 349.23, 440.0], // Fmaj7
      [130.81, 196.0, 246.94, 329.63, 392.0], // Cmaj9
      [164.81, 220.0, 261.63, 329.63, 493.88], // Am9
      [116.54, 174.61, 233.08, 293.66, 349.23], // BbMaj7
    ];

    let step = 0;
    const intervalTime = Math.max(140, 420 / settings.procSpeed);

    this.synthInterval = window.setInterval(() => {
      if (!this.isResonating || !this.audioCtx || !this.dolbyLowpass) return;

      const chord = chords[Math.floor(step / 4) % chords.length];
      const freq = chord[step % chord.length];

      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = settings.aiRoute === 'matrix' ? 'sawtooth' : 'triangle';
      const octaveMultiplier = step % 3 === 0 ? 2 : step % 4 === 0 ? 0.5 : 1;
      osc.frequency.setValueAtTime(freq * octaveMultiplier, this.audioCtx.currentTime);

      const level = settings.foregroundActive ? 0.1 : 0.02;
      gain.gain.setValueAtTime(level, this.audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.42);

      osc.connect(gain);
      gain.connect(this.dolbyLowpass);

      osc.start();
      osc.stop(this.audioCtx.currentTime + 0.45);

      if (this.onWordBoundaryCb) {
        this.onWordBoundaryCb(step);
      }

      step++;
      if (step > 64) {
        step = 0; // Continuous loop for instrument mode until killed
      }
    }, intervalTime);
  }

  public applySettings(settings: ResonatorSettings) {
    if (!this.audioCtx) return;

    // Dolby High-End Attenuation (0 to 48 dB/oct)
    // 0 dB = 18000 Hz cutoff, 48 dB = 1600 Hz cutoff with steep Q resonance
    if (this.dolbyLowpass) {
      const cutoff = 18000 - (settings.attenuationDb / 48) * 16400;
      this.dolbyLowpass.frequency.setTargetAtTime(Math.max(600, cutoff), this.audioCtx.currentTime, 0.05);
      const qVal = 0.7 + (settings.attenuationDb / 48) * 2.5;
      this.dolbyLowpass.Q.setTargetAtTime(qVal, this.audioCtx.currentTime, 0.05);
    }

    // High shelf damping
    if (this.dolbyHighShelf) {
      const shelfGain = -((settings.attenuationDb / 48) * 18);
      this.dolbyHighShelf.gain.setTargetAtTime(shelfGain, this.audioCtx.currentTime, 0.05);
    }

    // Deep Horizon Ambient feedback loop delay attenuation
    if (this.delayFeedback) {
      // deepHorizonDb is -48 to 0 dB
      const normalizedDelayGain = Math.max(0.01, Math.min(0.75, Math.pow(10, settings.deepHorizonDb / 20)));
      this.delayFeedback.gain.setTargetAtTime(normalizedDelayGain, this.audioCtx.currentTime, 0.05);
    }

    // Master volume & Noise floor clearance
    if (this.masterGain) {
      const baseVol = settings.diffMode === 'instrument' ? 0.42 : 0.35;
      // noiseFloorDb (-120 to -40 dB)
      const noiseGain = Math.max(0.08, Math.min(1.0, 1.0 + (settings.noiseFloorDb + 40) / 100));
      this.masterGain.gain.setTargetAtTime(baseVol * noiseGain, this.audioCtx.currentTime, 0.05);
    }
  }

  public getAudioData(): {
    freqAverage: number;
    freqArray: Uint8Array<ArrayBuffer>;
    metrics: SpectralMetrics;
  } {
    if (!this.analyser) {
      return {
        freqAverage: 0,
        freqArray: new Uint8Array(0),
        metrics: { bass: 0, mid: 0, treble: 0, centroidHz: 0, rmsDb: -96 },
      };
    }

    const buffer = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(buffer);

    let sum = 0;
    let weightedSum = 0;
    let bassSum = 0;
    let midSum = 0;
    let trebleSum = 0;

    const sampleRate = this.audioCtx?.sampleRate || 44100;
    const binWidth = sampleRate / (this.analyser.frequencyBinCount * 2);

    const bassLimit = Math.floor(250 / binWidth);
    const midLimit = Math.floor(2500 / binWidth);

    for (let i = 0; i < buffer.length; i++) {
      const val = buffer[i];
      sum += val;
      const freq = i * binWidth;
      weightedSum += freq * val;

      if (i < bassLimit) bassSum += val;
      else if (i < midLimit) midSum += val;
      else trebleSum += val;
    }

    const freqAverage = buffer.length > 0 ? sum / buffer.length / 255 : 0;
    const centroidHz = sum > 0 ? Math.round(weightedSum / sum) : 0;

    const bass = bassLimit > 0 ? bassSum / (bassLimit * 255) : 0;
    const mid = midLimit - bassLimit > 0 ? midSum / ((midLimit - bassLimit) * 255) : 0;
    const treble =
      buffer.length - midLimit > 0 ? trebleSum / ((buffer.length - midLimit) * 255) : 0;

    const rmsDb = freqAverage > 0.001 ? Math.round(20 * Math.log10(freqAverage)) : -96;

    return {
      freqAverage,
      freqArray: buffer,
      metrics: { bass, mid, treble, centroidHz, rmsDb },
    };
  }

  public stop() {
    this.isResonating = false;

    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }

    if (this.pannerInterval) {
      clearInterval(this.pannerInterval);
      this.pannerInterval = null;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    this.stopFormantCarrier();

    if (this.droneOsc1) {
      try { this.droneOsc1.stop(); } catch { /* ignore */ }
      this.droneOsc1 = null;
    }
    if (this.droneOsc2) {
      try { this.droneOsc2.stop(); } catch { /* ignore */ }
      this.droneOsc2 = null;
    }
  }

  public previewVoice(voiceIndex: number, text?: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text || 'Resonator vocal channel synchronized.');
    const voices = this.getVoices();
    if (voices[voiceIndex]) {
      utterance.voice = voices[voiceIndex];
    }
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    this.playCue('click');
    window.speechSynthesis.speak(utterance);
  }
}

export const resonatorEngine = new ResonatorAudioEngine();
