import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { ResonatorSettings, TelemetryState, VisualTopology, CameraPreset } from '../types';
import { resonatorEngine } from '../audio/resonatorAudioEngine';
import { Maximize2, Minimize2, RotateCcw, Compass, Eye, ShieldAlert, Sparkles } from 'lucide-react';

interface ThreeResonatorArenaProps {
  settings: ResonatorSettings;
  telemetry: TelemetryState;
  syllableImpulse: number;
  onOpenDiagnostics: () => void;
  onSelectTopology: (top: VisualTopology) => void;
}

const NODE_POINTS_COUNT = 3600;

interface NodeProfile {
  theta: number;
  phi: number;
  w4d: number;
  mutationSpeedMod: number;
  distanceScalarBasis: number;
  frequencyBandOffset: number;
  strandIndex: number;
}

export const ThreeResonatorArena: React.FC<ThreeResonatorArenaProps> = ({
  settings,
  telemetry,
  syllableImpulse,
  onOpenDiagnostics,
  onSelectTopology,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasTargetRef = useRef<HTMLDivElement>(null);
  const oscCanvasRef = useRef<HTMLCanvasElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);
  const [activeTopology, setActiveTopology] = useState<VisualTopology>('fractal');

  // References to Three.js instances
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const torusRef = useRef<THREE.Mesh | null>(null);
  const tesseractRef = useRef<THREE.LineSegments | null>(null);
  const satelliteBeaconsRef = useRef<THREE.Mesh[]>([]);
  const filamentLinesRef = useRef<THREE.LineSegments | null>(null);
  const nodeProfilesRef = useRef<NodeProfile[]>([]);
  const clockRef = useRef(new THREE.Clock());

  // Interactive dragging state
  const isDraggingRef = useRef(false);
  const previousPointerRef = useRef({ x: 0, y: 0 });
  const rotationVelocityRef = useRef({ x: 0, y: 0 });
  const targetCameraPosRef = useRef(new THREE.Vector3(0, 0, 8.5));

  // Acoustic multipliers interpolation
  const impulseRef = useRef(0.0);
  const settingsRef = useRef(settings);
  const topologyRef = useRef(activeTopology);

  useEffect(() => {
    settingsRef.current = settings;
    // Map diffMode to visual topology default
    if (settings.diffMode === 'spoken') {
      setActiveTopology('vocal_string');
      topologyRef.current = 'vocal_string';
    } else if (settings.diffMode === 'instrument') {
      setActiveTopology('harmonic_field');
      topologyRef.current = 'harmonic_field';
    } else if (settings.aiRoute === 'predictive') {
      setActiveTopology('tesseract_4d');
      topologyRef.current = 'tesseract_4d';
    } else {
      setActiveTopology('fractal');
      topologyRef.current = 'fractal';
    }
  }, [settings.diffMode, settings.aiRoute]);

  useEffect(() => {
    impulseRef.current = syllableImpulse;
  }, [syllableImpulse]);

  const handleTopologySwitch = (top: VisualTopology) => {
    setActiveTopology(top);
    topologyRef.current = top;
    onSelectTopology(top);
    resonatorEngine.playCue('click');
  };

  // Generate glowing radial gradient dot texture
  const createDotTexture = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
    grad.addColorStop(0.2, 'rgba(168, 85, 247, 0.95)');
    grad.addColorStop(0.5, 'rgba(6, 182, 212, 0.55)');
    grad.addColorStop(0.8, 'rgba(236, 72, 153, 0.25)');
    grad.addColorStop(1, 'rgba(2, 6, 23, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  };

  const setCameraPreset = (preset: CameraPreset) => {
    resonatorEngine.playCue('click');
    if (preset === 'core') {
      targetCameraPosRef.current.set(0, 0, 4.2);
    } else if (preset === 'planar') {
      targetCameraPosRef.current.set(0, 8.5, 0.01);
    } else if (preset === 'orbit') {
      targetCameraPosRef.current.set(5.5, 3.8, 6.0);
    } else {
      targetCameraPosRef.current.set(0, 0, 8.5);
      if (particlesRef.current) particlesRef.current.rotation.set(0, 0, 0);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Main Three.js Scene Setup & Render Loop
  useEffect(() => {
    const domTarget = canvasTargetRef.current;
    if (!domTarget) return;

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020617, 0.045);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      52,
      domTarget.clientWidth / domTarget.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 8.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(domTarget.clientWidth, domTarget.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(scene.fog.color);
    rendererRef.current = renderer;

    domTarget.replaceChildren(renderer.domElement);

    // 2. Build particle buffer geometry
    const positions = new Float32Array(NODE_POINTS_COUNT * 3);
    const colors = new Float32Array(NODE_POINTS_COUNT * 3);
    const profiles: NodeProfile[] = [];

    for (let i = 0; i < NODE_POINTS_COUNT; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const w4d = Math.random() * Math.PI * 2;

      profiles.push({
        theta,
        phi,
        w4d,
        mutationSpeedMod: 0.3 + Math.random() * 1.6,
        distanceScalarBasis: 2.8 + Math.random() * 1.1,
        frequencyBandOffset: Math.random() * Math.PI * 2,
        strandIndex: i % 8,
      });

      positions[i * 3] = 0;
      positions[i * 3 + 1] = 0;
      positions[i * 3 + 2] = 0;

      colors[i * 3] = 0.5;
      colors[i * 3 + 1] = 0.5;
      colors[i * 3 + 2] = 1.0;
    }
    nodeProfilesRef.current = profiles;

    const particlesGeo = new THREE.BufferGeometry();
    particlesGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particlesGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const dotTex = createDotTexture();
    const particlesMat = new THREE.PointsMaterial({
      size: 0.16,
      map: dotTex || undefined,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      vertexColors: true,
      sizeAttenuation: true,
    });

    const particlesMesh = new THREE.Points(particlesGeo, particlesMat);
    scene.add(particlesMesh);
    particlesRef.current = particlesMesh;

    // 3. Central Wireframe Torus Knot
    const torusGeo = new THREE.TorusKnotGeometry(1.6, 0.36, 128, 20, 2, 3);
    const torusMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      wireframe: true,
      transparent: true,
      opacity: 0.12,
    });
    const torusMesh = new THREE.Mesh(torusGeo, torusMat);
    scene.add(torusMesh);
    torusRef.current = torusMesh;

    // 4. Inner 4D Tesseract / Hypercube Wireframe (Dual Cube)
    const tesseractGeo = new THREE.BufferGeometry();
    const cubeVertices = [
      // Outer cube
      [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
      [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1],
      // Inner cube
      [-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5],
      [-0.5, -0.5, 0.5], [0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5],
    ];
    const edgeIndices = [
      // Outer edges
      0,1, 1,2, 2,3, 3,0, 4,5, 5,6, 6,7, 7,4, 0,4, 1,5, 2,6, 3,7,
      // Inner edges
      8,9, 9,10, 10,11, 11,8, 12,13, 13,14, 14,15, 15,12, 8,12, 9,13, 10,14, 11,15,
      // Connectors between inner and outer (hypercube projection edges)
      0,8, 1,9, 2,10, 3,11, 4,12, 5,13, 6,14, 7,15,
    ];
    const tesseractPos = new Float32Array(edgeIndices.length * 3);
    for (let k = 0; k < edgeIndices.length; k++) {
      const v = cubeVertices[edgeIndices[k]];
      tesseractPos[k * 3] = v[0] * 1.2;
      tesseractPos[k * 3 + 1] = v[1] * 1.2;
      tesseractPos[k * 3 + 2] = v[2] * 1.2;
    }
    tesseractGeo.setAttribute('position', new THREE.BufferAttribute(tesseractPos, 3));
    const tesseractMat = new THREE.LineBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.25,
      blending: THREE.AdditiveBlending,
    });
    const tesseractMesh = new THREE.LineSegments(tesseractGeo, tesseractMat);
    scene.add(tesseractMesh);
    tesseractRef.current = tesseractMesh;

    // 5. Satellite Beacons (Node A, Node B, Sat 04)
    const beacons: THREE.Mesh[] = [];
    const beaconGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const beaconColors = [0x06b6d4, 0xa855f7, 0xec4899];

    for (let b = 0; b < 3; b++) {
      const mat = new THREE.MeshBasicMaterial({
        color: beaconColors[b],
        wireframe: true,
      });
      const mesh = new THREE.Mesh(beaconGeo, mat);
      scene.add(mesh);
      beacons.push(mesh);
    }
    satelliteBeaconsRef.current = beacons;

    // 6. Connecting Laser Filament Lines
    const filamentGeo = new THREE.BufferGeometry();
    const filamentPositions = new Float32Array(3 * 2 * 3); // 3 lines, 2 vertices each
    filamentGeo.setAttribute('position', new THREE.BufferAttribute(filamentPositions, 3));
    const filamentMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
    });
    const filamentMesh = new THREE.LineSegments(filamentGeo, filamentMat);
    scene.add(filamentMesh);
    filamentLinesRef.current = filamentMesh;

    // Pointer Event Listeners for smooth rotation
    const domElement = renderer.domElement;

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      isDraggingRef.current = true;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      previousPointerRef.current = { x: clientX, y: clientY };
      rotationVelocityRef.current = { x: 0, y: 0 };
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDraggingRef.current) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const deltaX = clientX - previousPointerRef.current.x;
      const deltaY = clientY - previousPointerRef.current.y;

      rotationVelocityRef.current = {
        x: deltaX * 0.005,
        y: deltaY * 0.005,
      };

      if (particlesRef.current) {
        particlesRef.current.rotation.y += rotationVelocityRef.current.x;
        particlesRef.current.rotation.x += rotationVelocityRef.current.y;
      }

      previousPointerRef.current = { x: clientX, y: clientY };
    };

    const onPointerUp = () => {
      isDraggingRef.current = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (cameraRef.current) {
        targetCameraPosRef.current.z = Math.max(3.2, Math.min(16, targetCameraPosRef.current.z + e.deltaY * 0.006));
      }
    };

    domElement.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    domElement.addEventListener('touchstart', onPointerDown, { passive: true });
    window.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchend', onPointerUp);
    domElement.addEventListener('wheel', onWheel, { passive: false });

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = width / height;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(width, height);
        }
      }
    });
    resizeObserver.observe(domTarget);

    // Render & Animation Loop
    let animationFrameId: number;

    const renderLoop = () => {
      animationFrameId = requestAnimationFrame(renderLoop);

      const elapsed = clockRef.current.getElapsedTime();
      const currentSettings = settingsRef.current;
      const currentTopology = topologyRef.current;
      const audioData = resonatorEngine.getAudioData();

      // Smooth camera interpolation
      if (cameraRef.current) {
        cameraRef.current.position.lerp(targetCameraPosRef.current, 0.05);
      }

      // Syllable impulse decay
      if (impulseRef.current > 0.01) {
        impulseRef.current *= 0.92;
      }

      // Auto-rotation inertia
      if (particlesRef.current) {
        if (!isDraggingRef.current) {
          rotationVelocityRef.current.x *= 0.94;
          rotationVelocityRef.current.y *= 0.94;
          particlesRef.current.rotation.y += rotationVelocityRef.current.x;
          particlesRef.current.rotation.x += rotationVelocityRef.current.y;

          if (autoRotate) {
            particlesRef.current.rotation.y += 0.002 * currentSettings.procSpeed;
          }
        }
      }

      // Audio reactive multipliers
      const freqAmp = audioData.freqAverage * 2.8;
      const isPlaying = telemetry.isResonating;
      const reactiveBoost = isPlaying ? 1.0 + freqAmp : 0.25;
      const compoundingFactor = Math.pow(10, currentSettings.deepHorizonDb / 40);

      // Mutate particle geometry according to active Topology Form
      if (particlesRef.current && nodeProfilesRef.current.length > 0) {
        const geo = particlesRef.current.geometry;
        const posAttr = geo.getAttribute('position') as THREE.BufferAttribute;
        const colAttr = geo.getAttribute('color') as THREE.BufferAttribute;
        const profs = nodeProfilesRef.current;

        for (let i = 0; i < profs.length; i++) {
          const p = profs[i];
          const dynamicSpeed = elapsed * p.mutationSpeedMod * (0.35 + currentSettings.procSpeed * 0.4);

          let x = 0;
          let y = 0;
          let z = 0;

          if (currentTopology === 'vocal_string') {
            // Linear Vocal Chord String: Multi-strand standing waves with harmonic node dispersion
            const strandOffset = (p.strandIndex - 3.5) * 0.35;
            const waveLength = 6.0;
            const progress = (i / profs.length) * waveLength - waveLength / 2;
            x = progress;
            const harmonicFreq = (p.strandIndex + 1) * 1.5;
            y = Math.sin(progress * 1.8 + dynamicSpeed * harmonicFreq) * (0.6 + reactiveBoost * 0.4) + strandOffset;
            z = Math.cos(progress * 2.2 + dynamicSpeed * 2.0) * 0.45 * (1 + impulseRef.current * 0.8);
          } else if (currentTopology === 'harmonic_field') {
            // Hyper-Dispersed Harmonic Field: Galactic Acoustic Swirling Vortex
            const arm = i % 5;
            const armAngle = (arm * Math.PI * 2) / 5;
            const radius = (i / profs.length) * 4.2 + 0.3;
            const swirl = dynamicSpeed * 0.8 + radius * 1.8 + armAngle;
            x = Math.cos(swirl) * radius;
            z = Math.sin(swirl) * radius;
            y = Math.sin(radius * 3.5 + dynamicSpeed * 3) * (0.35 + freqAmp * 0.8);
          } else if (currentTopology === 'tesseract_4d') {
            // 4D Quantum Tesseract Hypercube projection:
            // 4D coordinates (x4, y4, z4, w4) rotated on XW, YW planes then projected to 3D
            const rBasis = p.distanceScalarBasis * (0.85 + reactiveBoost * 0.25);
            const x4 = Math.sin(p.theta) * Math.cos(p.phi) * rBasis;
            const y4 = Math.sin(p.theta) * Math.sin(p.phi) * rBasis;
            const z4 = Math.cos(p.theta) * rBasis;
            const w4 = Math.sin(p.w4d + dynamicSpeed * 0.8) * 1.4;

            // 4D rotation on XW plane
            const angle4d = dynamicSpeed * 0.6;
            const rotX = x4 * Math.cos(angle4d) - w4 * Math.sin(angle4d);
            const rotW = x4 * Math.sin(angle4d) + w4 * Math.cos(angle4d);

            // Perspective stereographic projection from 4D to 3D:
            const projDist = 3.2;
            const denom = Math.max(0.6, projDist - rotW);
            x = (rotX / denom) * 2.2;
            y = (y4 / denom) * 2.2;
            z = (z4 / denom) * 2.2;
          } else {
            // 'fractal': Polymorphic Neural Fractal Cage (Standard default)
            const ripple = Math.sin(p.theta * 4 + dynamicSpeed) * 0.35 + Math.cos(p.phi * 3 - dynamicSpeed * 0.8) * 0.25;
            const radialDist = (p.distanceScalarBasis + ripple * reactiveBoost) * (1.0 + impulseRef.current * 0.35);

            x = radialDist * Math.sin(p.phi) * Math.cos(p.theta + dynamicSpeed * 0.2);
            y = radialDist * Math.sin(p.phi) * Math.sin(p.theta + dynamicSpeed * 0.2);
            z = radialDist * Math.cos(p.phi);

            // Background / foreground layer decoupling
            if (!currentSettings.backgroundActive && radialDist > 3.2) {
              x *= 0.2;
              y *= 0.2;
              z *= 0.2;
            }
          }

          posAttr.setXYZ(i, x, y, z);

          // Harmonic color distribution modulated by Dolby Attenuation & Impulse
          const attenuationRatio = currentSettings.attenuationDb / 48; // 0 (bright treble) to 1 (warm dark)
          let r = 0.2 + 0.35 * Math.sin(x * 0.4 + dynamicSpeed);
          let g = 0.3 + 0.4 * Math.cos(y * 0.5 + dynamicSpeed * 1.2);
          let b = 0.65 + 0.35 * Math.sin(z * 0.4 + compoundingFactor);

          // Dolby damping warms up color profile
          r += attenuationRatio * 0.3;
          b -= attenuationRatio * 0.25;

          if (currentSettings.diffMode === 'spoken') {
            r += 0.3;
            g += 0.2;
          } else if (currentSettings.diffMode === 'instrument') {
            g += 0.35;
            b += 0.3;
          } else if (currentSettings.aiRoute === 'predictive') {
            r += 0.4;
            b += 0.35;
          }

          if (impulseRef.current > 0.1) {
            r += 0.4 * impulseRef.current;
            g += 0.3 * impulseRef.current;
            b += 0.4 * impulseRef.current;
          }

          colAttr.setXYZ(i, Math.min(1, r), Math.min(1, g), Math.min(1, b));
        }

        posAttr.needsUpdate = true;
        colAttr.needsUpdate = true;
      }

      // Animate inner Torus Knot wireframe
      if (torusRef.current) {
        torusRef.current.rotation.x = elapsed * 0.09;
        torusRef.current.rotation.y = elapsed * 0.14;
        const pulseScale = 1.0 + freqAmp * 0.18 + impulseRef.current * 0.2;
        torusRef.current.scale.set(pulseScale, pulseScale, pulseScale);
        const torusMat = torusRef.current.material as THREE.MeshBasicMaterial;
        torusMat.opacity = 0.08 + freqAmp * 0.15;
      }

      // Animate 4D Tesseract wireframe
      if (tesseractRef.current) {
        tesseractRef.current.rotation.y = -elapsed * 0.15;
        tesseractRef.current.rotation.z = elapsed * 0.08;
        const tessScale = 0.9 + reactiveBoost * 0.15;
        tesseractRef.current.scale.set(tessScale, tessScale, tessScale);
        const tessMat = tesseractRef.current.material as THREE.LineBasicMaterial;
        tessMat.opacity = currentTopology === 'tesseract_4d' ? 0.45 : 0.18;
      }

      // Animate Satellite Beacons & Connecting Laser Filaments
      if (satelliteBeaconsRef.current.length === 3 && filamentLinesRef.current) {
        const beaconPositions: [number, number, number][] = [
          [Math.cos(elapsed * 0.4) * 4.2, Math.sin(elapsed * 0.5) * 1.5, Math.sin(elapsed * 0.4) * 4.2],
          [Math.cos(elapsed * 0.35 + 2.1) * 3.8, Math.cos(elapsed * 0.4) * 1.8, Math.sin(elapsed * 0.35 + 2.1) * 3.8],
          [Math.cos(elapsed * 0.45 + 4.2) * 4.5, Math.sin(elapsed * 0.3) * -1.6, Math.sin(elapsed * 0.45 + 4.2) * 4.5],
        ];

        const fGeo = filamentLinesRef.current.geometry;
        const fPos = fGeo.getAttribute('position') as THREE.BufferAttribute;

        for (let b = 0; b < 3; b++) {
          const mesh = satelliteBeaconsRef.current[b];
          mesh.position.set(...beaconPositions[b]);

          // Laser line from center (0,0,0) to satellite
          fPos.setXYZ(b * 2, 0, 0, 0);
          fPos.setXYZ(b * 2 + 1, beaconPositions[b][0], beaconPositions[b][1], beaconPositions[b][2]);
        }
        fPos.needsUpdate = true;
      }

      // Draw real-time Neon Oscilloscope on 2D HUD Canvas
      if (oscCanvasRef.current) {
        const oscCtx = oscCanvasRef.current.getContext('2d');
        if (oscCtx) {
          const w = oscCanvasRef.current.width;
          const h = oscCanvasRef.current.height;

          oscCtx.clearRect(0, 0, w, h);

          // Background scanlines
          oscCtx.fillStyle = 'rgba(2, 6, 23, 0.4)';
          oscCtx.fillRect(0, 0, w, h);

          // Grid line
          oscCtx.strokeStyle = 'rgba(30, 41, 59, 0.5)';
          oscCtx.lineWidth = 1;
          oscCtx.beginPath();
          oscCtx.moveTo(0, h / 2);
          oscCtx.lineTo(w, h / 2);
          oscCtx.stroke();

          // Frequency spectrum bars or waveform
          const buffer = audioData.freqArray;
          if (buffer.length > 0) {
            oscCtx.lineWidth = 1.5;
            oscCtx.strokeStyle = currentSettings.diffMode === 'spoken' ? '#38bdf8' : '#c084fc';
            oscCtx.beginPath();

            const sliceWidth = w / 64;
            let x = 0;

            for (let b = 0; b < 64; b++) {
              const val = buffer[b * 2] / 255;
              const y = h - val * (h * 0.85) - 2;

              if (b === 0) oscCtx.moveTo(x, y);
              else oscCtx.lineTo(x, y);

              x += sliceWidth;
            }

            oscCtx.stroke();
          }
        }
      }

      if (sceneRef.current && cameraRef.current) {
        renderer.render(sceneRef.current, cameraRef.current);
      }
    };

    renderLoop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      domElement.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      domElement.removeEventListener('touchstart', onPointerDown);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);
      domElement.removeEventListener('wheel', onWheel);
      renderer.dispose();
    };
  }, [autoRotate]);

  return (
    <section
      ref={containerRef}
      id="canvasContainer"
      className="flex-1 relative w-full h-full min-h-[520px] xl:h-screen bg-slate-950 overflow-hidden cursor-grab active:cursor-grabbing select-none"
    >
      {/* 3D WebGL Canvas Layer */}
      <div ref={canvasTargetRef} className="w-full h-full" />

      {/* Left Wing Diagnostic Telemetry Matrix HUD */}
      <div
        id="leftWingHud"
        className="absolute top-4 left-4 p-3.5 bg-slate-950/85 border border-slate-800/80 backdrop-blur-md rounded-xl font-mono text-[10px] text-slate-400 space-y-2 z-10 pointer-events-none max-w-[280px] shadow-2xl"
      >
        <div className="text-cyan-400 font-bold uppercase tracking-wider text-[11px] flex justify-between items-center">
          <span>Predictive Melodic Flow</span>
          <span
            className={`w-2 h-2 rounded-full ${
              telemetry.isResonating ? 'bg-cyan-400 animate-ping' : 'bg-cyan-600/50'
            }`}
          />
        </div>

        <div className="h-1.5 bg-slate-900 rounded overflow-hidden">
          <div
            id="predictiveFlowProgress"
            className="h-full bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 transition-all duration-300 shadow-sm"
            style={{ width: `${telemetry.flowProgress}%` }}
          />
        </div>

        <div>
          4D Coordinate Tensor:{' '}
          <span className="text-slate-200" id="patternVectorLabel">
            [{telemetry.patternVectors.map((v) => v.toFixed(2)).join(', ')}]
          </span>
        </div>

        <div>
          Foreshadow Horizon:{' '}
          <span className="text-purple-400 font-semibold" id="foreshadowLabel">
            {telemetry.foreshadowText}
          </span>
        </div>

        <div className="pt-1.5 border-t border-slate-900 flex justify-between items-center text-[9px]">
          <span className="text-slate-500 uppercase tracking-tight">Spectral Centroid:</span>
          <span className="text-cyan-300 font-bold">{telemetry.spectralMetrics.centroidHz} Hz</span>
        </div>

        <div className="flex justify-between items-center text-[9px]">
          <span className="text-slate-500 uppercase tracking-tight">RMS Clearance Level:</span>
          <span className="text-pink-300 font-bold">{telemetry.spectralMetrics.rmsDb} dB</span>
        </div>
      </div>

      {/* Right Wing Diagnostic Telemetry Matrix HUD */}
      <div
        id="rightWingHud"
        className="absolute top-4 right-4 p-3.5 bg-slate-950/85 border border-slate-800/80 backdrop-blur-md rounded-xl font-mono text-[10px] text-slate-400 space-y-2.5 z-10 max-w-[270px] shadow-2xl"
      >
        <div className="text-pink-400 font-bold uppercase tracking-wider text-[11px] flex items-center justify-between">
          <span>4D Spatial Projections</span>
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-pink-500/10 text-pink-300 border border-pink-500/20 font-mono font-bold">
            {settings.diffMode.toUpperCase()}
          </span>
        </div>

        {/* Interactive Topology Selector Buttons */}
        <div>
          <span className="text-[9px] text-slate-500 uppercase block mb-1">Visual Topology Form:</span>
          <div className="grid grid-cols-2 gap-1 pointer-events-auto">
            <button
              id="topBtnFractal"
              onClick={() => handleTopologySwitch('fractal')}
              className={`px-1.5 py-1 rounded text-[9px] font-mono border transition ${
                activeTopology === 'fractal'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Fractal Cage
            </button>
            <button
              id="topBtnVocal"
              onClick={() => handleTopologySwitch('vocal_string')}
              className={`px-1.5 py-1 rounded text-[9px] font-mono border transition ${
                activeTopology === 'vocal_string'
                  ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 font-bold'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Vocal String
            </button>
            <button
              id="topBtnHarmonic"
              onClick={() => handleTopologySwitch('harmonic_field')}
              className={`px-1.5 py-1 rounded text-[9px] font-mono border transition ${
                activeTopology === 'harmonic_field'
                  ? 'bg-pink-500/20 text-pink-300 border-pink-500/40 font-bold'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Vortex Field
            </button>
            <button
              id="topBtnTesseract"
              onClick={() => handleTopologySwitch('tesseract_4d')}
              className={`px-1.5 py-1 rounded text-[9px] font-mono border transition ${
                activeTopology === 'tesseract_4d'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              4D Tesseract
            </button>
          </div>
        </div>

        <div>
          Fractal Intensity:{' '}
          <span className="text-cyan-400 font-bold" id="fractalIntensityLabel">
            {(telemetry.fractalIntensity * 8.4).toFixed(1)} Hz Amplitude
          </span>
        </div>

        <div>
          Far Background Channels:{' '}
          <span className="text-slate-400 block" id="farBgChannelLabel">
            {settings.backgroundActive
              ? 'Compounding Deep Horizon Active'
              : 'Suppressed Stack Muted'}
          </span>
        </div>

        {/* Linked Node Indicators */}
        <div className="pt-1.5 border-t border-slate-900 grid grid-cols-3 gap-1 text-[8px] text-center font-mono pointer-events-auto">
          <button
            id="hudDevice1"
            onClick={onOpenDiagnostics}
            className={`p-1 rounded transition-colors duration-200 border cursor-pointer ${
              telemetry.activeNodes.nodeA
                ? 'bg-cyan-500/30 text-cyan-200 border-cyan-400 ring-1 ring-cyan-400 shadow-md'
                : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
            title="Inspect NODE.A Diagnostics"
          >
            <span className="block font-bold">NODE.A</span>
            <span className="text-[7px] text-cyan-400 block">12ms</span>
          </button>
          <button
            id="hudDevice2"
            onClick={onOpenDiagnostics}
            className={`p-1 rounded transition-colors duration-200 border cursor-pointer ${
              telemetry.activeNodes.nodeB
                ? 'bg-purple-500/30 text-purple-200 border-purple-400 ring-1 ring-purple-400 shadow-md'
                : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
            title="Inspect NODE.B Diagnostics"
          >
            <span className="block font-bold">NODE.B</span>
            <span className="text-[7px] text-purple-400 block">8ms</span>
          </button>
          <button
            id="hudDevice3"
            onClick={onOpenDiagnostics}
            className={`p-1 rounded transition-colors duration-200 border cursor-pointer ${
              telemetry.activeNodes.sat04
                ? 'bg-pink-500/30 text-pink-200 border-pink-400 ring-1 ring-pink-400 shadow-md'
                : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
            title="Inspect SAT.04 Diagnostics"
          >
            <span className="block font-bold">SAT.04</span>
            <span className="text-[7px] text-pink-400 block">15ms</span>
          </button>
        </div>
      </div>

      {/* Arena Floating View Controls Bar */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 p-1.5 bg-slate-950/80 border border-slate-800/80 backdrop-blur-md rounded-xl text-[10px] font-mono">
        <button
          id="orbitPresetBtn"
          onClick={() => setCameraPreset('orbit')}
          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 transition flex items-center gap-1"
          title="Orbit Perspective"
        >
          <Compass className="w-3 h-3" />
          <span className="hidden sm:inline">Orbit</span>
        </button>
        <button
          id="corePresetBtn"
          onClick={() => setCameraPreset('core')}
          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-purple-300 transition flex items-center gap-1"
          title="Core Zoom"
        >
          <Eye className="w-3 h-3" />
          <span className="hidden sm:inline">Core</span>
        </button>
        <button
          id="planarPresetBtn"
          onClick={() => setCameraPreset('planar')}
          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-pink-300 transition flex items-center gap-1"
          title="Planar Lattice View"
        >
          <Sparkles className="w-3 h-3" />
          <span className="hidden sm:inline">Planar</span>
        </button>
        <button
          id="resetViewBtn"
          onClick={() => setCameraPreset('free')}
          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition flex items-center gap-1"
          title="Reset Camera Orientation"
        >
          <RotateCcw className="w-3 h-3" />
          <span className="hidden sm:inline">Reset</span>
        </button>
        <button
          id="autoRotateToggle"
          onClick={() => setAutoRotate(!autoRotate)}
          className={`px-2 py-1 rounded border transition ${
            autoRotate
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
              : 'bg-slate-900 text-slate-500 border-slate-800'
          }`}
          title="Toggle Auto Rotation"
        >
          {autoRotate ? 'Spin ON' : 'Spin OFF'}
        </button>
        <button
          id="fullscreenToggle"
          onClick={toggleFullscreen}
          className="p-1.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Arena'}
        >
          {isFullscreen ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
        </button>
      </div>

      {/* Bottom Floating Telemetry & Oscilloscope HUD */}
      <div
        id="bottomHud"
        className="absolute bottom-4 left-4 right-4 p-3 bg-slate-950/85 border border-slate-800/80 backdrop-blur-md rounded-xl font-mono text-[10px] text-slate-400 flex flex-col md:flex-row items-center justify-between gap-3 z-10 shadow-2xl"
      >
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-300 font-bold">CONNECTED INTEGRATIONS:</span>
            <span className="text-emerald-400">4 / 4 ACTIVE (DOLBY MATRIX)</span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5">
            <span className="text-slate-500">CLEARANCE:</span>
            <span className="text-cyan-400 font-semibold">
              {settings.noiseFloorDb <= -90 ? 'FILTERED CLEAN' : 'PASSIVE REDUCTION'} ({settings.noiseFloorDb} dB)
            </span>
          </div>

          <div className="hidden lg:flex items-center gap-1.5">
            <span className="text-slate-500">DOLBY DAMPING:</span>
            <span className="text-purple-400 font-semibold">{settings.attenuationDb} dB/oct</span>
          </div>
        </div>

        {/* Real-time Oscilloscope Mini-Canvas */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="relative border border-slate-800 rounded bg-slate-950 overflow-hidden w-36 sm:w-48 h-7">
            <canvas
              ref={oscCanvasRef}
              width={192}
              height={28}
              className="w-full h-full block"
            />
            <span className="absolute top-0.5 left-1 text-[8px] text-slate-500 font-mono select-none pointer-events-none">
              SPECTRAL BUS
            </span>
          </div>

          {/* Audit 4D Telemetry Button */}
          <button
            id="openDiagnosticsBtn"
            onClick={onOpenDiagnostics}
            className="px-3 py-1.5 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/40 text-cyan-300 font-bold uppercase tracking-wider transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <ShieldAlert className="w-3 h-3" />
            <span>Audit 4D Telemetry</span>
          </button>
        </div>
      </div>
    </section>
  );
};
