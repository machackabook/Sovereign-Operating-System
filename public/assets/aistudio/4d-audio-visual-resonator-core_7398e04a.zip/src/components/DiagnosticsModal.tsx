import React from 'react';
import { TelemetryState, ResonatorSettings } from '../types';
import { X, ShieldCheck, Activity, Radio, Cpu, Network, Zap } from 'lucide-react';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: TelemetryState;
  settings: ResonatorSettings;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  telemetry,
  settings,
}) => {
  if (!isOpen) return null;

  const copySnapshot = () => {
    const report = JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        settings,
        telemetry: {
          patternVectors: telemetry.patternVectors,
          spectralMetrics: telemetry.spectralMetrics,
          nodesDetail: telemetry.nodesDetail,
          topologyForm: telemetry.topologyForm,
          statusText: telemetry.statusText,
        },
      },
      null,
      2
    );
    navigator.clipboard.writeText(report);
  };

  return (
    <div
      id="diagnosticsOverlay"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        id="diagnosticsModal"
        className="w-full max-w-2xl bg-slate-950 border border-cyan-500/30 rounded-2xl p-6 shadow-2xl space-y-5 text-slate-200 font-mono text-xs overflow-y-auto max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-900 pb-3">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-sm font-bold text-cyan-300 uppercase tracking-wider">
                4D Quantum Telemetry & Neural Parity Inspector
              </h2>
              <p className="text-[10px] text-slate-500 font-sans">
                Real-time sub-harmonic bus verification and peripheral satellite routing audit
              </p>
            </div>
          </div>
          <button
            id="closeDiagnosticsBtn"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* System Diagnostics Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
              <Cpu className="w-3 h-3 text-cyan-400" /> Core Routing
            </span>
            <div className="text-cyan-300 font-bold text-xs uppercase">{settings.aiRoute} Matrix</div>
            <div className="text-[9px] text-slate-400">
              {settings.procSpeed.toFixed(2)}x Throttle
            </div>
          </div>

          <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
              <Activity className="w-3 h-3 text-purple-400" /> Spectral Centroid
            </span>
            <div className="text-purple-300 font-bold text-xs">
              {telemetry.spectralMetrics.centroidHz} Hz
            </div>
            <div className="text-[9px] text-slate-400">
              {telemetry.spectralMetrics.rmsDb} dB RMS
            </div>
          </div>

          <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-pink-400" /> Dolby Damping
            </span>
            <div className="text-pink-300 font-bold text-xs">
              {settings.attenuationDb} dB/oct
            </div>
            <div className="text-[9px] text-slate-400">High-End Roll-off</div>
          </div>

          <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl space-y-1">
            <span className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
              <Zap className="w-3 h-3 text-emerald-400" /> Floor Clearance
            </span>
            <div className="text-emerald-300 font-bold text-xs">
              {settings.noiseFloorDb} dB
            </div>
            <div className="text-[9px] text-slate-400">Known Unknown Active</div>
          </div>
        </div>

        {/* Satellite Node Network Status */}
        <div>
          <h3 className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Network className="w-3.5 h-3.5 text-cyan-400" /> Connected Peripheral Arrays
          </h3>
          <div className="space-y-2">
            {Object.entries(telemetry.nodesDetail).map(([key, node]) => (
              <div
                key={key}
                className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      node.intensity > 0.4
                        ? 'bg-cyan-400 animate-ping'
                        : 'bg-emerald-500'
                    }`}
                  />
                  <div>
                    <div className="font-bold text-slate-200">{node.name}</div>
                    <div className="text-[10px] text-slate-500">Channel: {node.channel}</div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-[10px]">
                  <div>
                    <span className="text-slate-500 block">LATENCY</span>
                    <span className="text-cyan-400">{node.latencyMs} ms</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">PARITY</span>
                    <span className="text-purple-400">{node.parity}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">PACKETS</span>
                    <span className="text-slate-300">{node.packets.toLocaleString()}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-bold">
                    {node.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4D Vector Tensor Status */}
        <div className="p-3.5 bg-slate-900/40 border border-slate-900 rounded-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 uppercase">
              Current 4D Coordinate Tensor Matrix [X, Y, Z, W]
            </span>
            <span className="text-pink-400 text-[10px]">
              Tension Scalar: {telemetry.fractalIntensity.toFixed(3)}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-2 text-center text-[11px]">
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-500 text-[9px] block">VECTOR X</span>
              <span className="text-cyan-400 font-bold">{telemetry.patternVectors[0].toFixed(3)}</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-500 text-[9px] block">VECTOR Y</span>
              <span className="text-purple-400 font-bold">{telemetry.patternVectors[1].toFixed(3)}</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-500 text-[9px] block">VECTOR Z</span>
              <span className="text-pink-400 font-bold">{telemetry.patternVectors[2].toFixed(3)}</span>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <span className="text-slate-500 text-[9px] block">VECTOR W (4D)</span>
              <span className="text-emerald-400 font-bold">{telemetry.patternVectors[3].toFixed(3)}</span>
            </div>
          </div>
        </div>

        {/* Modal Actions Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-900">
          <button
            id="copySnapshotBtn"
            onClick={copySnapshot}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 transition text-[10px]"
          >
            📋 Copy Telemetry Snapshot (JSON)
          </button>
          <button
            id="modalDismissBtn"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition text-[10px] uppercase tracking-wider"
          >
            Dismiss Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
