import React, { useState } from 'react';
import { ResonatorSettings, TelemetryState, DiffMode, AiRoute } from '../types';
import { resonatorEngine } from '../audio/resonatorAudioEngine';
import { Play, Square, Activity, Mic, MicOff, Volume2, Sparkles, Sliders, Waves } from 'lucide-react';

interface ControlDeckProps {
  settings: ResonatorSettings;
  setSettings: React.Dispatch<React.SetStateAction<ResonatorSettings>>;
  telemetry: TelemetryState;
  voices: SpeechSynthesisVoice[];
  activePresetId: number | null;
  onResonate: () => void;
  onKill: () => void;
  onLoadPreset: (id: 1 | 2 | 3 | 4) => void;
}

export const ControlDeck: React.FC<ControlDeckProps> = ({
  settings,
  setSettings,
  telemetry,
  voices,
  activePresetId,
  onResonate,
  onKill,
  onLoadPreset,
}) => {
  const [micActive, setMicActive] = useState(false);

  const toggleDiffMode = (target: DiffMode) => {
    resonatorEngine.playCue('click');
    setSettings((prev) => ({
      ...prev,
      diffMode: prev.diffMode === target ? 'mix' : target,
    }));
  };

  const handleAiRoute = (route: AiRoute) => {
    resonatorEngine.playCue('click');
    setSettings((prev) => ({ ...prev, aiRoute: route }));
  };

  const handleToggleMic = async () => {
    resonatorEngine.playCue('click');
    const nextState = !micActive;
    const ok = await resonatorEngine.toggleMicrophone(nextState);
    setMicActive(ok);
    setSettings((prev) => ({ ...prev, micActive: ok }));
  };

  const handlePreviewVoice = () => {
    resonatorEngine.previewVoice(
      settings.voiceIndex,
      settings.text.slice(0, 60) || 'Neural acoustic transmission verified.'
    );
  };

  return (
    <main className="w-full xl:w-[32%] min-w-[340px] max-w-[520px] xl:max-w-none bg-slate-950 border-b xl:border-b-0 xl:border-r border-slate-900 p-5 flex flex-col justify-between z-10 backdrop-blur-xl overflow-y-auto xl:h-screen select-none">
      <div>
        {/* Global Brand & Status Section */}
        <header className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="px-2 py-0.5 text-[10px] font-mono bg-cyan-500/10 text-cyan-400 tracking-widest rounded border border-cyan-500/20 uppercase flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              Predictive AI Routing
            </span>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-purple-500/10 text-purple-400 tracking-widest rounded border border-purple-500/20 uppercase flex items-center gap-1">
              <Waves className="w-2.5 h-2.5" />
              Dolby Attenuation 4.0
            </span>
          </div>
          <h1 className="text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-500 tracking-tight uppercase">
            4D Resonator Deck
          </h1>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Polymorphic neutrality engine transforming vocal strings and synthesizers into
            anticipatory multi-channel lattice geometries.
          </p>
        </header>

        {/* Operational Control Matrix Modules */}
        <div className="space-y-4">
          {/* Text Sequence Input Block */}
          <div>
            <label
              htmlFor="textInput"
              className="block text-[10px] font-mono tracking-wider uppercase text-slate-400 mb-1.5 flex justify-between items-center"
            >
              <span>Input Matrix Streams</span>
              <span className="text-cyan-400 italic font-sans text-[11px]">
                Melodic Flow Pattern Enabled
              </span>
            </label>
            <textarea
              id="textInput"
              value={settings.text}
              onChange={(e) =>
                setSettings((prev) => ({ ...prev, text: e.target.value }))
              }
              className="w-full h-24 bg-slate-900/90 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition resize-none font-sans leading-relaxed placeholder:text-slate-600"
              placeholder="Inject linguistic telemetry codes here..."
            />
          </div>

          {/* Strategic Preset Formations */}
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
              <span>Sequence Formations</span>
              <span className="text-purple-400">4 Presets Cached</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <button
                id="preset1Btn"
                onClick={() => onLoadPreset(1)}
                className={`p-2 rounded-md text-left transition truncate border flex items-center justify-between ${
                  activePresetId === 1
                    ? 'bg-cyan-950/50 border-cyan-500/60 text-cyan-300 shadow-sm'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-cyan-300'
                }`}
              >
                <span>🌀 Fractal Harmonic</span>
                {activePresetId === 1 && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />}
              </button>
              <button
                id="preset2Btn"
                onClick={() => onLoadPreset(2)}
                className={`p-2 rounded-md text-left transition truncate border flex items-center justify-between ${
                  activePresetId === 2
                    ? 'bg-purple-950/50 border-purple-500/60 text-purple-300 shadow-sm'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-purple-300'
                }`}
              >
                <span>🧠 Polymorphic Synth</span>
                {activePresetId === 2 && <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />}
              </button>
              <button
                id="preset3Btn"
                onClick={() => onLoadPreset(3)}
                className={`p-2 rounded-md text-left transition truncate border flex items-center justify-between ${
                  activePresetId === 3
                    ? 'bg-pink-950/50 border-pink-500/60 text-pink-300 shadow-sm'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-pink-300'
                }`}
              >
                <span>🛡️ Noise Floor Clear</span>
                {activePresetId === 3 && <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />}
              </button>
              <button
                id="preset4Btn"
                onClick={() => onLoadPreset(4)}
                className={`p-2 rounded-md text-left transition truncate border flex items-center justify-between ${
                  activePresetId === 4
                    ? 'bg-emerald-950/50 border-emerald-500/60 text-emerald-300 shadow-sm'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800/80 hover:border-slate-700 text-slate-300 hover:text-emerald-300'
                }`}
              >
                <span>⚡ Device Intercept</span>
                {activePresetId === 4 && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
              </button>
            </div>
          </div>

          {/* AI Synthesis Routing Deck */}
          <div className="bg-slate-900/40 p-3 rounded-lg border border-slate-900 space-y-3">
            <h3 className="text-[10px] font-mono tracking-wider uppercase text-cyan-400 flex justify-between items-center">
              <span>AI Synthesis Routing Deck</span>
              <span id="speedIndicator" className="text-slate-500 font-mono">
                {Math.round(settings.procSpeed * 100)}% Core Load
              </span>
            </h3>

            {/* AI Route Selectors */}
            <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono">
              <label
                className={`cursor-pointer p-1.5 rounded border flex flex-col items-center justify-center gap-1 transition text-center ${
                  settings.aiRoute === 'direct'
                    ? 'bg-cyan-950/50 border-cyan-500/60 text-cyan-300 shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-cyan-500/30'
                }`}
              >
                <input
                  type="radio"
                  name="aiRoute"
                  value="direct"
                  checked={settings.aiRoute === 'direct'}
                  onChange={() => handleAiRoute('direct')}
                  className="accent-cyan-500 sr-only"
                />
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mb-0.5" />
                <span>Direct Neural</span>
              </label>

              <label
                className={`cursor-pointer p-1.5 rounded border flex flex-col items-center justify-center gap-1 transition text-center ${
                  settings.aiRoute === 'matrix'
                    ? 'bg-purple-950/50 border-purple-500/60 text-purple-300 shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-purple-500/30'
                }`}
              >
                <input
                  type="radio"
                  name="aiRoute"
                  value="matrix"
                  checked={settings.aiRoute === 'matrix'}
                  onChange={() => handleAiRoute('matrix')}
                  className="accent-purple-500 sr-only"
                />
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mb-0.5" />
                <span>Multi-Channel</span>
              </label>

              <label
                className={`cursor-pointer p-1.5 rounded border flex flex-col items-center justify-center gap-1 transition text-center ${
                  settings.aiRoute === 'predictive'
                    ? 'bg-pink-950/50 border-pink-500/60 text-pink-300 shadow-sm'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-pink-500/30'
                }`}
              >
                <input
                  type="radio"
                  name="aiRoute"
                  value="predictive"
                  checked={settings.aiRoute === 'predictive'}
                  onChange={() => handleAiRoute('predictive')}
                  className="accent-pink-500 sr-only"
                />
                <span className="w-1.5 h-1.5 rounded-full bg-pink-400 mb-0.5" />
                <span>Foreshadow</span>
              </label>
            </div>

            {/* Synthetic Voice Selector & Controls */}
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                <label htmlFor="voiceSelect">Synthetic Voice Core Engine</label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handlePreviewVoice}
                    className="text-cyan-400 hover:text-cyan-300 transition text-[9px] flex items-center gap-0.5"
                    title="Audition Selected Voice"
                  >
                    <Volume2 className="w-2.5 h-2.5" /> Test Voice
                  </button>
                  <button
                    id="micToggleBtn"
                    type="button"
                    onClick={handleToggleMic}
                    className={`px-1.5 py-0.5 rounded text-[9px] border transition flex items-center gap-1 ${
                      micActive
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 animate-pulse'
                        : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                    }`}
                    title="Live Acoustic Microphone Intercept into 4D Resonator"
                  >
                    {micActive ? <Mic className="w-2.5 h-2.5" /> : <MicOff className="w-2.5 h-2.5" />}
                    <span>{micActive ? 'MIC ON' : 'MIC OFF'}</span>
                  </button>
                </div>
              </div>
              <select
                id="voiceSelect"
                value={settings.voiceIndex}
                onChange={(e) => {
                  resonatorEngine.playCue('click');
                  setSettings((prev) => ({
                    ...prev,
                    voiceIndex: Number(e.target.value),
                  }));
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-[11px] font-mono text-slate-300 focus:outline-none focus:border-purple-500 truncate"
              >
                {voices.length === 0 ? (
                  <option value={0}>Default System Voice Synthesizer</option>
                ) : (
                  voices.map((v, idx) => (
                    <option key={`${v.name}-${idx}`} value={idx}>
                      {v.name} ({v.lang})
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          {/* Acoustic Modulation & Attenuation Parameters */}
          <div className="bg-slate-900/40 p-3 rounded-lg border border-slate-900 space-y-3">
            <h3 className="text-[10px] font-mono tracking-wider uppercase text-purple-400 flex items-center gap-1.5">
              <Sliders className="w-3 h-3 text-purple-400" />
              High-End Dolby Attenuation & Modulation Parameters
            </h3>

            {/* Dolby HF Damping */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                <span>Dolby High-End Attenuation (HF Damping)</span>
                <span id="attenuationVal" className="text-cyan-400 font-bold">
                  {settings.attenuationDb} dB/oct
                </span>
              </div>
              <input
                type="range"
                id="attenuationSlider"
                min="0"
                max="48"
                step="6"
                value={settings.attenuationDb}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    attenuationDb: Number(e.target.value),
                  }))
                }
                className="w-full accent-cyan-500 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            {/* AI Speed Throttle */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                <span>AI Processing Speed Throttle</span>
                <span id="procSpeedVal" className="text-purple-400 font-bold">
                  {settings.procSpeed.toFixed(2)}x Core
                </span>
              </div>
              <input
                type="range"
                id="procSpeedSlider"
                min="0.25"
                max="3"
                step="0.25"
                value={settings.procSpeed}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    procSpeed: Number(e.target.value),
                  }))
                }
                className="w-full accent-purple-500 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            {/* Noise Floor Clearance */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                <span>Noise Floor Clearance (Known Unknown Filter)</span>
                <span id="noiseFloorVal" className="text-pink-400 font-bold">
                  {settings.noiseFloorDb} dB
                </span>
              </div>
              <input
                type="range"
                id="noiseFloorSlider"
                min="-120"
                max="-40"
                step="5"
                value={settings.noiseFloorDb}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    noiseFloorDb: Number(e.target.value),
                  }))
                }
                className="w-full accent-pink-500 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            {/* Rhythm & Tone Synchronization */}
            <div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                <span>Rhythm & Tone Synchronization Index</span>
                <span id="syncIndexVal" className="text-slate-300 font-bold">
                  {settings.syncIndex === 100
                    ? 'Perfect Match'
                    : `${settings.syncIndex}% Align`}
                </span>
              </div>
              <input
                type="range"
                id="syncIndexSlider"
                min="0"
                max="100"
                value={settings.syncIndex}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    syncIndex: Number(e.target.value),
                  }))
                }
                className="w-full accent-slate-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Foreground vs Background Signal Decoupler Platform */}
          <div className="bg-slate-900/40 p-3 rounded-lg border border-slate-900 space-y-3">
            <div className="flex items-center justify-between text-[10px] font-mono tracking-wider uppercase">
              <span className="text-pink-400">Foreground / Background Layers</span>
              <div className="flex gap-2">
                <button
                  id="fgToggle"
                  onClick={() => {
                    resonatorEngine.playCue('click');
                    setSettings((prev) => ({
                      ...prev,
                      foregroundActive: !prev.foregroundActive,
                    }));
                  }}
                  className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-tighter transition font-mono border ${
                    settings.foregroundActive
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30 shadow-sm'
                      : 'bg-slate-900 text-slate-600 border-slate-800'
                  }`}
                >
                  {settings.foregroundActive ? 'FG ON' : 'FG OFF'}
                </button>
                <button
                  id="bgToggle"
                  onClick={() => {
                    resonatorEngine.playCue('click');
                    setSettings((prev) => ({
                      ...prev,
                      backgroundActive: !prev.backgroundActive,
                    }));
                  }}
                  className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-tighter transition font-mono border ${
                    settings.backgroundActive
                      ? 'bg-purple-500/20 text-purple-300 border-purple-500/30 shadow-sm'
                      : 'bg-slate-900 text-slate-600 border-slate-800'
                  }`}
                >
                  {settings.backgroundActive ? 'BG MIX' : 'BG OFF'}
                </button>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                <span>Compounding Noise Attenuation (Deep Horizon)</span>
                <span id="deepHorizonVal" className="text-purple-400 font-bold">
                  {settings.deepHorizonDb} dB Comp
                </span>
              </div>
              <input
                type="range"
                id="deepHorizonSlider"
                min="-48"
                max="0"
                step="3"
                value={settings.deepHorizonDb}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    deepHorizonDb: Number(e.target.value),
                  }))
                }
                className="w-full accent-purple-500 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            {/* Ambient Compounding Channel Levels Stack Graph Simulator */}
            <div>
              <div className="flex justify-between text-[9px] font-mono text-slate-500 mb-1">
                <span>CHANNEL LEVELS SPECTRUM STACK</span>
                <span>5 BUS REAL-TIME</span>
              </div>
              <div className="h-7 bg-slate-950 rounded border border-slate-800 flex items-end p-1 gap-1 overflow-hidden">
                {telemetry.compoundingStack.map((val, idx) => (
                  <div
                    key={`stackBar-${idx}`}
                    id={`stackBar${idx + 1}`}
                    className="flex-1 rounded-sm transition-all duration-150 relative group"
                    style={{
                      height: `${Math.max(8, Math.min(100, val))}%`,
                      backgroundColor:
                        idx === 0
                          ? '#38bdf8'
                          : idx === 1
                          ? '#818cf8'
                          : idx === 2
                          ? '#c084fc'
                          : idx === 3
                          ? '#f472b6'
                          : '#34d399',
                      opacity: 0.88,
                    }}
                  >
                    <span className="sr-only">Channel {idx + 1} level {Math.round(val)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Terminal Actions & Pipeline Trigger Footing */}
      <footer className="mt-5 pt-3 border-t border-slate-900 space-y-3">
        {/* Diff Compare Engine Mode Matrix Selector Button Toggle */}
        <div className="flex bg-slate-950 p-1 border border-slate-900 rounded-lg text-[10px] font-mono gap-1">
          <button
            id="diffSpeechBtn"
            onClick={() => toggleDiffMode('spoken')}
            className={`flex-1 py-1.5 px-2 rounded font-bold uppercase tracking-tight transition ${
              settings.diffMode === 'spoken'
                ? 'bg-gradient-to-r from-cyan-500/30 to-cyan-400/20 border border-cyan-500/40 text-cyan-300 shadow-sm'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Spoken Matrix
          </button>
          <button
            id="diffInstrumentBtn"
            onClick={() => toggleDiffMode('instrument')}
            className={`flex-1 py-1.5 px-2 rounded font-bold uppercase tracking-tight transition ${
              settings.diffMode === 'instrument'
                ? 'bg-gradient-to-r from-purple-500/30 to-pink-500/20 border border-purple-500/40 text-purple-300 shadow-sm'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Instruments Mode
          </button>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex gap-2">
          <button
            id="speakBtn"
            onClick={onResonate}
            className={`flex-1 py-2.5 px-4 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-white text-xs font-bold font-mono tracking-wider uppercase rounded-lg transition shadow-xl flex items-center justify-center gap-2 cursor-pointer ${
              telemetry.isResonating
                ? 'ring-2 ring-cyan-400 animate-pulse shadow-cyan-500/50'
                : 'hover:shadow-purple-500/30'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            RESONATE FREQUENCIES
          </button>

          <button
            id="stopBtn"
            onClick={onKill}
            className="py-2.5 px-3.5 bg-slate-900 hover:bg-red-950/40 border border-slate-800 hover:border-red-500/40 text-slate-400 hover:text-red-300 rounded-lg transition text-xs font-mono uppercase flex items-center justify-center gap-1.5 cursor-pointer"
            title="Emergency Terminate Resonance"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            KILL
          </button>
        </div>

        {/* Real-time System Status Indicator */}
        <div className="flex items-center justify-between text-[9px] font-mono text-slate-500 px-0.5">
          <span id="statusIndicator" className="flex items-center gap-1.5">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                telemetry.isResonating
                  ? 'bg-pink-500 animate-ping'
                  : 'bg-emerald-500 animate-pulse'
              }`}
            />
            <span className={telemetry.isResonating ? 'text-pink-400 font-semibold' : ''}>
              {telemetry.statusText}
            </span>
          </span>
          <span className="flex items-center gap-1">
            <Activity className="w-2.5 h-2.5 text-cyan-500" />
            SYSTEM SYNCHRONIZED
          </span>
        </div>
      </footer>
    </main>
  );
};
